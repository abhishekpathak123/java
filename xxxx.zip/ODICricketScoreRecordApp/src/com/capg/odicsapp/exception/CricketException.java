package com.capg.odicsapp.exception;

public class CricketException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CricketException(String message) {
		super(message);
	}

}

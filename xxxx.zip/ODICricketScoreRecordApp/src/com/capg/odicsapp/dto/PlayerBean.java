package com.capg.odicsapp.dto;

import java.time.LocalDate;

public class PlayerBean {

private int playerId;
private String playerName;
private LocalDate dateOfBirth;
private String country;
private String battingStyle;
private int centuries; 
private int matches;
private int age;
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
private long totalRun;
public int getPlayerId() {
	return playerId;
}
public void setPlayerId(int playerId) {
	this.playerId = playerId;
}
public String getPlayerName() {
	return playerName;
}
public void setPlayerName(String playerName) {
	this.playerName = playerName;
}
public LocalDate getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(LocalDate dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public String getBattingStyle() {
	return battingStyle;
}
public void setBattingStyle(String battingStyle) {
	this.battingStyle = battingStyle;
}
public int getCenturies() {
	return centuries;
}
public void setCenturies(int centuries) {
	this.centuries = centuries;
}
public int getMatches() {
	return matches;
}
public void setMatches(int matches) {
	this.matches = matches;
}
public long getTotalRun() {
	return totalRun;
}
public void setTotalRun(long totalRun) {
	this.totalRun = totalRun;
}

}

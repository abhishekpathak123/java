package com.capg.odicsapp.service;

import java.util.List;

import com.capg.odicsapp.dao.CricketScoreDaoImpli;
import com.capg.odicsapp.dao.ICricketScore;
import com.capg.odicsapp.dto.PlayerBean;
import com.capg.odicsapp.exception.CricketException;

public class CricketServiceImpli implements ICricketService {
ICricketScore cdao = new CricketScoreDaoImpli();

/*******************************************************************************************************
- Function Name	:	getAllPlayer()
- Input Parameters	:	null
- Return Type		:	List<PlayerBean>
- Throws			:  	CricketException
- Author			:	Abhishek Pathak
- Creation Date		:	07/11/2017
- Description		:	getting data from dao layer and passing it to controller
********************************************************************************************************/


	@Override
	public List<PlayerBean> getAllPlayer() throws CricketException {
		System.out.println("Returning Values");
		return cdao.getAllPlayer();
	}
	
	
	/*******************************************************************************************************
	- Function Name		:	insertPlayerDetails()
	- Input Parameters	:	PlayerBean pb
	- Return Type		:	int
	- Throws			:  	CricketException
	- Author			:	Abhishek Pathak
	- Creation Date		:	07/11/2017
	- Description		:	getting data from controller and passing it to Dao layer
	********************************************************************************************************/
	
	

	@Override
	public int insertPlayerDetails(PlayerBean pb) throws CricketException {
		// TODO Auto-generated method stub
		return cdao.insertPlayerDetails(pb);
	}

}

package com.capg.odicsapp.service;

import java.util.List;

import com.capg.odicsapp.dto.PlayerBean;
import com.capg.odicsapp.exception.CricketException;

public interface ICricketService {
	List <PlayerBean> getAllPlayer() throws CricketException;
	int insertPlayerDetails(PlayerBean pb)throws CricketException;
}

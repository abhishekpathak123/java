package com.capg.odicsapp.dao;

import java.util.List;

import com.capg.odicsapp.dto.PlayerBean;
import com.capg.odicsapp.exception.CricketException;

public interface ICricketScore {
	List <PlayerBean> getAllPlayer() throws CricketException;
	int insertPlayerDetails(PlayerBean pb)throws CricketException;
}

 package com.capg.odicsapp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import com.capg.odicsapp.dto.PlayerBean;
import com.capg.odicsapp.exception.CricketException;

public class CricketScoreDaoImpli implements ICricketScore {
	Connection conn;
	
	/*******************************************************************************************************
	 - Function Name	:	getAllPlayer()
	 - Input Parameters	:	null
	 - Return Type		:	List<PlayerBean>
	 - Throws			:  	CricketException
	 - Author			:	Abhishek Pathak
	 - Creation Date	:	07/11/2017
	 - Description		:	get players details from data base
	 ********************************************************************************************************/
	
	
	
	@Override
	public List<PlayerBean> getAllPlayer() throws CricketException {
		String sql = "select * from cricket_score";
		ArrayList<PlayerBean> mlist = new ArrayList<>();
		System.out.println("in getall players");
		conn = DBUtill.getConnection();
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			while (rst.next()) {
				
				PlayerBean pb = new PlayerBean();
				pb.setPlayerId(rst.getInt(1));
				pb.setPlayerName(rst.getString(2));
				pb.setDateOfBirth(rst.getDate(3).toLocalDate());
				
				pb.setCountry(rst.getString(4));
				pb.setBattingStyle(rst.getString(5));
				pb.setCenturies(rst.getInt(6));
				pb.setMatches(rst.getInt(7));
				pb.setTotalRun(rst.getLong(8));
				
				LocalDate oldDate = rst.getDate(3).toLocalDate();
				Period per = oldDate.until(LocalDate.now());
				pb.setAge((int)per.get(ChronoUnit.YEARS));
				
				mlist.add(pb);
			}

		} catch (SQLException e) {

		}

		return mlist;
	}
	
	
	
	
	/*******************************************************************************************************
	 - Function Name	:	insertPlayerDetails()
	 - Input Parameters	:	PlayerBean pb
	 - Return Type		:	int
	 - Throws			:  	CricketException
	 - Author			:	Abhishek Pathak
	 - Creation Date	:	07/11/2017
	 - Description		:	insert players details into data base
	 ********************************************************************************************************/
	
	

	@Override
	public int insertPlayerDetails(PlayerBean pb) throws CricketException {
		String sql = "insert into cricket_score values(player_seq.NEXTVAL,?,?,?,?,?,?,?)";
		int n;
		conn = DBUtill.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);

			pst.setString(1, pb.getPlayerName());
			pst.setDate(2, Date.valueOf(pb.getDateOfBirth()));
			pst.setString(3, pb.getCountry());
			pst.setString(4, pb.getBattingStyle());
			pst.setInt(5,pb.getCenturies());
			pst.setInt(6, pb.getMatches());
			pst.setLong(7, pb.getTotalRun());
			n =pst.executeUpdate();
		} catch (SQLException e) {
			throw new CricketException("problem is inserting data:"
					+ e.getMessage());

		}
		return n;
	}

}

package com.capg.odicsapp.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capg.odicsapp.exception.CricketException;

public class DBUtill {

	
		 private static Connection conn;
		 
		 /*******************************************************************************************************
		 - Function Name	:	getConnection()
		 - Input Parameters	:	null
		 - Return Type		:	Connection
		 - Throws			:  	CricketException
		 - Author			:	Abhishek Pathak
		 - Creation Date	:	07/11/2017
		 - Description		:	establishing connection with data base.
		 ********************************************************************************************************/
		
		 
		 
		public static  Connection getConnection()throws CricketException
		{
			if(conn== null){
				try{
					InitialContext ic = new InitialContext();
					DataSource ds = (DataSource) ic.lookup("java:/jdbc/TestDs");
					conn = ds.getConnection();
				}catch(NamingException e){
					throw new CricketException("problem in obtaining data source"+e.getMessage());
				}catch (SQLException e) {
					throw new CricketException("problem is obtaining connection"+e.getMessage());
				}
			}
			return conn;
		}
	}



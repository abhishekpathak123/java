package com.capg.odicsapp.controler;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capg.odicsapp.dto.PlayerBean;
import com.capg.odicsapp.exception.CricketException;
import com.capg.odicsapp.service.CricketServiceImpli;
import com.capg.odicsapp.service.ICricketService;

/**
 * Servlet implementation class CricketScoreController
 */
@WebServlet({ "/viewall", "/newPlayer", "/addplayer" })
public class CricketScoreController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String url = request.getServletPath();
		System.out.println(url);
		String target = "";

		ICricketService cser = new CricketServiceImpli();

		switch (url) {
		case "/viewall":
			try {
				List<PlayerBean> mlist = cser.getAllPlayer();
				System.out.println("After Fetching Values");
				request.setAttribute("mlist", mlist);
				System.out.println("Request Updated");
				for (PlayerBean m : mlist) {
					System.out.println(m.getCountry());
				}
				
				
				target = "ViewPlayers.jsp";
			} catch (CricketException e) {
				request.setAttribute("error", e.getMessage());
				target = "Error.jsp";
			}

			break;

		case "/newPlayer":

			target = "NewPlayer.jsp";

			break;

		case "/addplayer":
			

			String playerName = request.getParameter("playerName");
			String dateOfBirth = request.getParameter("dateOfBirth");
			String country = request.getParameter("country");
			String battingStyle = request.getParameter("battingStyle");
			String centuries = request.getParameter("centuries");
			String matches = request.getParameter("matches");
			String totalRun = request.getParameter("totalRun");
			
			
			

			PlayerBean pb = new PlayerBean();
			pb.setPlayerName(playerName);
			DateTimeFormatter format = DateTimeFormatter
					.ofPattern("yyyy-MM-dd");
			LocalDate fdate = LocalDate.parse(dateOfBirth, format);
			pb.setDateOfBirth(fdate);
			pb.setCountry(country);
			pb.setBattingStyle(battingStyle);
			pb.setCenturies(Integer.parseInt(centuries));
			pb.setMatches(Integer.parseInt(matches));
			pb.setTotalRun(Long.parseLong(totalRun));

			try {
				cser.insertPlayerDetails(pb);
				request.setAttribute("pb", pb);
				target = "InsertSucess.jsp";

			} catch (CricketException e) {
				request.setAttribute("error", e.getMessage());
				target = "Error.jsp";
			}
			
			break;
		
		}
		RequestDispatcher disp = request.getRequestDispatcher(target);
		disp.forward(request, response);
	}

}

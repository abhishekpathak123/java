/**
 * 
 * @author Administrator: Srinidhi.M
 * candidate no: 135295
 * project name: GameCity
 * Test : Module 3
 *
 */
package com.capgemini.gamecity.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.capgemini.gamecity.beans.GameBean;
import com.capgemini.gamecity.beans.UserBean;
import com.capgemini.gamecity.exception.GameCityException;
import com.capgemini.gamecity.utils.DBUtil;

public class GameCityDAOImpl implements IGameCityDAO {

	Connection connection = null;
	//preparing some objects for connection
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;

	@Override
	public void addUser(UserBean userBean) throws GameCityException {
		int rowCount = 0;

		try {
			//providing connection to database
			connection = DBUtil.getConnect();
			//providing connection to execute statement
			preparedStatement = connection
					.prepareStatement("INSERT INTO USERS VALUES(seq_users.NEXTVAL,?,?,?)");
			preparedStatement.setString(1, userBean.getUserName());
			preparedStatement.setString(2, userBean.getAddress());
			preparedStatement.setInt(3, userBean.getCardAmount());

			rowCount = preparedStatement.executeUpdate();

			if (rowCount == 0) {

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<GameBean> getGameDetails() throws GameCityException {
		List<GameBean> listGames = new ArrayList<>();

		try {
			//providing connection to database
			connection = DBUtil.getConnect();
			//providing connection to execute statement
			preparedStatement = connection
					.prepareStatement("SELECT * FROM ONLINEGAMES");
			resultSet = preparedStatement.executeQuery();

			int index = 0;
			while (resultSet.next()) {
				listGames.add(new GameBean(resultSet.getString("name"),
						resultSet.getInt("amount")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listGames;
	}

}

/**
 * 
 * @author Administrator: Srinidhi.M
 * candidate no: 135295
 * project name: GameCity
 * Test : Module 3
 *
 */
package com.capgemini.gamecity.service;

import java.util.List;

import com.capgemini.gamecity.beans.GameBean;
import com.capgemini.gamecity.beans.UserBean;
import com.capgemini.gamecity.dao.GameCityDAOImpl;
import com.capgemini.gamecity.dao.IGameCityDAO;
import com.capgemini.gamecity.exception.GameCityException;

public class GameCityServiceImpl implements IGameCityService {

	IGameCityDAO gameDAO = null;

	@Override
	public void addUser(UserBean userBean) throws GameCityException {
		gameDAO = new GameCityDAOImpl();
		gameDAO.addUser(userBean);
	}

	@Override
	public List<GameBean> getGameDetails() throws GameCityException {
		gameDAO = new GameCityDAOImpl();
		return gameDAO.getGameDetails();
	}

}

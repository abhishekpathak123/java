/**
 * 
 * @author Administrator: Srinidhi.M
 * candidate no: 135295
 * project name: GameCity
 * Test : Module 3
 *
 */
package com.capgemini.gamecity.beans;

//GameBean created for getting the details of user and the amount

public class GameBean {

	private String name;
	private int amount;

	public GameBean() {
		super();
	}

	public GameBean(String name, int amount) {
		super();
		this.name = name;
		this.amount = amount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

}

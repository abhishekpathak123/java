/**
 * 
 * @author Administrator: Srinidhi.M
 * candidate no: 135295
 * project name: GameCity
 * Test : Module 3
 *
 */
package com.capgemini.gamecity.beans;

//UserBean created for getting the user details

public class UserBean {
	private int userId;
	private String userName;
	private String address;
	private int cardAmount;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getCardAmount() {
		return cardAmount;
	}

	public void setCardAmount(int cardAmount) {
		this.cardAmount = cardAmount;
	}

}

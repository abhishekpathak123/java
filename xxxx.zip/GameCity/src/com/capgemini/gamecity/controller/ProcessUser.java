/**
 * 
 * @author Administrator: Srinidhi.M
 * candidate no: 135295
 * project name: GameCity
 * Test : Module 3
 *
 */
 package com.capgemini.gamecity.controller;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.gamecity.beans.GameBean;
import com.capgemini.gamecity.beans.UserBean;
import com.capgemini.gamecity.exception.GameCityException;
import com.capgemini.gamecity.service.GameCityServiceImpl;
import com.capgemini.gamecity.service.IGameCityService;

/**
 * Servlet implementation class ProcessUser
 */
@WebServlet("*.task")
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProcessUser() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (GameCityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (GameCityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, GameCityException {
		
		//Which form generated the request?
		String choose = request.getServletPath();

		HttpSession session = null;
		RequestDispatcher requestDispatcher = null;
		
		//Provide action according to a particular request
		switch (choose) {

		//In this switch case it is calling GameCity.jsp file for insert details of User 
		case "/register.task":
			UserBean userBean = new UserBean();
			userBean.setUserName(request.getParameter("name"));
			userBean.setAddress(request.getParameter("address"));
			userBean.setCardAmount(Integer.parseInt(request
					.getParameter("amount")) - 100);

			IGameCityService gameCityService = new GameCityServiceImpl();
			gameCityService.addUser(userBean);

			List<GameBean> listGame = null;
			listGame = gameCityService.getGameDetails();

			session = request.getSession();
			session.setAttribute("CardAmount", userBean.getCardAmount());
			session.setAttribute("GameList", listGame);

			requestDispatcher = request.getRequestDispatcher("Play.jsp");
			requestDispatcher.forward(request, response);

			break;
			
			
		//In this switch case it is calling Play.jsp file to view and select games			
		case "/playnow.task":

			int amount = Integer.parseInt(request.getParameter("amount"));

			GameBean gameBean = new GameBean();
			gameBean.setName(request.getParameter("game_name"));
			gameBean.setAmount(Integer.parseInt(request
					.getParameter("game_amount")));

			if (gameBean.getAmount() < amount) {
				session = request.getSession();
				session.setAttribute("CardAmount",
						amount - gameBean.getAmount());
				session.setAttribute("GameName", gameBean.getName());

				requestDispatcher = request.getRequestDispatcher("Success.jsp");
				requestDispatcher.forward(request, response);
			} else {
				session = request.getSession();
				session.setAttribute("GameName", gameBean.getName());

				requestDispatcher = request.getRequestDispatcher("Topup.jsp");
				requestDispatcher.forward(request, response);
			}

			break;
		}
	}
}

package com.capgemini.gamecity.utils;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.capgemini.gamecity.exception.GameCityException;


public class DBUtil {
	static Connection con;
	static{
		try
		{
			InitialContext context = new InitialContext();
			DataSource datasource = (DataSource)context.lookup("java:/jdbc/TestDs");
			con = datasource.getConnection();
			
		}catch(Exception e){
			try{
			throw new GameCityException(e.getMessage());
		}catch(Exception e1){
			e1.printStackTrace();
		}
			
			
		}
		
	}
	public static Connection getConnect() throws GameCityException{
		return con;
	}
}
		
	/*
	public static Connection getConnection() 
			throws NamingException, SQLException, ClassNotFoundException
	{
		Connection con= null;
		InitialContext ctx = new InitialContext();
		
		DataSource dataSource =(DataSource)ctx.lookup("java:/jdbc/TestDs");
		
		con = dataSource.getConnection();
		return con;
		
	}
}*/

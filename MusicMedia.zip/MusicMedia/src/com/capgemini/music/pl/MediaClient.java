package com.capgemini.music.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import oracle.net.ano.AuthenticationService;

import com.capgemini.music.service.AdminServiceImpl;
import com.capgemini.music.service.AuthenticationServiceImpl;
import com.capgemini.music.service.IAdminService;
import com.capgemini.music.service.IAuthenticationService;
import com.capgemini.music.service.IUserService;
import com.capgemini.music.service.UserServiceImpl;
import com.capgemini.musicMedia.bean.ArtistMaster;
import com.capgemini.musicMedia.bean.ComposerMaster;
import com.capgemini.musicMedia.bean.MusicSocietyMaster;
import com.capgemini.musicMedia.bean.SongMaster;
import com.capgemini.musicMedia.bean.UserMaster;
import com.capgemini.musicMedia.exception.MusicMediaException;

public class MediaClient {
	private static Scanner sc;
	private static IAuthenticationService authenticationService;
	private static IAdminService adminService;
	private static IUserService userService;
	private static Logger myLogger;
	private static UserMaster sessionUser=null;
	static {
		PropertyConfigurator
			.configure("resources/log4j.properties");
		myLogger = Logger
		.getLogger(MusicMediaException.class.getName());
	}
	static {
		authenticationService=new AuthenticationServiceImpl();
		adminService=new AdminServiceImpl();
		userService=new UserServiceImpl();
	}

	public static void main(String[] args) {
		int option = 0;
		Scanner sc = new Scanner(System.in);
		while (true) {
			// show menu
			showMenuLogin();
			// accept option
			try {
				option = sc.nextInt();
				switch (option) {
				case 1:
					login();
					break;
				case 2:
					exitApp();
					break;
				default:
					System.out.println("Enter a valid option[1-2]");
				}// end of switch

			} catch (InputMismatchException e) {
				// //myLogger.error("Please enter a numeric value, Try Again" +
				// e);
				sc.nextLine();
				System.err.println("Please enter a numeric value, Try Again");
			}
		}
	}

	private static void showMenuLogin() {
		System.out
				.println("\n_____________________________________________________________________________________________\n"
						+ "\n      				Music Media Application "
						+ "\n_____________________________________________________________________________________________\n"
						+ "\n      1.Login"
						+ "\n      2.Exit"
						+ "\n______________________________________________________________________________________________"
						+ "\nSelect an option:");

	}

	private static void exitApp() {
		System.out.println("Exit Music Media Application.");
		System.out.println("=============Thank You=================");
		System.exit(0);
	}

	private static void login() {
		sc = new Scanner(System.in);
		UserMaster userMaster = new UserMaster();
		// //Taking user-id as input
		System.out.println("Enter User-Id: ");
		int userId = sc.nextInt();
		while (true) {
			if (authenticationService.validateId(userId)) {
				break;
			} else {
				System.err
						.println("Please enter correct user id.. It must have 4 digit, Try Again");
				userId = sc.nextInt();
			}
		}
 
		// //Taking user password as input
		System.out.println("Enter Password: ");
		String userPassword = sc.next();

		// Setting id and password into object
		userMaster.setUserId(userId);
		userMaster.setUserPassword(userPassword);

		String type = authenticationService.authenticateUser(userMaster);
		try {
			switch (type) {
			case "Admin":sessionUser=userMaster;
						admin();
				break;
			case "User":sessionUser=userMaster;
						user();
				break;
			default:
				System.out.println("Invalid Login Credentials..");
				// return main menu
			}// end of switch

		} catch (InputMismatchException e) {
			// //myLogger.error(e);
		} catch (MusicMediaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void user() throws MusicMediaException {
		int userOption = 0;
		int flag = 0;
		while (true) {
			// show menu
			showMenuUser();
			// accept option
			try {
				userOption = sc.nextInt();
				switch (userOption) {
				case 1:
					searchByArtist();
					break;
				case 2:
					searchByComposer();
					break;
				case 3:
					searchByBoth();
					break;
				case 4:
					flag = 1;
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
				if (flag == 1)
					break;
			} catch (InputMismatchException e) {
				// //myLogger.error("Please enter a numeric value, Try Again" +
				// e);
				sc.nextLine();
				System.err.println("Please enter a numeric value, Try Again");
			}
		}

	}

	private static void searchByArtist() throws MusicMediaException {
		sc = new Scanner(System.in);
		String artist;
		System.out.println("Enter Artist Name: ");
		artist = sc.next();
		List<Object> list = userService.searchSongByArtist(artist);
		if(list.isEmpty())
			System.out.println("No Songs Found for artist "+artist);
		else{
			Object obj=list.get(0);
			if(obj instanceof String)
			{	System.out.println("\nNo composer/artist found with name"+artist);
				System.out.println("\nArtists/Composers Matching to "+artist+" are:");
				for(Object o:list)
					System.out.println((String)o);	
			}
			else{
				System.out.println("List of songs:");
				for(Object o:list)
					System.out.println((SongMaster)o);
			}
			
		}


	}

	private static void searchByComposer() throws MusicMediaException {
		sc = new Scanner(System.in);
		String composer;
		System.out.println("Enter Composer Name: ");
		composer = sc.next();
		List<Object> list = userService.searchSongByComposer(composer);
		if(list.isEmpty())
			System.out.println("No Songs Found for composer "+composer);
		else{
			Object obj=list.get(0);
			if(obj instanceof String)
			{	System.out.println("\nNo composer found with name"+composer);
				System.out.println("\nComposers Matching to "+composer+" are:");
				for(Object o:list)
					System.out.println((String)o);	
			}
			else{
				System.out.println("List of songs:");
				for(Object o:list)
					System.out.println((SongMaster)o);
			}
			
		}
	}

	private static void searchByBoth() throws MusicMediaException {
		sc = new Scanner(System.in);
		String name;
		System.out.println("Enter Composer/Artist Name: ");
		name = sc.next();
		List<Object> list = userService.searchSongByBoth(name);
		if(list.isEmpty())
			System.out.println("No Songs Found for artist/composer "+name);
		else{
			Object obj=list.get(0);
			if(obj instanceof String)
			{	System.out.println("\nNo artist/composer found with name"+name);
				System.out.println("\nArtists/Composers Matching to "+name+" are:");
				for(Object o:list)
					System.out.println((String)o);	
			}
			else{
				System.out.println("List of songs:");
				for(Object o:list)
					System.out.println((SongMaster)o);
			}
			
		}
	}

	private static void showMenuUser() {
		System.out
				.println("\n_____________________________________________________________________________________________\n"
						+ "\n      				Music Media Application "
						+ "\n_____________________________________________________________________________________________\n"
						+ "\n     "
						+ "\n		1.Search By Artist Name"
						+ "\n		2.Search By Composer Name"
						+ "\n		3.Search By Any Type"
						+ "\n		4.Log Out"
						+ "\n______________________________________________________________________________________________"
						+ "\nSelect an option:");

	}

	private static void admin() throws MusicMediaException {

		int adminOption = 0;
		int flag=0;
		while (true) {
			// show menu
			showMenuAdmin();
			// accept option
			try {
				adminOption = sc.nextInt();
				switch (adminOption) {
				case 1:
					addArtistDetails();
					break;
				case 2:
					editArtistDetails();
					break;
				case 3:
					searchArtist();
					break;
				case 4:
					associateSongWithArtist();
					break;
				case 5:
					addComposerDetails();
					break;
				case 6:
					editComposerDetails();
					break;
				case 7:
					searchComposer();
					break;
				case 8:
					associateSongWithComposer();
					break;
				case 9:
					flag=1;;
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch

			} catch (InputMismatchException e) {
				// //myLogger.error("Please enter a numeric value, Try Again" +
				// e);
				sc.nextLine();
				System.err.println("Please enter a numeric value, Try Again");
			}
		}

	}

	private static void addArtistDetails() throws MusicMediaException {
		sc=new Scanner(System.in);
		ArtistMaster artist=new ArtistMaster();
		System.out.println("Enter Artist Name: ");
		String name=sc.next();
		System.out.println("Enter Artist Type: ");
		String artistType=sc.next();
		System.out.println("Enter Artist's Birth date (dd/MM/yyyy): ");
		String bDate=sc.next();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate bornDate = LocalDate.parse(bDate, formatter);
		System.out.println("Enter Artist's Died date (dd/MM/yyyy): ");
		String dDate=sc.next();
		LocalDate diedDate = LocalDate.parse(dDate, formatter);
		//set values
		artist.setArtistName(name);
		artist.setArtistType(artistType);
		artist.setArtistBornDate(bornDate);
		artist.setArtistDiedDate(diedDate);
		
		//call service layer method---addArtistDetails()
		int artistId=adminService.addArtist(artist, sessionUser);
		if(artistId<0)
			System.err.println("Failed to add artist");
		else
			System.out.println("Artist has been added successfully with Artist Id: "+artistId);
		
	}

	private static void editArtistDetails() {
		
		
	}

	private static void searchArtist() throws MusicMediaException {
		// TODO Auto-generated method stub
		System.out.println("Enter Artist Name:");
		String artistName=sc.next();
		ArtistMaster artist=adminService.searchArtist(artistName);
		if(artist==null)
			System.out.println("No Artist Found With Name: "+artistName);
		else
			System.out.println(artist);
	}

	private static void associateSongWithArtist() throws MusicMediaException {
		sc=new Scanner(System.in);
		System.out.println("Enter Song Id: ");
		int songId=sc.nextInt();
		//validate songId(check if the song exists in songMaster table)
		System.out.println("Enter Artist Id: ");
		int artistId=sc.nextInt();
		//validate artistId(check if it exists in artistMaster table)
		
		//call service.associateSongWithArtist()
		int associationId=adminService.associateSongToArtist(songId, artistId, sessionUser);
		if(associationId>0)
		{	System.out.println("Artist and Song have been successfully associated");
			System.out.println("Association Id is:"+associationId);
		}
		else{
			System.err.println("Failed to associate artist and song");
		}
		
	}

	private static void addComposerDetails() throws MusicMediaException {
		sc=new Scanner(System.in);
		MusicSocietyMaster musicSociety=new MusicSocietyMaster();
		ComposerMaster composer=new ComposerMaster();
		System.out.println("Enter Composer Name: ");
		String name=sc.next();
		composer.setComposerName(name);
		System.out.println("Enter Composer's Birth date: ");
		String bDate=sc.next();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate bornDate = LocalDate.parse(bDate, formatter);
		composer.setComposerBornDate(bornDate);
		System.out.println("Enter Composer's Died date: ");
		String dDate=sc.next();
		LocalDate diedDate = LocalDate.parse(dDate, formatter);
		composer.setComposerDiedDate(diedDate);
		System.out.println("Enter Composer's Caeipi Number: ");
		String caeipiNumber=sc.next();
		composer.setCaeipiNumber(caeipiNumber);
		System.out.println("Enter Music Society Name: ");
		String musicSocietyName=sc.next();
		//call searchMusicSocity(musicSociety)
		String musicSocietyId=adminService.searchMusicSociety(musicSocietyName.toUpperCase());
		while(musicSocietyId==null){
			System.out.println("The Music Society you entered does not exist..\nDo you want to add this Music Society?(Yes/No)");
			String societyChoice=sc.next();
			if("YES".equals(societyChoice.toUpperCase())){
				musicSociety.setComposerMusicSocietyName(musicSocietyName);
				adminService.addMusicSociety(musicSociety);
			}
			else{
				System.out.println("Please enter correct Music Society Name:");
				musicSocietyName=sc.next();
				musicSocietyId=adminService.searchMusicSociety(musicSocietyName.toUpperCase());
			}
		}
		composer.setComposerMusicSocietyId(musicSocietyId);
		
		//call service layer method---addComposerDetails(composer)
		int composerId=adminService.addComposer(composer, sessionUser);
		if(composerId>0)
			System.out.println("Composer has been added successfully with ID:"+composerId);	
		else
			System.err.println("Failed to store composer details");
	}

	private static void editComposerDetails() {
		// TODO Auto-generated method stub
		
	}

	private static void searchComposer() throws MusicMediaException {
		// TODO Auto-generated method stub
		System.out.println("Enter Composer Name:");
		String composerName=sc.next();
		List<ComposerMaster> list=adminService.searchComposer(composerName);
		
		if(list.isEmpty())
			System.out.println("No Compser Found");
		else
		{	System.out.println("Composers matching to "+composerName+"are :");
			for (ComposerMaster composerMaster : list) {
				System.out.println(composerMaster);
			}
		}
	}

	private static void associateSongWithComposer() throws MusicMediaException {
		sc=new Scanner(System.in);
		System.out.println("Enter Song Id: ");
		int songId=sc.nextInt();
		//validate songId(check if the song exists in songMaster table)
		SongMaster song=adminService.searchSongById(songId);
		if(song==null)
		{	System.out.println("No Song Found with ID: "+songId);
			return;
		}
		System.out.println("Enter Composer Id: ");
		int composerId=sc.nextInt();
		//validate composerId(check if it exists in composerMaster table)
		ComposerMaster composer=adminService.searchComposerById(composerId);
		if(composer==null)
		{	System.out.println("No Composer Found with ID: "+composerId);
			return;
		}
		//call service.associateSongWithComposer()
		int associationId=adminService.associateSongToComposer(songId, composerId, sessionUser);
		
		if(associationId>0)
		{	System.out.println("Composer and Song have been successfully associated");
			System.out.println("Association Id is:"+associationId);
		}
		else{
			System.err.println("Failed to associate composer and song");
		}
	}

	private static void showMenuAdmin() {
		System.out.println("\n_____________________________________________________________________________________________\n"
				+ "\n      				Music Media Application "
				+ "\n_____________________________________________________________________________________________\n"
				+ "\n     "
				+ "\n		1. Add Artist Details"
				+ "\n		2. Edit Artist Details"
				+ "\n		3. Search For an Artist"
				+ "\n		4. Associate Song With Artist "
				+ "\n		5. Add Composer Details"
				+ "\n		6. Edit Composer Details"
				+ "\n		7. Search For a Composer"
				+ "\n		8. Associate Song With Composer"
				+ "\n		9.Log Out"
				+ "\n______________________________________________________________________________________________"
				+ "\nSelect an option:");
		
	}

}

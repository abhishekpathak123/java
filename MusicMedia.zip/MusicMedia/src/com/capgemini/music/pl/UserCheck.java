package com.capgemini.music.pl;

import java.util.List;

import com.capgemini.music.service.IUserService;
import com.capgemini.music.service.UserServiceImpl;
import com.capgemini.musicMedia.bean.ArtistMaster;
import com.capgemini.musicMedia.bean.ComposerMaster;
import com.capgemini.musicMedia.bean.SongMaster;
import com.capgemini.musicMedia.dao.AdminDaoImpl;
import com.capgemini.musicMedia.dao.IAdminDao;
import com.capgemini.musicMedia.exception.MusicMediaException;

public class UserCheck {
	public static void main(String[] args) throws MusicMediaException {
		//UserDao userDao=new UserDao();
		/*IUserService service=new UserServiceImpl();
		List<Object> list=service.searchSongByBoth("ubham");
		if(list.isEmpty())
			System.out.println("No song found for Shubham");
		else
		{
			Object obj=list.get(0);
			if(obj instanceof String)
			{	System.out.println("No composer/artist found like Shubham");
				System.out.println("Artists/Composers Matching to Shubham are:");
				for(Object o:list)
					System.out.println((String)o);	
			}
			else{
				System.out.println("List of songs:");
				for(Object o:list)
					System.out.println((SongMaster)o);
			}
		}*/
		
		IAdminDao dao=new AdminDaoImpl();
		/*ArtistMaster artist=new ArtistMaster();
		artist.setArtistId(5006);
		artist.setCreationId(5022);
		artist.setArtistName("LP");
		int update=dao.editArtist(artist, 1001);
		if(update>0)
			System.out.println("Update Successful");*/
		
		ComposerMaster c=new ComposerMaster();
		c.setComposerName("Shubham");
		c.setComposerMusicSocietyId("101");
		c.setComposerId(5004);
		int update=dao.editComposer(c, 1015);
		if(update>0)
			System.out.println("Update Successful");
		else if(update==-1)
			System.out.println("MusicSociety Not Present");
	}
}

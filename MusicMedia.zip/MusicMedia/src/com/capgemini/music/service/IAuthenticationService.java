package com.capgemini.music.service;

import com.capgemini.musicMedia.bean.UserMaster;

public interface IAuthenticationService {
	public String authenticateUser(UserMaster user);
	public boolean validateId(int userId);

}

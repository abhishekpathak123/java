package com.capgemini.music.service;

import java.util.List;

import com.capgemini.musicMedia.exception.MusicMediaException;

public interface IUserService {

public List<Object> searchSongByArtist(String artistName)throws MusicMediaException;
public List<Object> searchSongByComposer(String composerName)throws MusicMediaException;
public List<Object> searchSongByBoth(String name)throws MusicMediaException;
}

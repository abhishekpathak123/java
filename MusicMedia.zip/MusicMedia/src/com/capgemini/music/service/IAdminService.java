package com.capgemini.music.service;

import java.util.List;

import com.capgemini.musicMedia.bean.ArtistMaster;
import com.capgemini.musicMedia.bean.ComposerMaster;
import com.capgemini.musicMedia.bean.MusicSocietyMaster;
import com.capgemini.musicMedia.bean.SongMaster;
import com.capgemini.musicMedia.bean.UserMaster;
import com.capgemini.musicMedia.exception.MusicMediaException;

public interface IAdminService {
	public int addArtist(ArtistMaster artist,UserMaster user)throws MusicMediaException;
	public int editArtist(ArtistMaster artist,int adminId)throws MusicMediaException;
	public int editComposer(ComposerMaster composer,int adminId)throws MusicMediaException;
	public ArtistMaster searchArtist(String artistName)throws MusicMediaException;
	public int associateSongToArtist(int songId,int artistId,UserMaster user)throws MusicMediaException;
	public int addComposer(ComposerMaster composer,UserMaster user) throws MusicMediaException;
	public List<ComposerMaster> searchComposer(String composerName) throws MusicMediaException;
	public int associateSongToComposer(int songId,int composerId,UserMaster user) throws MusicMediaException;
	public String searchMusicSociety(String musicSocietyName) throws MusicMediaException;
	public void addMusicSociety(MusicSocietyMaster musicSociety);
	public SongMaster searchSongById(int songId);
	public ComposerMaster searchComposerById(int composerId);
}

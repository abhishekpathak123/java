package com.capgemini.music.service;

import java.util.List;

import com.capgemini.musicMedia.dao.IUserDao;
import com.capgemini.musicMedia.dao.UserDaoImpl;
import com.capgemini.musicMedia.exception.MusicMediaException;

public class UserServiceImpl implements IUserService {
	IUserDao userDao;
	
	public UserServiceImpl() {
		userDao=new UserDaoImpl();
	}
	@Override
	public List<Object> searchSongByArtist(String artistName)
			throws MusicMediaException {
		return userDao.searchSongByArtist(artistName);
	}

	@Override
	public List<Object> searchSongByComposer(String composerName)
			throws MusicMediaException {
		return userDao.searchSongByComposer(composerName);
	}

	@Override
	public List<Object> searchSongByBoth(String name)
			throws MusicMediaException {
		return userDao.searchSongByBoth(name);
	}

}

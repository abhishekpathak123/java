package com.capgemini.music.service;

import com.capgemini.music.service.IAuthenticationService;
import com.capgemini.musicMedia.bean.UserMaster;

public class AuthenticationServiceImpl implements IAuthenticationService {

	@Override
	public String authenticateUser(UserMaster user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validateId(int userId) {
		// TODO Auto-generated method stub
		return false;
	}

}

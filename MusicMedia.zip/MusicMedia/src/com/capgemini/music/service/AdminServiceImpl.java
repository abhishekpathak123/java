package com.capgemini.music.service;

import java.util.List;

import com.capgemini.musicMedia.bean.ArtistMaster;
import com.capgemini.musicMedia.bean.ComposerMaster;
import com.capgemini.musicMedia.bean.MusicSocietyMaster;
import com.capgemini.musicMedia.bean.SongMaster;
import com.capgemini.musicMedia.bean.UserMaster;
import com.capgemini.musicMedia.dao.AdminDaoImpl;
import com.capgemini.musicMedia.dao.IAdminDao;
import com.capgemini.musicMedia.exception.MusicMediaException;

public class AdminServiceImpl implements IAdminService{
	private static IAdminDao adminDao;
	
	static{
		adminDao=new AdminDaoImpl();
	}

	@Override
	public int addArtist(ArtistMaster artist, UserMaster user)
			throws MusicMediaException {
		// TODO Auto-generated method stub
		return adminDao.addArtist(artist, user);
	}

	@Override
	public int editArtist(ArtistMaster artist, int adminId)
			throws MusicMediaException {
		// TODO Auto-generated method stub
		return adminDao.editArtist(artist, adminId);
	}

	@Override
	public int editComposer(ComposerMaster composer, int adminId)
			throws MusicMediaException {
		// TODO Auto-generated method stub
		return adminDao.editComposer(composer, adminId);
	}

	@Override
	public ArtistMaster searchArtist(String artistName)
			throws MusicMediaException {
		// TODO Auto-generated method stub
		return adminDao.searchArtist(artistName);
	}

	@Override
	public int associateSongToArtist(int songId, int artistId, UserMaster user)
			throws MusicMediaException {
		// TODO Auto-generated method stub
		return adminDao.associateSongToArtist(songId, artistId, user);
	}

	@Override
	public int addComposer(ComposerMaster composer,UserMaster user) throws MusicMediaException {
		return adminDao.addComposer(composer,user);
	}


	@Override
	public List<ComposerMaster> searchComposer(String composerName)
			throws MusicMediaException {
		// TODO Auto-generated method stub
		return adminDao.searchComposer(composerName);
	}

	@Override
	public int associateSongToComposer(int songId, int composerId,UserMaster user)
			throws MusicMediaException {
		// TODO Auto-generated method stub
		return adminDao.associateSongToComposer(songId, composerId, user);
	}

	@Override
	public String searchMusicSociety(String musicSocietyName)
			throws MusicMediaException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addMusicSociety(MusicSocietyMaster musicSociety) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public SongMaster searchSongById(int songId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ComposerMaster searchComposerById(int composerId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}

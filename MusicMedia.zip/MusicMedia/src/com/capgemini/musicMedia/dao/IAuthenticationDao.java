package com.capgemini.musicMedia.dao;

import com.capgemini.musicMedia.bean.UserMaster;

public interface IAuthenticationDao {
	public String authenticateUser(UserMaster user);
}

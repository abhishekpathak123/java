package com.capgemini.musicMedia.dao;

import com.capgemini.musicMedia.bean.UserMaster;

public class AuthenticationDaoImpl implements IAuthenticationDao {

	@Override
	public String authenticateUser(UserMaster user) {
		// TODO Auto-generated method stub
		return null;
	}

}

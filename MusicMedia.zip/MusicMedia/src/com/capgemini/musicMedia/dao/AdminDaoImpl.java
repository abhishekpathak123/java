/**
 * 
 */
package com.capgemini.musicMedia.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;






//import com.capgemini.music.bean.ComposerMaster;
import com.capgemini.musicMedia.bean.ArtistMaster;
import com.capgemini.musicMedia.bean.ComposerMaster;
import com.capgemini.musicMedia.bean.MusicSocietyMaster;
import com.capgemini.musicMedia.bean.SongMaster;
import com.capgemini.musicMedia.bean.UserMaster;
import com.capgemini.musicMedia.exception.MusicMediaException;
import com.capgemini.musicMedia.util.DBUtil;

/**
 * @author anihalde
 *
 */
public class AdminDaoImpl implements IAdminDao {
	// declaring Connection and Logger variables
	static Connection connection;
	private static Logger myLogger = null;
	// static blog for logger code
	static {
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(AdminDaoImpl.class.getName());
	}

	// obtain connection in the constructor
	public AdminDaoImpl() {
		try {
			connection = new DBUtil().obtainConnection();
			myLogger.info("Connection Obtained ... at DAO");
		} catch (MusicMediaException e) {
			myLogger.error("ERROR : " + e);
			System.err.println(e.getMessage());
		}
	}

	@Override
	public int addArtist(ArtistMaster artist, UserMaster user)
			throws MusicMediaException {
		myLogger.info("addArtist() invoked in artistDaoImpl!!");
		System.out.println("Adding Artist record.... Kindly have patience!!");
		String sql = "insert into Artist_Master values(artist_id_seq.NEXTVAL,?,?,?,?,?,?)";
		PreparedStatement pst = null;
		int creationId = insertCreationDetails(user);

		int result = 0;
		int artistId = 0;
		try {// obtain ps
			pst = connection.prepareStatement(sql);
			// connection.setAutoCommit(false);// transaction starts

			// set the values for place holders
			pst.setString(1, artist.getArtistName());
			pst.setString(2, artist.getArtistType());
			pst.setDate(3,Date.valueOf(artist.getArtistBornDate()));
			
			pst.setDate(4,Date.valueOf(artist.getArtistDiedDate()));
            
			pst.setInt(5, 0);
			pst.setInt(6, creationId);

			result = pst.executeUpdate();
			if (result > 0) {
				artistId = getUniqueArtistId();

				myLogger.info("Artist details getting inserted "
						+ "....unique traineeId : " + artistId);

				// if insert successful the commit the
			} // transaction
		} catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Inserting Artist failed  "
					+ e.getMessage());
			throw new MusicMediaException("ERRROR :  Inserting Artist failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Inserting Artist failed "
						+ e.getMessage());
				throw new MusicMediaException(
						"ERRROR : Inserting Artist failed " + e.getMessage());
			}
		}
		return artistId;
	}

	private int insertCreationDetails(UserMaster user)
			throws MusicMediaException {
		PreparedStatement pst = null;
		int creationId=0;
		String sql = "insert into Creation_Master values(creation_id_seq.NEXTVAL,?,SYSDATE,?,null)";

		int result = 0;
		try {// obtain ps
			pst = connection.prepareStatement(sql);
			pst.setInt(1, user.getUserId());
			pst.setInt(2, user.getUserId());
			result=pst.executeUpdate();
			if(result>0)
				creationId = getUniqueCreationId();
		} catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Inserting Creation failed  "
					+ e.getMessage());
			throw new MusicMediaException(
					"ERRROR :  Inserting Creation failed  " + e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback

			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Inserting Creation failed "
						+ e.getMessage());
				throw new MusicMediaException(
						"ERRROR : Inserting Creation Creation "
								+ e.getMessage());
			}
		}
		return creationId;
	}
	
	private int getUniqueArtistId() throws MusicMediaException {
		myLogger.info("Generating unique CreationId");
		String sql = "SELECT artist_id_seq.CURRVAL FROM dual";
		int artistId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				artistId = rs.getInt(1);
				myLogger.info("auto-generated artistId by sequence : "
						+ artistId);
			} else {
				myLogger.error("artistId not auto generated , error occured ");
			}
		} catch (SQLException e) {
			myLogger.error("artistId not auto generated , error occured : "
					+ e.getMessage());
			throw new MusicMediaException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("CustomerId not auto generated , error occured :"
						+ e.getMessage());
				throw new MusicMediaException(e.getMessage());
			}
		}
		return artistId;
	}
	
	private int getUniqueCreationId() throws MusicMediaException {
		myLogger.info("Generating unique CreationId");
		String sql = "SELECT creation_id_seq.currval FROM dual";
		int creationId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				creationId = rs.getInt(1);
				myLogger.info("auto-generated creationId by sequence : "
						+ creationId);
			} else {
				myLogger.error("creationId not auto generated , error occured ");
			}
		} catch (SQLException e) {
			myLogger.error("creationId not auto generated , error occured : "
					+ e.getMessage());
			throw new MusicMediaException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("CustomerId not auto generated , error occured :"
						+ e.getMessage());
				throw new MusicMediaException(e.getMessage());
			}
		}
		return creationId;
	}
	
	@Override
	public int editArtist(ArtistMaster artist,int adminId) throws MusicMediaException {
		artist.setCreationId(getArtistCreationId(artist.getArtistId()));
		String sql="UPDATE ARTIST_MASTER SET";
		int res=0;
		if(artist.getArtistName()!=null)
			sql+=" artist_name=?";
		boolean flag=false;
		if(artist.getArtistType()!=null)
		{
			if(flag)
				sql+=",";
			sql+=" artist_type=?";
			flag=true;
		}
		if(artist.getArtistBornDate()!=null)
		{
			if(flag)
				sql+=",";
			sql+=" artist_borndate=?";
			flag=true;
		}
		if(artist.getArtistDiedDate()!=null)
		{
			if(flag)
				sql+=",";
			sql+=" artist_dieddate=?";
			flag=true;
		}
		if(artist.isArtistDeletedFlag())
		{
			if(flag)
				sql+=",";
			sql+=" artist_deletedflag=?";
		}
		sql+=" WHERE artist_id=?";
		
		int count=1;
		PreparedStatement ps=null;
		
		try {
			ps=connection.prepareStatement(sql);
			if(artist.getArtistName()!=null){
				ps.setString(count, artist.getArtistName());
				count++;
			}
			if(artist.getArtistType()!=null)
			{
				ps.setString(count,artist.getArtistType());
				count++;
			}
			if(artist.getArtistBornDate()!=null){
				ps.setDate(count,Date.valueOf(artist.getArtistBornDate()));
				count++;
			}
			if(artist.getArtistDiedDate()!=null){
				ps.setDate(count,Date.valueOf(artist.getArtistDiedDate()));
				count++;
			}
			if(artist.isArtistDeletedFlag())
			{	
				ps.setInt(count, 1);
				count++;
			}
			ps.setInt(count, artist.getArtistId());
			res=ps.executeUpdate();
			if(res>0)
			{
				sql="UPDATE CREATION_MASTER SET UPDATED_BY=?, UPDATED_ON=? WHERE CREATION_ID=?";
				ps=connection.prepareStatement(sql);
				ps.setInt(1, adminId);
				ps.setDate(2, Date.valueOf(LocalDate.now()));
				ps.setInt(3, artist.getCreationId());
				res=ps.executeUpdate();				
			}	
			
		} catch (SQLException e) {	
			e.printStackTrace();
		}
		return res;
	}
	
	@Override
	public ArtistMaster searchArtist(String artistName)
			throws MusicMediaException {
		myLogger.info("searchArtist() in ArtistDaoImpl invoked!!");
		String sql = "SELECT * FROM Artist_Master WHERE Artist_Name=?";
		ArtistMaster artist = null;
		PreparedStatement pst = null;
		try {
			// obtaining pst
			pst = connection.prepareStatement(sql);
			pst.setString(1, artistName);// setting the artistId
			ResultSet rs = pst.executeQuery();// executing the sql
			if (rs.next()) {
				myLogger.info("Artist record found ");
				// create the object of trainee
				artist = new ArtistMaster();
				// mapping the value from db to trainee object
				artist.setArtistId(rs.getInt(1));
				artist.setArtistName(rs.getString(2));
				artist.setArtistBornDate(rs.getDate(3).toLocalDate());
				artist.setArtistDiedDate(rs.getDate(4).toLocalDate());
				artist.setArtistDeletedFlag(rs.getInt(5)==1);
				artist.setCreationId(rs.getInt(6));

			} else {
				myLogger.error("ERRROR " + "ArtistId does Not Exits");
				throw new MusicMediaException("ArtistId does Not Exits , ");
			}
		} catch (SQLException e) {
			myLogger.error("ERRROR " + "Searching ArtistMaster details failed "
					+ e.getMessage());
			throw new MusicMediaException(
					"Searching ArtistMaster details failed " + e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ERRROR "
						+ "Searching ArtistMaster details failed "
						+ e.getMessage());
				throw new MusicMediaException(
						"Searching ArtistMaster details failed "
								+ e.getMessage());
			}
		}
		return artist;
	}

	@Override
	public int associateSongToArtist(int songId, int artistId, UserMaster user)
			throws MusicMediaException {
		myLogger.info("associateSongToArtist() invoked in AdminDaoImpl!!");
		System.out.println("associating record.... Kindly have patience!!");
		String sql = "insert into Artist_Song_Assoc values(?,?,?)";
		PreparedStatement pst = null;
		
		int result = 0;
		int searchDuplicate=searchAssociateSongToArtist(songId,artistId);
		if(searchDuplicate==1)
		{
			return -1;
		}
		int creationId = insertCreationDetails(user);
		try {// obtain ps
			
			pst = connection.prepareStatement(sql);
			// connection.setAutoCommit(false);// transaction starts

			// set the values for place holders
			pst.setInt(1, artistId);
			pst.setInt(2, songId);
			pst.setInt(3, creationId);
			result = pst.executeUpdate();
			if (result > 0) {
				// artistId = getUniqueArtistId();

				myLogger.info("Artist details getting inserted "
						+ "....unique traineeId : " + artistId);

				// if insert successful the commit the
			} // transaction
		} catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Inserting Artist failed  "
					+ e.getMessage());
			throw new MusicMediaException("ERRROR :  Inserting Artist failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Inserting Artist failed "
						+ e.getMessage());
				throw new MusicMediaException(
						"ERRROR : Inserting Artist failed " + e.getMessage());
			}
		}
		return creationId;

	}
	
	private static int searchAssociateSongToArtist(int i, int j)
			throws MusicMediaException {
		myLogger.info("searchTrainee() in TraineeDaoImpl invoked!!");
		String sql = "SELECT * FROM Artist_Song_Assoc WHERE Artist_Id=? and  Song_Id=?";
		PreparedStatement pst = null;
		int c = 0;
		System.out.println(i + "   " + j);

		try {
			// obtaining pst
			pst = connection.prepareStatement(sql);
			pst.setInt(1, i);
			pst.setInt(2, j);
			// setting the traineeId
			ResultSet rs = pst.executeQuery();// executing the sql
			if(rs.next()) {
				//logger
				return 1;
				

			}

		} catch (SQLException e) {
			myLogger.error("ERRROR " + "Searching ArtistMaster details failed "
					+ e.getMessage());
			throw new MusicMediaException(
					"Searching ArtistMaster details failed " + e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ERRROR "
						+ "Searching ArtistMaster details failed "
						+ e.getMessage());
				throw new MusicMediaException(
						"Searching ArtistMaster details failed "
								+ e.getMessage());
			}
		}
		System.out.println(c + "   dfhdu");
		return 0;
	}
	
	@Override
	public int addComposer(ComposerMaster composer,UserMaster user) throws MusicMediaException {//creation_id_seq.NEXTVAL
		
		String sql="INSERT INTO composer_master VALUES(composer_id_seq.NEXTVAL,?,?,?,?,?,?,?)";
		//AdminDaoImpl daoImpl = new AdminDaoImpl();
		PreparedStatement pst = null;
		int insertRec=0;
		int cid=0;
		
		try{
			
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);	// transaction starts
			int creationId = insertCreationDetails(user);
			pst.setString(1, composer.getComposerName());
			pst.setDate(2,Date.valueOf(composer.getComposerBornDate()));
			pst.setDate(3,Date.valueOf(composer.getComposerDiedDate()));
			pst.setString(4, composer.getCaeipiNumber());
			pst.setString(5,composer.getComposerMusicSocietyId());
			pst.setInt(6,0);
			pst.setInt(7,creationId);
			
			//WE have to call insertCreationDetails(UserMaster user);
			
			insertRec=pst.executeUpdate();
			if(insertRec>0){
				cid = generateComposerId();
				}
			else{
				myLogger.error("Adding Composer Failed!");
			}
			connection.commit();
		}catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Adding Composer Failed! "
					+ e.getMessage());
			throw new MusicMediaException("ERRROR :  Adding Composer Failed!  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Adding Composer Failed! "
						+ e.getMessage());
				throw new MusicMediaException(
						"ERRROR : Adding Composer Failed! " + e.getMessage());
			}
		}
		return cid;
	}

	private int generateComposerId() throws MusicMediaException{
		String sql="SELECT composer_id_seq.CURRVAL FROM dual";
		PreparedStatement pst=null;
		ResultSet rs;
		try{
			pst=connection.prepareStatement(sql);
			
			rs=pst.executeQuery();
			rs.next();
			
			return rs.getInt(1);
		}catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Sequence not found! "
					+ e.getMessage());
			throw new MusicMediaException("ERRROR :  Sequence not found!  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Sequence not found! "
						+ e.getMessage());
				throw new MusicMediaException(
						"ERRROR : Sequence not found! " + e.getMessage());
			}
		}
	}

	@Override
	public List<ComposerMaster> searchComposer(String composerName)
			throws MusicMediaException {
		ArrayList<ComposerMaster> composerList = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		ComposerMaster composers = null;
		String sql = "SELECT * FROM composer_master WHERE composer_name LIKE ? ";
		try {
			
			pst = connection.prepareStatement(sql);
			pst.setString(1, "%"+composerName+"%");
			rs = pst.executeQuery();
			composerList = new ArrayList<>();
			while (rs.next()) {
				composers = new ComposerMaster();
				
				composers.setCreationId(rs.getInt("Composer_id"));
				composers.setComposerName(rs.getString("Composer_Name"));
				java.sql.Date sqlDate=rs.getDate("Composer_BornDate");
				LocalDate orderDate = sqlDate.toLocalDate();
				composers.setComposerBornDate(orderDate);
				
				java.sql.Date sqlDate2=rs.getDate("Composer_DiedDate");
				LocalDate orderDate2 = sqlDate2.toLocalDate();
				composers.setComposerBornDate(orderDate2);
				composers.setComposerDiedDate(rs.getDate(4).toLocalDate());
				composers.setCaeipiNumber(rs.getString("Composer_CaeipiNumber"));
				composers.setComposerMusicSocietyId(rs.getString("Composer_MusicSocietyID"));
				composers.setComposerDeletedFlag(rs.getInt("Composer_DeletedFlag")==1);
				composers.setCreationId(rs.getInt("creation_id"));
				
				composerList.add(composers);
			}
		} catch (SQLException e) {
			myLogger.error("ComposerList not found , error occured : "
					+ e.getMessage());
			e.printStackTrace();
			throw new MusicMediaException(e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ComposerList not found , error occured :"
						+ e.getMessage());
				throw new MusicMediaException(e.getMessage());
			}
		}
		return composerList;
	}
	
	@Override
	public int associateSongToComposer(int songId, int composerId,UserMaster user)
			throws MusicMediaException {
		
		String sql="INSERT INTO Composer_Song_Assoc VALUES(?,?,?)";
		//AdminDaoImpl daoImpl = new AdminDaoImpl();
		PreparedStatement pst = null;
		int insertRec=0;
		int cid=0;
		int searchDuplicate=searchAssociateSongToComposer(songId,composerId);
		if(searchDuplicate==1)
		{
		return -1;
		}
		int creationId = insertCreationDetails(user);
		try{
			
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);	// transaction starts
			
			pst.setInt(1, composerId);
			pst.setInt(2, songId);
			
			/*
			//---  WE have to call insertCreationDetails(UserMaster user); ---//
			*/
			
			insertRec = pst.executeUpdate();
			if(insertRec>0){
				cid = 1;
				}
			else{
				myLogger.error("Associating Composer To Song Failed!");
			}
			connection.commit();
		}catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Associating Composer To Song Failed! "
					+ e.getMessage());
			throw new MusicMediaException("ERRROR :  Associating Composer To Song Failed!  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Associating Composer To Song Failed! "
						+ e.getMessage());
				throw new MusicMediaException(
						"ERRROR : Associating Composer To Song Failed! " + e.getMessage());
			}
		}
		return cid;
	}
	
	private int searchAssociateSongToComposer(int songId, int composerId)throws MusicMediaException{
		myLogger.info("searchAssociateSongToComposer() in AdminDaoImpl invoked!!");
		String sql = "SELECT * FROM Composer_Song_Assoc WHERE Composer_Id=? and  Song_Id=?";
		PreparedStatement pst = null;

		try {
			// obtaining pst
			pst = connection.prepareStatement(sql);
			pst.setInt(1, composerId);
			pst.setInt(2, songId);
			// setting the traineeId
			ResultSet rs = pst.executeQuery();// executing the sql
			if(rs.next()) {
				//logger
				return 1;
				

			}

		} catch (SQLException e) {
			myLogger.error("ERRROR " + "Searching Association details failed "
					+ e.getMessage());
			throw new MusicMediaException(
					"Searching Association details failed " + e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ERRROR "
						+ "Searching Association details failed "
						+ e.getMessage());
				throw new MusicMediaException(
						"Searching Association details failed "
								+ e.getMessage());
			}
		}
		
		return 0;
	}
	

	@Override
	public int editComposer(ComposerMaster composer, int adminId){
	composer.setCreationId(getComposerCreationId(composer.getComposerId()));
	String sql="UPDATE COMPOSER_MASTER SET";
	int res=0;
	boolean flag=false;
	if(composer.getComposerName()!=null)
	{	sql+=" composer_name=?";
		flag=true;
	}
	if(composer.getComposerBornDate()!=null)
	{
		if(flag)
			sql+=",";
		sql+=" comopser_borndate=?";
		flag=true;
	}
	if(composer.getComposerDiedDate()!=null)
	{
		if(flag)
			sql+=",";
		sql+=" composer_dieddate=?";
		flag=true;
	}
	if(composer.getCaeipiNumber()!=null)
	{
		if(flag)
			sql+=",";
		sql+=" composer_caeipinumber=?";
		flag=true;
	}
	if(composer.getComposerMusicSocietyId()!=null)
	{	if(validateMusicSociety(composer.getComposerMusicSocietyId())==0)
			return -1;
		if(flag)
			sql+=",";
		sql+=" composer_musicsocietyid=?";
		flag=true;
	}
	if(composer.isComposerDeletedFlag())
	{
		if(flag)
			sql+=",";
		sql+=" composer_deletedflag=?";
	}
	sql+=" WHERE composer_id=?";
	
	int count=1;
	PreparedStatement ps=null;
	
	try {
		ps=connection.prepareStatement(sql);
		if(composer.getComposerName()!=null){
			ps.setString(count, composer.getComposerName());
			count++;
		}
		if(composer.getComposerBornDate()!=null){
			ps.setDate(count,Date.valueOf(composer.getComposerBornDate()));
			count++;
		}
		if(composer.getComposerDiedDate()!=null){
			ps.setDate(count,Date.valueOf(composer.getComposerDiedDate()));
			count++;
		}
		if(composer.getCaeipiNumber()!=null){
			ps.setString(count, composer.getCaeipiNumber());
			count++;
		}
		if(composer.getComposerMusicSocietyId()!=null){
			ps.setString(count, composer.getComposerMusicSocietyId());
			count++;
		}
		if(composer.isComposerDeletedFlag())
		{	
			ps.setInt(count, 1);
			count++;
		}
		ps.setInt(count, composer.getComposerId());
		res=ps.executeUpdate();
		if(res>0)
		{
			sql="UPDATE CREATION_MASTER SET UPDATED_BY=?, UPDATED_ON=? WHERE CREATION_ID=?";
			ps=connection.prepareStatement(sql);
			ps.setInt(1, adminId);
			ps.setDate(2, Date.valueOf(LocalDate.now()));
			ps.setInt(3, composer.getCreationId());
			res=ps.executeUpdate();				
		}	
		
	} catch (SQLException e) {	
		e.printStackTrace();
	}
	return res;
	}
	
	private int getArtistCreationId(int artistId){
		String sql="SELECT creation_Id FROM artist_master where artist_id=?";
		PreparedStatement ps=null;
		ResultSet rs=null;
		int creationId=0;
		try {
			ps= connection.prepareStatement(sql);
			ps.setInt(1, artistId);
			rs=ps.executeQuery();
			if(rs.next())
				creationId=rs.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return creationId;
	}

	private int getComposerCreationId(int composerId){
		String sql="SELECT creation_Id FROM composer_master where composer_id=?";
		PreparedStatement ps=null;
		ResultSet rs=null;
		int creationId=0;
		try {
			ps= connection.prepareStatement(sql);
			ps.setInt(1, composerId);
			rs=ps.executeQuery();
			if(rs.next())
				creationId=rs.getInt(1);
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
	return creationId;
	}
	
	private int validateMusicSociety(String id){
		String sql="SELECT * FROM musicsociety_master where composer_musicsocietyId=?";
		PreparedStatement ps=null;
		ResultSet rs=null;
		int res=0;
		try {
			ps= connection.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
			if(rs.next())
				res=1;
			} catch (SQLException e) {
			e.printStackTrace();
			}
		return res;
	}

	@Override
	public String searchMusicSociety(String musicSocietyName)
			throws MusicMediaException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addMusicSociety(MusicSocietyMaster musicSociety) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public SongMaster searchSongById(int songId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ComposerMaster searchComposerById(int composerId) {
		// TODO Auto-generated method stub
		return null;
	}
}
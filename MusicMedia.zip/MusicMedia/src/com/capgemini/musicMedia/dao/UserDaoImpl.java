package com.capgemini.musicMedia.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.musicMedia.bean.SongMaster;
import com.capgemini.musicMedia.exception.MusicMediaException;
import com.capgemini.musicMedia.util.DBUtil;


public class UserDaoImpl implements IUserDao {
	private Connection connection;
	private static Logger myLogger = null;
	
	static {
		PropertyConfigurator
			.configure("resources/log4j.properties");
		myLogger = Logger
		.getLogger(MusicMediaException.class.getName());
	}
	
	public UserDaoImpl() {
		try {
			connection = new DBUtil().obtainConnection();
			myLogger.info("Connection Obtained ... at DAO");
		} catch (MusicMediaException e) {
			myLogger.error("ERROR : " + e);
			System.err.println(e.getMessage());
		}
	}
	
	@Override
	public List<Object> searchSongByArtist(String artistName) throws MusicMediaException {
		myLogger.info("searchSongByArtist() invoked in UserDao");
		int artistId=searchArtist(artistName);
		ArrayList<Object> list=new ArrayList<Object>();
		if(artistId==0)
		{
			String query="Select artist_name from artist_master where artist_name like ?";
			PreparedStatement ps=null;
			ResultSet rs=null;
			try {
				ps=connection.prepareStatement(query);
				ps.setString(1, "%"+artistName+"%");
				rs=ps.executeQuery();
				while(rs.next())
				{
					list.add(rs.getString(1));
				}
			} catch (SQLException e) {
					myLogger.error("ERRROR : Failed to fetch data from artist_master "
							+ e.getMessage());
					throw new MusicMediaException("ERRROR :  Failed to fetch data from artist_maste  "
							+ e.getMessage());
			}
			
		}
		else
		{
			String query="Select sm.song_id, song_name, to_char(song_duration,'MI:SS'), "
					+ "song_deletedflag, sm.creation_id "
					+ "from song_master sm, artist_song_assoc assoc "
					+ "where sm.song_id=assoc.song_id "
					+ "and assoc.artist_id=?";
			PreparedStatement ps=null;
			ResultSet rs=null;
			SongMaster songMaster=null;
			try {
				ps=connection.prepareStatement(query);
				ps.setInt(1, artistId);
				rs=ps.executeQuery();
				while(rs.next())
				{	songMaster=new SongMaster();
					songMaster.setSongId(rs.getInt(1));
					songMaster.setSongName(rs.getString(2));
					songMaster.setSongDuration(rs.getString(3));
					songMaster.setSongDeletedFlag(rs.getInt(4)==1);
					songMaster.setCreationId(rs.getInt(5));
					list.add(songMaster);
				}
			} catch (SQLException e) {
				myLogger.error("ERRROR : Failed to fetch Song information "
						+ e.getMessage());
				throw new MusicMediaException("ERRROR :  Failed to fetch Song information"
						+ e.getMessage());
			}
		}
		return list;
	}
	

	@Override
	public List<Object> searchSongByComposer(String composerName) throws MusicMediaException{
		myLogger.info("searchSongByComposer() invoked in UserDao");
		int composerId=searchComposer(composerName);
		ArrayList<Object> list=new ArrayList<Object>();
		if(composerId==0)
		{
			String query="Select composer_name from composer_master where composer_name like ?";
			PreparedStatement ps=null;
			ResultSet rs=null;
			try {
				ps=connection.prepareStatement(query);
				ps.setString(1, "%"+composerName+"%");
				rs=ps.executeQuery();
				while(rs.next())
				{
					list.add(rs.getString(1));
				}
			} catch (SQLException e) {
					myLogger.error("ERRROR : Failed to fetch data from composer_master "
							+ e.getMessage());
					throw new MusicMediaException("ERRROR :  Failed to fetch data from composer_master  "
							+ e.getMessage());
			}
			
		}
		else
		{
			String query="Select sm.song_id, song_name, to_char(song_duration,'MI:SS'), "
					+ "song_deletedflag, sm.creation_id "
					+ "from song_master sm, composer_song_assoc assoc "
					+ "where sm.song_id=assoc.song_id "
					+ "and assoc.composer_id=?";
			PreparedStatement ps=null;
			ResultSet rs=null;
			SongMaster songMaster=null;
			try {
				ps=connection.prepareStatement(query);
				ps.setInt(1, composerId);
				rs=ps.executeQuery();
				while(rs.next())
				{	songMaster=new SongMaster();
					songMaster.setSongId(rs.getInt(1));
					songMaster.setSongName(rs.getString(2));
					songMaster.setSongDuration(rs.getString(3));
					songMaster.setSongDeletedFlag(rs.getInt(4)==1);
					songMaster.setCreationId(rs.getInt(5));
					list.add(songMaster);
				}
			} catch (SQLException e) {
				myLogger.error("ERRROR : Failed to fetch Song information "
						+ e.getMessage());
				throw new MusicMediaException("ERRROR :  Failed to fetch Song information"
						+ e.getMessage());
			}
		}
		return list;
	}
	

	@Override
	public List<Object> searchSongByBoth(String name) throws MusicMediaException{
		List<Object> list=new ArrayList<Object>();
		List<Object> artistSongs=searchSongByArtist(name);
		List<Object> composerSongs=searchSongByComposer(name);
		if(artistSongs.isEmpty())
			return composerSongs;
		if(composerSongs.isEmpty())
			return artistSongs;
		Object artistSong=artistSongs.get(0);
		Object composerSong=composerSongs.get(0);
		if(artistSong instanceof String)
		{
			if(composerSong instanceof String)
			{
				list.addAll(artistSongs);
				list.addAll(composerSongs);
			}
			else
			return composerSongs;
		}
		else{
			if(composerSong instanceof String)
				return artistSongs;
			list.addAll(artistSongs);
			list.addAll(composerSongs);
		}
		return list;
	}
	

	private int searchArtist(String artistName) throws MusicMediaException{
		myLogger.info("searchArtist() invoked in UserDao");
		int artistId=0;
		String query="Select artist_id from artist_master where artist_name=?";
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			ps=connection.prepareStatement(query);
			ps.setString(1, artistName);
			rs=ps.executeQuery();
			if(rs.next())
				artistId=rs.getInt(1);
			else
				myLogger.info("No artist found with name: "+artistName);
		} catch (SQLException e) {
			myLogger.error("ERRROR : Failed to fetch data from artist_master "
					+ e.getMessage());
			throw new MusicMediaException("ERRROR :  Failed to fetch data from artist_master  "
					+ e.getMessage());
		}	
		return artistId;
	}
	
	
	private int searchComposer(String composerName) throws MusicMediaException{
		myLogger.info("searchComposer() invoked in UserDao");
		int composerId=0;
		String query="Select composer_id from composer_master where composer_name=?";
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			ps=connection.prepareStatement(query);
			ps.setString(1, composerName);
			rs=ps.executeQuery();
			if(rs.next())
				composerId=rs.getInt(1);
			else
				myLogger.info("No composer found with name: "+composerName);
		} catch (SQLException e) {
			myLogger.error("ERRROR : Failed to fetch data from composer_master "
					+ e.getMessage());
			throw new MusicMediaException("ERRROR :  Failed to fetch data from composer_maste  "
					+ e.getMessage());
		}	
		return composerId;
	}
}

package com.capgemini.musicMedia.test;
import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.musicMedia.exception.MusicMediaException;
import com.capgemini.musicMedia.util.DBUtil;

/**
 * @author anikhalder
 *
 */
public class DBUtilTest {
	 static DBUtil dbUtil ;
	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void testDBUtil() throws MusicMediaException{
		dbUtil= new DBUtil();
		assertNotNull("DBUtil Object Not created..."
				,dbUtil);
	}
	@Test
	public void testConnection() throws MusicMediaException {
		Connection conn = dbUtil.obtainConnection();
		assertNotNull("Connection NOT obtained!",conn);
		if(conn!=null)System.out.println("connection Obtained ...."+conn);
	}

}

package com.capgemini.musicMedia.bean;

import java.time.LocalDate;

public class ArtistMaster {

	private int artistId;
	private String artistName;
	private String artistType;
	private LocalDate artistBornDate;
	private LocalDate artistDiedDate;
	private boolean artistDeletedFlag;
	private int creationId;
	
	public ArtistMaster() {
		// TODO Auto-generated constructor stub
	}

	public ArtistMaster(int artistId, String artistName, String artistType,
			LocalDate artistBornDate, LocalDate artistDiedDate,
			boolean artistDeletedFlag, int creationId) {
		super();
		this.artistId = artistId;
		this.artistName = artistName;
		this.artistType = artistType;
		this.artistBornDate = artistBornDate;
		this.artistDiedDate = artistDiedDate;
		this.artistDeletedFlag = artistDeletedFlag;
		this.creationId = creationId;
	}

	public int getArtistId() {
		return artistId;
	}

	public void setArtistId(int artistId) {
		this.artistId = artistId;
	}

	public String getArtistName() {
		return artistName;
	}

	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}

	public String getArtistType() {
		return artistType;
	}

	public void setArtistType(String artistType) {
		this.artistType = artistType;
	}

	public LocalDate getArtistBornDate() {
		return artistBornDate;
	}

	public void setArtistBornDate(LocalDate artistBornDate) {
		this.artistBornDate = artistBornDate;
	}

	public LocalDate getArtistDiedDate() {
		return artistDiedDate;
	}

	public void setArtistDiedDate(LocalDate artistDiedDate) {
		this.artistDiedDate = artistDiedDate;
	}

	public boolean isArtistDeletedFlag() {
		return artistDeletedFlag;
	}

	public void setArtistDeletedFlag(boolean artistDeletedFlag) {
		this.artistDeletedFlag = artistDeletedFlag;
	}

	public int getCreationId() {
		return creationId;
	}

	public void setCreationId(int creationId) {
		this.creationId = creationId;
	}

	@Override
	public String toString() {
		return "ArtistMaster [artistId=" + artistId + ", artistName="
				+ artistName + ", artistType=" + artistType
				+ ", artistBornDate=" + artistBornDate + ", artistDiedDate="
				+ artistDiedDate + ", artistDeletedFlag=" + artistDeletedFlag
				+ ", creationId=" + creationId + "]";
	}
	
	
}

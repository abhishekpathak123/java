package com.capgemini.musicMedia.bean;

public class SongMaster {
	
	private int songId;
	private String songName;
	private String SongDuration;
	private boolean SongDeletedFlag;
	private int creationId;
	
	public SongMaster() {
		// TODO Auto-generated constructor stub
	}

	public SongMaster(int songId, String songName, String songDuration,
			boolean songDeletedFlag, int creationId) {
		super();
		this.songId = songId;
		this.songName = songName;
		SongDuration = songDuration;
		SongDeletedFlag = songDeletedFlag;
		this.creationId = creationId;
	}

	public int getSongId() {
		return songId;
	}

	public void setSongId(int songId) {
		this.songId = songId;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public String getSongDuration() {
		return SongDuration;
	}

	public void setSongDuration(String songDuration) {
		SongDuration = songDuration;
	}

	public boolean isSongDeletedFlag() {
		return SongDeletedFlag;
	}

	public void setSongDeletedFlag(boolean songDeletedFlag) {
		SongDeletedFlag = songDeletedFlag;
	}

	public int getCreationId() {
		return creationId;
	}

	public void setCreationId(int creationId) {
		this.creationId = creationId;
	}

	@Override
	public String toString() {
		return "SngMaster [songId=" + songId + ", songName=" + songName
				+ ", SongDuration=" + SongDuration + ", SongDeletedFlag="
				+ SongDeletedFlag + ", creationId=" + creationId + "]";
	}
	
	

}

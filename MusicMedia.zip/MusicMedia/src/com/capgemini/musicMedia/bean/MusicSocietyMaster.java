package com.capgemini.musicMedia.bean;

public class MusicSocietyMaster {
	
	private String composerMusicSocietyId;
	private String composerMusicSocietyName;
	
	public MusicSocietyMaster() {
		// TODO Auto-generated constructor stub
	}

	public MusicSocietyMaster(String composerMusicSocietyId,
			String composerMusicSocietyName) {
		super();
		this.composerMusicSocietyId = composerMusicSocietyId;
		this.composerMusicSocietyName = composerMusicSocietyName;
	}

	public String getComposerMusicSocietyId() {
		return composerMusicSocietyId;
	}

	public void setComposerMusicSocietyId(String composerMusicSocietyId) {
		this.composerMusicSocietyId = composerMusicSocietyId;
	}

	public String getComposerMusicSocietyName() {
		return composerMusicSocietyName;
	}

	public void setComposerMusicSocietyName(String composerMusicSocietyName) {
		this.composerMusicSocietyName = composerMusicSocietyName;
	}

	@Override
	public String toString() {
		return "MusicSocietyMaster [composerMusicSocietyId="
				+ composerMusicSocietyId + ", composerMusicSocietyName="
				+ composerMusicSocietyName + "]";
	}
	
	

}

package com.capgemini.musicMedia.bean;

public class UserMaster {
	
	private int userId;
	private String userPassword;
	private int creationId;
	
	
	public UserMaster() {
		// TODO Auto-generated constructor stub
	}


	public UserMaster(int userId, String userPassword, int creationId) {
		super();
		this.userId = userId;
		this.userPassword = userPassword;
		this.creationId = creationId;
	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getUserPassword() {
		return userPassword;
	}


	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	public int getCreationId() {
		return creationId;
	}


	public void setCreationId(int creationId) {
		this.creationId = creationId;
	}


	@Override
	public String toString() {
		return "UserMaster [userId=" + userId + ", userPassword="
				+ userPassword + ", creationId=" + creationId + "]";
	}
	
	
}

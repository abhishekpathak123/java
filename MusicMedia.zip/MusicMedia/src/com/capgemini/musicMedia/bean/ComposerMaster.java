package com.capgemini.musicMedia.bean;

import java.time.LocalDate;

public class ComposerMaster {
	
	private int composerId;
	private String composerName;
	private LocalDate composerBornDate;
	private LocalDate composerDiedDate;
	private String caeipiNumber;
	private String composerMusicSocietyId;
	private boolean composerDeletedFlag;
	private int creationId;
	
	public ComposerMaster() {
		// TODO Auto-generated constructor stub
	}

	public ComposerMaster(int composerId, String composerName,
			LocalDate composerBornDate, LocalDate composerDiedDate,
			String caeipiNumber, String composerMusicSocietyId,
			boolean composerDeletedFlag, int creationId) {
		super();
		this.composerId = composerId;
		this.composerName = composerName;
		this.composerBornDate = composerBornDate;
		this.composerDiedDate = composerDiedDate;
		this.caeipiNumber = caeipiNumber;
		this.composerMusicSocietyId = composerMusicSocietyId;
		this.composerDeletedFlag = composerDeletedFlag;
		this.creationId = creationId;
	}

	public int getComposerId() {
		return composerId;
	}

	public void setComposerId(int composerId) {
		this.composerId = composerId;
	}

	public String getComposerName() {
		return composerName;
	}

	public void setComposerName(String composerName) {
		this.composerName = composerName;
	}

	public LocalDate getComposerBornDate() {
		return composerBornDate;
	}

	public void setComposerBornDate(LocalDate composerBornDate) {
		this.composerBornDate = composerBornDate;
	}

	public LocalDate getComposerDiedDate() {
		return composerDiedDate;
	}

	public void setComposerDiedDate(LocalDate composerDiedDate) {
		this.composerDiedDate = composerDiedDate;
	}

	public String getCaeipiNumber() {
		return caeipiNumber;
	}

	public void setCaeipiNumber(String caeipiNumber) {
		this.caeipiNumber = caeipiNumber;
	}

	public String getComposerMusicSocietyId() {
		return composerMusicSocietyId;
	}

	public void setComposerMusicSocietyId(String composerMusicSocietyId) {
		this.composerMusicSocietyId = composerMusicSocietyId;
	}

	public boolean isComposerDeletedFlag() {
		return composerDeletedFlag;
	}

	public void setComposerDeletedFlag(boolean composerDeletedFlag) {
		this.composerDeletedFlag = composerDeletedFlag;
	}

	public int getCreationId() {
		return creationId;
	}

	public void setCreationId(int creationId) {
		this.creationId = creationId;
	}

	@Override
	public String toString() {
		return "ComposerMaster [composerId=" + composerId + ", composerName="
				+ composerName + ", composerBornDate=" + composerBornDate
				+ ", composerDiedDate=" + composerDiedDate + ", caeipiNumber="
				+ caeipiNumber + ", composerMusicSocietyId="
				+ composerMusicSocietyId + ", composerDeletedFlag="
				+ composerDeletedFlag + ", creationId=" + creationId + "]";
	}
	
	

}

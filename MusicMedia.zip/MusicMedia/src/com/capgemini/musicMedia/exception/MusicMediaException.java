/**
 * 
 */
package com.capgemini.musicMedia.exception;

/**
 * @author anihalde
 *
 */
public class MusicMediaException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 893915591056469988L;

	public MusicMediaException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MusicMediaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

package com.capgemini.dao;

import com.capgemini.bean.FRSBean;

public interface IFRSDao {

	public FRSBean addFlat(FRSBean frsbean);

	
	
}

package com.capgemini.service;

import com.capgemini.bean.FRSBean;

public interface IFRSService {

	public FRSBean addFlat(FRSBean frsbean);
	
	
}

package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.AccountBean;
import com.cg.exception.BankException;

public interface BankDao {

	public ArrayList<AccountBean> displayAllAccounts(String cName) throws BankException;

	public boolean validate(String cName)throws BankException;

	public boolean insertTransaction(double amount, String accNo)throws BankException;
	
}

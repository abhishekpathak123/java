package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.bean.AccountBean;
import com.cg.bean.TransactionBean;
import com.cg.exception.BankException;
import com.cg.util.DBUtil;


public class BankDaoImpl implements BankDao {

	Connection con;
	public BankDaoImpl() {
		con = DBUtil.getConnect();
	}
	public boolean validate(String cName)throws BankException{
		boolean flag = false;
		String sql = "SELECT * FROM account_details WHERE customer_name=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cName);
			ResultSet resultSet = pstmt.executeQuery();
			if(resultSet.next())
			{
				flag = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	@Override
	public ArrayList<AccountBean> displayAllAccounts(String cName)throws BankException {
		String sql = "SELECT * FROM account_details WHERE customer_name=? ";
		ArrayList<AccountBean> list = new ArrayList<>();
		
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cName);
			ResultSet resultSet = pstmt.executeQuery();
			
			while(resultSet.next())
			{
				AccountBean accBean = new AccountBean();
				accBean.setAccNo(resultSet.getString(1));
				accBean.setcName(resultSet.getString(2));
				accBean.setAccType(resultSet.getString(3));
				accBean.setAccLocation(resultSet.getString(4));
				accBean.setBalance(resultSet.getDouble(5));
				list.add(accBean);
				
			}
		} catch (SQLException e) {
			
			throw new BankException("Could not fetch Account details");
		}
		
		return list;
	}
	@Override
	public boolean insertTransaction(double amount, String accNo)throws BankException {
		boolean flag = false;
		String type="ATM DEBIT";
		String sql = "INSERT INTO transaction_details VALUES(transaction_id_seq.nextval,?,?,?,?)";
		try {
			TransactionBean bean = new TransactionBean();
			PreparedStatement pstmt = con.prepareStatement(sql);
			bean.setTransactionDesc(type);
			pstmt.setString(1,bean.getTransactionDesc());
			pstmt.setDouble(2, amount);
			pstmt.setDate(3, Date.valueOf(LocalDate.now()));
			pstmt.setString(4, accNo);
			ResultSet resultSet = pstmt.executeQuery();
			
			boolean status = updateBalance(amount,accNo);
			
			if(resultSet.next())
			{
				flag = true;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return flag;
	}
	boolean updateBalance(double amount,String accNo) throws BankException{
		boolean flag = false;
		String sql = "UPDATE account_details SET balance=balance-? WHERE account_number=?";
		
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setDouble(1, amount);
			pstmt.setString(2, accNo);
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
		
		
	}

}

package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.AccountBean;
import com.cg.dao.BankDao;
import com.cg.dao.BankDaoImpl;
import com.cg.exception.BankException;

public class BankServiceImpl implements BankService {
	BankDao dao;
	public BankServiceImpl() {
		dao = new BankDaoImpl();
	}

	@Override
	public ArrayList<AccountBean> displayAllAccounts(String cName) throws BankException {
		
		return dao.displayAllAccounts(cName);
	}

	@Override
	public boolean validate(String cName) throws BankException {
		// TODO Auto-generated method stub
		return dao.validate(cName);
	}

	@Override
	public boolean insertTransaction(double amount, String accNo) throws BankException {
		// TODO Auto-generated method stub
		return dao.insertTransaction(amount,accNo);
	}

	

}

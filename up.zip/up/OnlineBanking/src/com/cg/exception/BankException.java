package com.cg.exception;

public class BankException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1875006995138791433L;

	public BankException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}

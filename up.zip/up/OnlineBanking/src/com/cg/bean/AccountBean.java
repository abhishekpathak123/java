package com.cg.bean;

public class AccountBean {

	String accNo;
	String cName;
	String accType;
	String accLocation;
	Double balance;
	@Override
	public String toString() {
		return "AccountBean [accNo=" + accNo + ", cName=" + cName
				+ ", accType=" + accType + ", accLocation=" + accLocation
				+ ", balance=" + balance + "]";
	}
	public AccountBean(String accNo, String cName, String accType,
			String accLocation, Double balance) {
		super();
		this.accNo = accNo;
		this.cName = cName;
		this.accType = accType;
		this.accLocation = accLocation;
		this.balance = balance;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getAccLocation() {
		return accLocation;
	}
	public void setAccLocation(String accLocation) {
		this.accLocation = accLocation;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	
	public AccountBean() {
		// TODO Auto-generated constructor stub
	}
	
}

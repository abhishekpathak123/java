package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.BillDetails;
import com.cg.bean.Consumers;

public interface BillService {

	ArrayList<Consumers> showConsumer();

	ArrayList<BillDetails> showBillDetails(int consumerNo);

	boolean insertBillDetails(BillDetails bill);

	BillDetails calculate(int conno, Double lastRead, Double curRead);

	String getConsumerName(int conno);

	

}

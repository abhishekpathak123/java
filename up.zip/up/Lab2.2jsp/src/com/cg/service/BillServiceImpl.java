package com.cg.service;



import java.util.ArrayList;






import com.cg.bean.BillDetails;
import com.cg.bean.Consumers;
import com.cg.dao.BillDao;
import com.cg.dao.BillDaoImpl;

public class BillServiceImpl implements BillService {

	
	BillDao dao;
	public BillServiceImpl() {
		dao = new BillDaoImpl();
	}
	
	@Override
	public ArrayList<Consumers> showConsumer() {
		
		
		return dao.showConsumer();
	}

	@Override
	public ArrayList<BillDetails> showBillDetails(int consumerNo) {
		// TODO Auto-generated method stub
		return dao.showBillDetails(consumerNo);
	}

	

	@Override
	public boolean insertBillDetails(BillDetails bill) {
		// TODO Auto-generated method stub
		return dao.insertBillDetails(bill);
	}

	@Override
	public BillDetails calculate(int conno, Double lastRead, Double curRead) {
		BillDetails bill = new BillDetails();
		Double units =  curRead - lastRead;
		bill.setUnitConsumed(units);
		Double amount = units * 1.15 +100;
		bill.setAmount(amount);
		return bill;
		
	}

	@Override
	public String getConsumerName(int conno) {
		// TODO Auto-generated method stub
		return dao.getConsumerName(conno);
	}

}

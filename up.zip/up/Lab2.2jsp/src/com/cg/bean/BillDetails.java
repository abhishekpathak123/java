package com.cg.bean;

import java.time.LocalDate;

public class BillDetails {

	int billNum;
	int consumerNum;
	Double curReading;
	Double unitConsumed;
	Double amount;
	LocalDate billDate;
	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public int getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}
	public Double getCurReading() {
		return curReading;
	}
	public void setCurReading(Double curReading) {
		this.curReading = curReading;
	}
	public Double getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(Double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public LocalDate getBillDate() {
		return billDate;
	}
	public void setBillDate(LocalDate billDate) {
		this.billDate = billDate;
	}
	@Override
	public String toString() {
		return "BillDetails [billNum=" + billNum + ", consumerNum="
				+ consumerNum + ", curReading=" + curReading
				+ ", unitConsumed=" + unitConsumed + ", amount=" + amount
				+ ", billDate=" + billDate + "]";
	}
	
	
}

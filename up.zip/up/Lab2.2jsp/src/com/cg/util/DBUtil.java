package com.cg.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBUtil {
static Connection con;
	
	static{
		try{
			InitialContext context = new InitialContext();
			DataSource dataSource = (DataSource)context.lookup("java:/jdbc/TestDs");
			con = dataSource.getConnection();
		}catch(Exception e){
			try {
				throw new SQLException(e.getMessage());
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	public static Connection getConnect(){
		return con;
	}
}

package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.sql.Date;

import com.cg.bean.BillDetails;
import com.cg.bean.Consumers;
import com.cg.util.DBUtil;

public class BillDaoImpl implements BillDao {
	Connection con;
	public BillDaoImpl() {
		con = DBUtil.getConnect();
	}
	@Override
	public ArrayList<Consumers> showConsumer() {
		Consumers consumers;
		ArrayList<Consumers> list = new ArrayList<>();
		String sql = "select * from consumers";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				consumers = new Consumers();
				consumers.setConsumerNo(rs.getInt(1));
				consumers.setName(rs.getString(2));
				consumers.setAddress(rs.getString(3));
			
				list.add(consumers);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	@Override
	public ArrayList<BillDetails> showBillDetails(int consumerNo) {
		BillDetails bill = null;
		ArrayList<BillDetails> list = new ArrayList<>();
		String sql = "select * from billdetails where consumer_num=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, consumerNo);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
			{
				bill = new BillDetails();
				bill.setBillNum(rs.getInt(1));
				bill.setConsumerNum(rs.getInt(2));
				bill.setCurReading(rs.getDouble(3));
				bill.setUnitConsumed(rs.getDouble(4));
				bill.setAmount(rs.getDouble(5));
				bill.setBillDate(rs.getDate(6).toLocalDate());
				
				list.add(bill);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	@Override
	public boolean insertBillDetails(BillDetails bill) {
		boolean flag = false;
		String sql = "insert into billdetails values(seq_bill_num.nextval,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bill.getConsumerNum());
			pstmt.setDouble(2, bill.getCurReading());
			pstmt.setDouble(3, bill.getUnitConsumed());
			pstmt.setDouble(4, bill.getAmount());
			pstmt.setDate(5, Date.valueOf(LocalDate.now()));
			int row = pstmt.executeUpdate();
			if(row > 0){
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
	}
	@Override
	public String getConsumerName(int conno) {
		String sql = "select consumer_name from consumers where consumer_num=?";
		String name = null;
		
		ResultSet rs = null;
		try {
			
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, conno);
			 rs = pstmt.executeQuery();
			 System.out.println(rs);
			 if(rs.next()){
				 name = rs.getString("consumer_name");
				
			 }
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
	}
	
}

package com.cg.dao;

import java.util.ArrayList;




import com.cg.bean.BillDetails;
import com.cg.bean.Consumers;

public interface BillDao {

	ArrayList<Consumers> showConsumer();

	ArrayList<BillDetails> showBillDetails(int consumerNo);

	boolean insertBillDetails(BillDetails bill);

	String getConsumerName(int conno);

}

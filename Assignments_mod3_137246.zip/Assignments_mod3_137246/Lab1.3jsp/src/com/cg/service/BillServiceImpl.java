package com.cg.service;

import com.cg.bean.BillDetails;
import com.cg.bean.Login;
import com.cg.dao.BillDao;
import com.cg.dao.BillDaoImpl;

public class BillServiceImpl implements BillService {

	BillDao dao;
	public BillServiceImpl() {
		dao = new BillDaoImpl();
	}
	
	@Override
	public boolean validate(Login bean) {
		
		return dao.validate(bean);
	}

	@Override
	public boolean insertBillDetails(BillDetails bill) {
		
		return dao.insertBillDetails(bill);
	}

	@Override
	public BillDetails calculate(int conno, Double lastRead, Double curRead) {
		BillDetails bill = new BillDetails();
		Double units =  curRead - lastRead;
		bill.setUnitConsumed(units);
		Double amount = units * 1.15 +100;
		bill.setAmount(amount);
		return bill;
		
	}

	@Override
	public String getConsumerName(int conno) {
		// TODO Auto-generated method stub
		return dao.getConsumerName(conno);
	}



	

}

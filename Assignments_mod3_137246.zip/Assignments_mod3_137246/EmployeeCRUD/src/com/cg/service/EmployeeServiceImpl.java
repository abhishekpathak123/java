package com.cg.service;

import com.cg.bean.Employee;
import com.cg.dao.EmployeeDao;
import com.cg.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDao dao;
	 
	public EmployeeServiceImpl() {
		dao = new EmployeeDaoImpl();
	}
	
	@Override
	public boolean insertEmployee(Employee bean) {
		
		return dao.insertEmployee(bean);
	}

	@Override
	public Employee getEmployeeById(int id) {
		
		return dao.getEmployeeById(id);
	}

}

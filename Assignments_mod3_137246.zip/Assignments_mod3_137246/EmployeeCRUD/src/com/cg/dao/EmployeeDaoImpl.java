package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

import com.cg.bean.Employee;
import com.cg.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	Connection con;
	public EmployeeDaoImpl() {
		con = DBUtil.getConnect();
	}
	
	@Override
	public boolean insertEmployee(Employee bean) {
		
		String sql = "INSERT INTO Employee values(empId_seq.nextval,?,?,?)";
		Date bDate = Date.valueOf(bean.getbDate());
		boolean flag = false;
		try{
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1,bean.getEmpName());
			pstmt.setDate(2,bDate);
			pstmt.setInt(3,bean.getSalary());
			int row = pstmt.executeUpdate();
			if(row > 0){
				flag = true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public Employee getEmployeeById(int id) {
		String sql = "SELECT * FROM Employee where empId=?";
		Employee emp = null;
		try{
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				emp = new Employee();
				emp.setEmpId(rs.getInt(1));
				emp.setEmpName(rs.getString(2));
				LocalDate bDate = rs.getDate(3).toLocalDate();
				emp.setbDate(bDate);
				emp.setSalary(rs.getInt(4));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return emp;
	}

	@Override
	public boolean updateEmployee(Employee bean) {
		String sql = "update Employee set empName=? bDate=? where empId=?";
		boolean flag = false;
		
		
		return false;
	}

}

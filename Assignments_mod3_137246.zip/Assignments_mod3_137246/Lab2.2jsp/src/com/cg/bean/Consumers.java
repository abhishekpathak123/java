package com.cg.bean;

public class Consumers {

	int consumerNo;
	String name;
	String address;
	
	
	public int getConsumerNo() {
		return consumerNo;
	}


	public void setConsumerNo(int consumerNo) {
		this.consumerNo = consumerNo;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	@Override
	public String toString() {
		return "Consumers [consumerNo=" + consumerNo + ", name=" + name
				+ ", address=" + address + "]";
	}
	
	
}

package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.BillDetails;
import com.cg.bean.Consumers;
import com.cg.service.BillService;
import com.cg.service.BillServiceImpl;

/**
 * Servlet implementation class EbillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       BillService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        service = new BillServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		String action = request.getParameter("action");
		ArrayList<Consumers> consumerList = new ArrayList<>();
		ArrayList<BillDetails> billList = new ArrayList<>();
		consumerList = service.showConsumer();
		session.setAttribute("consumerList", consumerList);
		if("list".equals(action))
		{
			
			
			RequestDispatcher dispatch = request.getRequestDispatcher("showConsumer.jsp");
			dispatch.forward(request, response);
		}
		if("search".equals(action))
		{
			
			RequestDispatcher dispatch = request.getRequestDispatcher("search.jsp");
			dispatch.forward(request, response);
		}
		
		
		if("billdetails".equals(action))
		{
			String id = request.getParameter("consumerNo");
			int consumerNo = Integer.parseInt(id);
			session.setAttribute("consumerNo", consumerNo);
			
			billList = service.showBillDetails(consumerNo);
			session.setAttribute("billList", billList);
			
			if(billList != null)
			{
				
				RequestDispatcher dispatch = request.getRequestDispatcher("showbills.jsp");
				dispatch.forward(request, response);
			}
			
		}
		if("generate".equals(action))
		{
			
			int consumerNo = (int)session.getAttribute("consumerNo");
			
			RequestDispatcher dispatch = request.getRequestDispatcher("UserInfo.jsp");
			dispatch.forward(request, response);
			
		}
		if("home".equals(action))
		{
			RequestDispatcher dispatch = request.getRequestDispatcher("index.html");
			dispatch.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		ArrayList<Consumers> consumerList = new ArrayList<>();
		ArrayList<BillDetails> billList = new ArrayList<>();
		String action = request.getParameter("action");
		if("billinfo".equals(action))
		{
		
			session.setAttribute("conno", request.getParameter("conno"));
			session.setAttribute("lread", request.getParameter("lread"));
			session.setAttribute("curread", request.getParameter("curread"));
			
			    BillDetails bill = new BillDetails();
			    Consumers consumers = new Consumers();
				String no = (String)session.getAttribute("conno");
				int conno = Integer.parseInt(no);
				String lread = (String)session.getAttribute("lread");
				Double lastRead = Double.parseDouble(lread);
				String cread = (String)session.getAttribute("curread");
				Double curRead = Double.parseDouble(cread);
				
				
				bill = service.calculate(conno,lastRead,curRead);
				bill.setCurReading(curRead);
				bill.setConsumerNum(conno);
				boolean flag = service.insertBillDetails(bill);
				if(flag)
				{
					String name = service.getConsumerName(conno);
					consumers.setName(name);
					session.setAttribute("name", name);
					session.setAttribute("newbill",bill);
					RequestDispatcher dispatch = request.getRequestDispatcher("BillInfo.jsp");
					dispatch.forward(request, response);
				}
			
		}
	
	if("show".equals(action))
	{
		
		String id = request.getParameter("consumerNo");
		int consumerNo = Integer.parseInt(id);
		System.out.println(consumerNo);
		session.setAttribute("consumerNo", consumerNo);
		
	
		consumerList = (ArrayList<Consumers>)session.getAttribute("consumerList");
		System.out.println(consumerList);
		for(Consumers con : consumerList)
		{
			if(consumerNo == con.getConsumerNo())
			{
				session.setAttribute("consumernew", con);
				System.out.println(con);
				break;
			}
		}
		
		RequestDispatcher dispatch = request.getRequestDispatcher("ConsumerDetails.jsp");
		dispatch.forward(request, response);
	}

}
}

package com.cg.exception;

public class BillException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6489574063513948253L;

	public BillException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BillException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}

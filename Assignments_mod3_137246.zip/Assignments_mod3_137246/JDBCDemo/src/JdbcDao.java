import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;




public class JdbcDao {

	static Connection con;
	
	static{
		try {
			InitialContext context = new InitialContext();//reference to Wildfly
			DataSource dataSource = (DataSource) context.lookup("java:/jdbc/TestDs");
			con = dataSource.getConnection();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static ArrayList<String>getNames() throws SQLException
	{
		ArrayList<String>list = new ArrayList<String>();
		Statement stmt = con.createStatement();
		String sql = "SELECT userName FROM userDetails";
		ResultSet result = stmt.executeQuery(sql);
		while(result.next()){
			String user = result.getString(1);
			list.add(user);
		}
		return list;
	}
	
}

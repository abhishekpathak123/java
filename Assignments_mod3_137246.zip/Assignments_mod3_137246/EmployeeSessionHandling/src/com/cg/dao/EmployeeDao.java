package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.Employee;

public interface EmployeeDao {

	public ArrayList<Employee> getEmployeeList();
	public boolean updateSalary(int id,int salary);
}

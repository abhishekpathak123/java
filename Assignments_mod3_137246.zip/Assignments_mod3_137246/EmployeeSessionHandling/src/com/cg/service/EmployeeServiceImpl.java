package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Employee;
import com.cg.dao.EmployeeDao;
import com.cg.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDao dao;
	
	public EmployeeServiceImpl() {
		dao = new EmployeeDaoImpl();
	}
	
	@Override
	public ArrayList<Employee> getEmployeeList() {
		// TODO Auto-generated method stub
		return dao.getEmployeeList();
	}

	@Override
	public boolean updateSalary(int id, int salary) {
		// TODO Auto-generated method stub
		return dao.updateSalary(id, salary);
	}

}

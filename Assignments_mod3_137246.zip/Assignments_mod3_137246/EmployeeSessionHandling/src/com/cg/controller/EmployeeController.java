package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.Employee;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       EmployeeService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeController() {
        super();
        service = new EmployeeServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		String action = request.getParameter("action");
		ArrayList<Employee> list = null;
		if("index".equals(action))
		{
			list = service.getEmployeeList();
			session.setAttribute("empList", list);
			PrintWriter out = response.getWriter();
			
			if(list.size() != 0){
				out.println("<html>");
				out.println("<body>");
				out.println("<table>");
				
				for(Employee obj:list){
					
					out.println("<tr><td>"+obj.getEmpName()+"</td><td>"+obj.getbDate()+"</td><td>"
					+obj.getSalary()+"</td>"+
							"<td><a href='EmployeeController?action=update&id="
							+obj.getEmpId()+"'>"+"update"+"</a></td></tr>");
			

				}
				out.println("</table>");
				out.println("</body>");
				out.println("</html>");



			}
		}
		else if("update".equals(action)){
			ArrayList<Employee> listEmp = (ArrayList<Employee>)session.getAttribute("empList");
			String empId = request.getParameter("id");
			for(Employee obj :listEmp)
			{
				if(obj.getEmpId()==Integer.parseInt(empId))
				{
					session.setAttribute("empId", empId);
					RequestDispatcher dispatch = request.getRequestDispatcher("update.html");
					dispatch.forward(request, response);
					break;
				}
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		String action = request.getParameter("action");
		PrintWriter out = response.getWriter();
		if("updateSal".equals(action))
		{
			String eid = (String)session.getAttribute("empId");
			int id = Integer.parseInt(eid);
			String sal = request.getParameter("sal");
			int salary = Integer.parseInt(sal);
			boolean flag = service.updateSalary(id,salary);
			if(flag)
			{
				out.println("updated salary of "+id);
			}
			else
			{
				out.println("Invalid id"+id);
			}
		}
	}

}

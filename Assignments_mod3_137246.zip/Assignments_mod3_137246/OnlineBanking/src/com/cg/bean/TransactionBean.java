package com.cg.bean;

import java.time.LocalDate;

public class TransactionBean {

	int transactionId;
	String transactionDesc;
	Double transactionAmt;
	LocalDate transactionDate;
	String accNo;
	public TransactionBean() {
		// TODO Auto-generated constructor stub
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionDesc() {
		return transactionDesc;
	}
	public void setTransactionDesc(String transactionDesc) {
		this.transactionDesc = transactionDesc;
	}
	public Double getTransactionAmt() {
		return transactionAmt;
	}
	public void setTransactionAmt(Double transactionAmt) {
		this.transactionAmt = transactionAmt;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public TransactionBean(int transactionId, String transactionDesc,
			Double transactionAmt, LocalDate transactionDate, String accNo) {
		super();
		this.transactionId = transactionId;
		this.transactionDesc = transactionDesc;
		this.transactionAmt = transactionAmt;
		this.transactionDate = transactionDate;
		this.accNo = accNo;
	}
	@Override
	public String toString() {
		return "TransactionBean [transactionId=" + transactionId
				+ ", transactionDesc=" + transactionDesc + ", transactionAmt="
				+ transactionAmt + ", transactionDate=" + transactionDate
				+ ", accNo=" + accNo + "]";
	}
	
	
	
}

package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.AccountBean;
import com.cg.exception.BankException;

public interface BankService {

	
	public ArrayList<AccountBean> displayAllAccounts(String cName)throws BankException;

	public boolean validate(String string)throws BankException;

	public boolean insertTransaction(double amount,String accNo)throws BankException;
}

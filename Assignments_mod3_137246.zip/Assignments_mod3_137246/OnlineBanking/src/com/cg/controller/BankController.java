package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.AccountBean;
import com.cg.exception.BankException;
import com.cg.service.BankService;
import com.cg.service.BankServiceImpl;

/**
 * Servlet implementation class BankController
 */
@WebServlet("/BankController")
public class BankController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BankService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BankController() {
        super();
        service = new BankServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session= request.getSession(true);
				String action = request.getParameter("action");
		if("debit".equals(action))
		{
			session.setAttribute("accNo",request.getParameter("accNo"));
			RequestDispatcher dispatch = request.getRequestDispatcher("DebitAmount.jsp");
			dispatch.forward(request, response);
		}
		if("index".equals(action))
		{
			response.sendRedirect("Home.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session= request.getSession(true);
		String action = request.getParameter("action");
		ArrayList<AccountBean> accList = new ArrayList<>();
		boolean validate = false;
		if("get".equals(action))
		{
			String cName = request.getParameter("cName");
			session.setAttribute("cName",cName);
			try {
				validate = service.validate(cName);if(validate)
				{
					
					accList = service.displayAllAccounts(cName);
						
					if(accList.size() != 0)
					{
						session.setAttribute("accList", accList);
						
						/*for(AccountBean bean:accList)
						{
							if(cName==bean.getcName())
							{
								session.setAttribute("accNo", bean.getAccNo());
								System.out.println(bean.getAccNo());
							}
						}*/
						RequestDispatcher dispatch = request.getRequestDispatcher("AccountInfo.jsp");
						dispatch.forward(request, response);
					}
					
					
				}
				else{
					throw new BankException();
					
				
			}
			} catch (BankException e) {
				// TODO Auto-generated catch block
				RequestDispatcher dispatch = request.getRequestDispatcher("Error.jsp");
				dispatch.forward(request, response);
			}
			
			
				}
		if("transaction".equals(action))
		{
			Double amount = Double.parseDouble(request.getParameter("amt"));
			if(amount==0 || amount < 0)
			{
				RequestDispatcher dispatch = request.getRequestDispatcher("amountfail.jsp");
				dispatch.forward(request, response);
				
			}
			session.setAttribute("amount", amount);
			String accNo = (String)session.getAttribute("accNo");
		
			boolean flag;
			try {
				flag = service.insertTransaction(amount, accNo);
				if(flag)
				{
					RequestDispatcher dispatch = request.getRequestDispatcher("success.jsp");
					dispatch.forward(request, response);
				}
				else{
					throw new BankException();
					
				}
			} catch (BankException e) {
				// TODO Auto-generated catch block
				RequestDispatcher dispatch = request.getRequestDispatcher("failure.jsp");
				dispatch.forward(request, response);
			}
			
		}
	
	}

}

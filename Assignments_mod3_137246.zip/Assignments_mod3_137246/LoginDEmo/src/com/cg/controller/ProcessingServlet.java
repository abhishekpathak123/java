package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.LoginBean;
import com.cg.service.LoginI;
import com.cg.service.LoginImpl;

/**
 * Servlet implementation class ProcessingServlet
 */
@WebServlet("/ProcessingServlet")
public class ProcessingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       LoginI service = new LoginImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcessingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LoginBean bean = new LoginBean();
		String user = request.getParameter("usern");
		String passwd = request.getParameter("pass");
		bean.setUsername(user);
		bean.setPassword(passwd);
		PrintWriter out = response.getWriter();
		boolean flag = service.validate(bean);
		if(flag){
			/*out.println("Welcome to our website");
			response.setHeader("Refresh","3;URL=success.html");*/
			response.sendRedirect("success.html");
			
		}
		else{
			/*out.println("Sorry, invalid credentials");*/
			response.sendError(404);
		}
		
	}

}

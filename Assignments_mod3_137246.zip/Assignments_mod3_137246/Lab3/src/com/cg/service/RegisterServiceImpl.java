/**
 * 
 */
package com.cg.service;

import com.cg.bean.RegisterBean;
import com.cg.dao.IRegistration;
import com.cg.dao.RegisterDaoImpl;

/**
 * @author shreya
 *
 */
public class RegisterServiceImpl implements IRegisterService {
	
	IRegistration dao;
	public RegisterServiceImpl() {
		dao = new RegisterDaoImpl();
	}
	
	@Override
	public RegisterBean registerUser(RegisterBean bean) {
		// TODO Auto-generated method stub
		return dao.registerUser(bean);
	}

}

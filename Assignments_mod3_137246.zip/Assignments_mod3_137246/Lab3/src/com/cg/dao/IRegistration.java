/**
 * 
 */
package com.cg.dao;

import com.cg.bean.RegisterBean;



/**
 * @author shreya
 *
 */
public interface IRegistration {

	public RegisterBean registerUser(RegisterBean bean);
}

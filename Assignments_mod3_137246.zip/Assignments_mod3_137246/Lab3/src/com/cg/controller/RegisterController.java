package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.RegisterBean;
import com.cg.service.IRegisterService;
import com.cg.service.RegisterServiceImpl;

/**
 * Servlet implementation class RegisterController
 */
@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	  IRegisterService service;
    /**
     * Default constructor. 
     */
    public RegisterController() {
    	service = new RegisterServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		HttpSession session = request.getSession(true);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		HttpSession session = request.getSession(false);
		RegisterBean bean = new RegisterBean();
		RegisterBean successBean = null;
		if("insertUser".equals(action))
		{
			String firstname = request.getParameter("firstname");
			String lastname = request.getParameter("lastname");
			String password = request.getParameter("password");
			String gender = request.getParameter("gender");
			String skillset = request.getParameter("skillset");
			String city = request.getParameter("city");
			bean.setFirstName(firstname);
			bean.setLastName(lastname);
			bean.setPassword(password);
			bean.setGender(gender);
			bean.setSkillSet(skillset);
			bean.setCity(city);
			successBean = service.registerUser(bean);
			session.setAttribute("success", successBean);
			PrintWriter out = response.getWriter();
		
		}
	}

}

package com.cg.onlineshopping.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.onlineshopping.bean.Product;
import com.cg.onlineshopping.service.ShoppingService;
import com.cg.onlineshopping.service.ShoppingServiceImpl;

/**
 * Servlet implementation class ShoppingController
 */
@WebServlet("/ShoppingController")
public class ShoppingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       ShoppingService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShoppingController() {
        super();
        service = new ShoppingServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		String action = request.getParameter("action");
		if("index".equals(action))
		{
			RequestDispatcher dispatch = request.getRequestDispatcher("home.jsp");
			dispatch.forward(request, response);
		}
		if("purchase".equals(action))
		{
			String id = request.getParameter("prodId");
			int prodId = Integer.parseInt(id);
			int customerId = (int)session.getAttribute("custId");
			int pId = service.purchase(prodId, customerId);
			if(pId != 0)
			{
				ArrayList<Product>list = (ArrayList<Product>)session.getAttribute("prodList");
				for(Product bean:list)
				{
					if(prodId==bean.getProdId())
					{
						session.setAttribute("pBean", bean);
						break;
					}
				}
				RequestDispatcher dispatch = request.getRequestDispatcher("success.jsp");
				dispatch.forward(request, response);
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		String action = request.getParameter("action");
		ArrayList<Product>prodList = null;
		if("home".equals(action))
		{
			String id = request.getParameter("customerId");
			int custId = Integer.parseInt(id);
			prodList = service.getProductList(custId);
			if(prodList.size() != 0)
			{
				session.setAttribute("custId", custId);
				session.setAttribute("prodList", prodList);
				RequestDispatcher dispatch = request.getRequestDispatcher("showProduct.jsp");
				dispatch.forward(request, response);
			}
		}
		
	}

}

package com.cg.onlineshopping.service;

import java.util.ArrayList;

import com.cg.onlineshopping.bean.Product;

public interface ShoppingService {


	ArrayList<Product> getProductList(int custId);
	int purchase(int prodId,int custId);
}

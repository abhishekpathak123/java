package com.cg.onlineshopping.service;

import java.util.ArrayList;

import com.cg.onlineshopping.bean.Product;
import com.cg.onlineshopping.dao.ShoppingDao;
import com.cg.onlineshopping.dao.ShoppingDaoImpl;

public class ShoppingServiceImpl implements ShoppingService {
	
	ShoppingDao dao;
	public ShoppingServiceImpl() {
		dao = new ShoppingDaoImpl();
	}

	@Override
	public ArrayList<Product> getProductList(int custId) {
		// TODO Auto-generated method stub
		return dao.getProductList(custId);
	}

	@Override
	public int purchase(int prodId, int custId) {
		// TODO Auto-generated method stub
		return dao.purchase(prodId, custId);
	}

}

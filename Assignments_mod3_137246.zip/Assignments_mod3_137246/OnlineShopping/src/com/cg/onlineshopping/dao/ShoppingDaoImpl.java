package com.cg.onlineshopping.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.onlineshopping.bean.Product;
import com.cg.onlineshopping.util.DBUtil;

public class ShoppingDaoImpl implements ShoppingDao {

	Connection con;
	public ShoppingDaoImpl() {
		con = DBUtil.getConnect();
	}
	public boolean validate(int custId){
		boolean flag = false;
		String sql = "select * from Customer where custId=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, custId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	@Override
	public ArrayList<Product> getProductList(int custId) {
		
		ArrayList<Product>list = new ArrayList<>();
		if(validate(custId))
		{
			String sql = "select * from Product";
			try{
				Statement stmt = con.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				Product bean = new Product();
				bean.setProdId(rs.getInt(1));
				bean.setProdName(rs.getString(2));
				bean.setProdPrice(rs.getInt(3));
				bean.setQuantity(rs.getInt(4));
				list.add(bean);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		}
		return list;
	}

	@Override
	public int purchase(int prodId, int custId) {
		int purchaseId=0;
		String sql = "insert into purchasedetails values(pId_seq.nextval,?,?)";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,custId);
			pstmt.setInt(2,prodId);
			int row = pstmt.executeUpdate();
			if(row > 0){
				purchaseId = getPurchaseId();
				
				updateQuantity(prodId);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return purchaseId;
	}
	public boolean updateQuantity(int prodId)
	{
		boolean flag = false;
		String sql = "update Product set quantity=quantity-1 where prodId=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, prodId);
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				flag = true;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return flag;
	}
	public int getPurchaseId()
	{
		int purchaseId = 0;
		String sql ="select pId_seq.currval from dual";
		
		
		
			Statement stmt;
			try {
				stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sql);
				
				if(rs.next()){
					purchaseId = rs.getInt(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		return purchaseId;
	}

}

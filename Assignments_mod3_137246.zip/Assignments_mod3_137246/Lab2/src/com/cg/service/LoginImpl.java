/**
 * 
 */
package com.cg.service;

import com.cg.bean.LoginBean;
import com.cg.dao.LoginDao;
import com.cg.dao.LoginDaoImpl;

/**
 * @author shreya
 *
 */
public class LoginImpl implements LoginI {

	LoginDao dao = new LoginDaoImpl();
	
	/* (non-Javadoc)
	 * @see com.cg.service.LoginI#vaidate(com.cg.bean.LoginBean)
	 */
	@Override
	public boolean validate(LoginBean bean) {
		
		return dao.validate(bean);
	}

}

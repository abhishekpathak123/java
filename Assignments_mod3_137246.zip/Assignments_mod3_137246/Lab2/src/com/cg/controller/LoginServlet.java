package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.LoginBean;
import com.cg.service.LoginI;
import com.cg.service.LoginImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//service obj
       LoginI service = new LoginImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user = request.getParameter("username");
		String passwd = request.getParameter("passwd");
	/*	LoginBean bean = new LoginBean();
		bean.setUsername(user);
		bean.setPassword(passwd);
		PrintWriter out = response.getWriter();
		boolean flag = service.validate(bean);
		if(flag){
			out.println("Welcome to our website");
		}
		else{
			out.println("Sorry, invalid credentials");
		}
		*/
		
		RequestDispatcher dispatch = request.getRequestDispatcher("ProcessingServlet?usern="+user+"&&pass="+passwd);
		dispatch.forward(request, response);
	}

}

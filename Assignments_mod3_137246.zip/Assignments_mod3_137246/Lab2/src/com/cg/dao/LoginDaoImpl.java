package com.cg.dao;

import com.cg.bean.LoginBean;

public class LoginDaoImpl implements LoginDao {

	@Override
	public boolean validate(LoginBean bean) {
		boolean flag = false;
		if("cg".equals(bean.getUsername())
				&&"cg".equals(bean.getPassword())){
			flag = true;
		}
		return flag;
	}

}

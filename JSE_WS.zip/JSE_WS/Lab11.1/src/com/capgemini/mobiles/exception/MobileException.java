/**
 * 
 */
package com.capgemini.mobiles.exception;

/**
 * @author shreya
 *
 */
public class MobileException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6113726960952382008L;

	public MobileException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MobileException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

package com.capgemini.jdbc.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;




import com.capgemini.mobiles.exception.MobileException;

import oracle.jdbc.pool.OracleDataSource;



public class DBUtil {
	private static Connection connection = null;
	private static DBUtil instance = null;
	private static Properties props = null;
	private static OracleDataSource dataSource = null;
	private static Logger myLogger = null;
	// step 1 :logger code
	static {
		PropertyConfigurator
		.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(
				DBUtil.class.getName());
	}

	/*****************************************************************************
	 * - @throws MobileException - Private Constructor - Desc:Loads the
	 * jdbc.properties file and Driver Class and gets the connection
	 * 
	 * @throws MobileException
	 ********************************************************************************/
	public DBUtil() throws MobileException {
		try {
			props = loadProperties();
			myLogger.info("Properties loaded");
			dataSource = prepareDataSource();
			myLogger.info("Datasource Prepared!");
		} catch (IOException e) {
			myLogger.error(" Could not read the database details from properties file : "+e.getMessage());
			throw new MobileException(
					" Could not read the database details from properties file : "+e.getMessage());
		} catch (SQLException e) {
			myLogger.error(e.getMessage());
			throw new MobileException(e.getMessage());
		}

	}

	/*****************************************************************
	 * - Method Name:getInstance() - Input Parameters : - Return Type :
	 * DBUtil instance - Throws : MobileException - Author : Capgemini -
	 * Creation Date : 09/11/2016 - Description : Singleton and Thread safe
	 * class
	 *******************************************************************/
	public static DBUtil getInstance() throws MobileException {
		synchronized (DBUtil.class) {
			if (instance == null) {
				instance = new DBUtil();
			}
		}
		return instance;
	}

	/****************************************************
	 * - Method Name:getConnection() 
	 * - Return Type : Connection object 
	 * - Author : Capgemini 
	 * - Creation Date : 09/11/2016 
	 * - Description : Returns connection object
	 ****************************************************/

	public Connection obtainConnection() throws MobileException {
		try {
			connection = dataSource.getConnection();
			if(connection!=null)
				myLogger.info("Connection Obtained!");
			else
				myLogger.error("Connection failed!!");
		} catch (SQLException e) {
			myLogger.error("Connection Failed!");
			throw new MobileException(" Database connection problem : "+e.getMessage());
		}
		return connection;
	}

	/****************************************************
	 * - Method Name:loadProperties() 
	 * - Return Type : Properties object 
	 * - Author : Capgemini 
	 * - Creation Date : 09/11/2016 
	 * - Description : Returns Properties object
	 ****************************************************/
	private Properties loadProperties() throws IOException {

		if (props == null) {
			Properties newProps = new Properties();
			String fileName = "resources/jdbc.properties";

			InputStream inputStream = new FileInputStream(fileName);
			newProps.load(inputStream);

			inputStream.close();

			return newProps;
		} else {
			return props;
		}
	}

	/****************************************************
	 * - Method Name:prepareDataSource() 
	 * - Return Type : OracleDataSource object  
	 * - Author : Capgemini 
	 * - Creation Date : 09/11/2016 
	 * - Description : Returns OracleDataSource object
	 ****************************************************/
	private OracleDataSource prepareDataSource() throws SQLException {

		if (dataSource == null) {
			if (props != null) {
				String connectionURL = props.getProperty("url");
				String username = props.getProperty("username");
				String password = props.getProperty("password");

				dataSource = new OracleDataSource();
				dataSource.setURL(connectionURL);
				dataSource.setUser(username);
				dataSource.setPassword(password);
			}
		}
		return dataSource;
	}
	
}

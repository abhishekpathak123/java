package com.capgemini.mobile.test;

import static org.junit.Assert.fail;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.mobile.dao.MobileDaoImpl;

public class DaoTest {
	MobileDaoImpl mobileDao;
	@BeforeClass
	public  void testMobDaoImpl(){
		mobileDao= new MobileDaoImpl();
	}
	@Test
	public void testInsertPurchaseDetails1() {
		
	}

	@Test
	public void testListAllMobiles() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveMobile() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchMobile() {
		fail("Not yet implemented");
	}

}

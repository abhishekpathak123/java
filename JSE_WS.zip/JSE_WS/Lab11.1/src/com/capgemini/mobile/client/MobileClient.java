package com.capgemini.mobile.client;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.mobile.service.IMobileService;
import com.capgemini.mobile.service.MobileServiceImpl;
import com.capgemini.mobiles.bean.Mobile;
import com.capgemini.mobiles.exception.MobileException;
import com.capgemini.purchase.bean.Purchase;


/**
 * @author Shreyanshi
 *
 */
public class MobileClient {
	private static IMobileService mobileService;
	private static Scanner sc;
	private static Mobile mobile = new Mobile();
	private static Logger myLogger = null;
	private static Purchase purchase = new Purchase();
	// step 2 :static blog for logger code
	static {
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(MobileClient.class.getName());
		sc = new Scanner(System.in);
		mobileService = new MobileServiceImpl();
	}

	public static void main(String[] args) {
		int option = 0;
		try {
			// crud
			do {
				option = showMenu(option);
				switch (option) {
				case 1:
					insertPurchaseDetails();
					break;
				case 2:
					listAllMobiles();
					break;
				case 3:
					removeMobile();
					break;
				case 4:
					searchMobile();
					break;
				
				case 5:
					exit();
					break;
				default:
					System.out.println("Wrong option entered"
							+ "\n kindly enter choice (1-6) only");
					break;
				}
			} while (true);
		} catch (MobileException e) {
			myLogger.error("Something went wrong at client code..."
					+ e.getMessage());
			System.out.println("Something went wrong at client code..."
					+ e.getMessage());
		} catch (InputMismatchException e) {
			myLogger.error("Input should be only Numbers ");
			System.out.println("Input should be only Numbers ");
		}
	}// end of main
		// -showing main menu to opt choice from the user

	private static void insertPurchaseDetails() throws MobileException {
		System.out.println("Enter Customer Name");
		String name = sc.next();
		while (true) {
			if (mobileService.validateName(name)) {
				purchase.setcName(name);
				break;
			} else {
				System.err
						.println("**********Please Enter Correct Customer Name:"
								+ "(Must be 3-20 Characters only and 1st Letter UpperCase! ex:Smita**********");
				name = sc.next();
			}
		}
		System.out.println("Enter email");
		String email = sc.next();
		while (true) {
			if (mobileService.validateEmail(email)) {
				purchase.setMailId(email);
				break;
			} else {
				System.err.println("**********Please Enter Correct Email: ex:Smita@gmail.com**********");
				email = sc.next();
			}
		}
		System.out.println("enter phone");
		String phone = sc.next();
		while (true) {
			if (mobileService.validatePhoneNo(phone)) {
				purchase.setPhoneNo(phone);
				break;
			} else {
				System.err
						.println("**********Please Enter Correct Phone Number"
								+ "Only 10 digits "
								+ "First digit can be 7 or 8 or 9"
								+ ": ex:9876543212**********");
				phone = sc.next();
			}
		}
		System.out.println("Enter mobileId among the following Mobile Details given");
		List<Mobile> mobileList = mobileService.listAllMobiles();
		for(Mobile mob:mobileList)
			mob.print();
		int mobileId = sc.nextInt();
	
		while (true) {
			if (mobileService.validateId(mobileId)) {
				purchase.setMobileId(mobileId);
				break;
			} else {
				System.err
						.println("MobileId is not in proper format");
				mobileId = sc.nextInt();
			}
		}
		
		
		purchase.setPurchaseDate(LocalDate.now());
		
		int purchaseId = mobileService.insertPurchaseDetails(purchase);
		if(purchaseId < 0){
			System.err.println("Employee could not be added");
		}
		else{
			System.out.println("Employee Addedd  successfully"
					+ "\n ******Unique Trainee Id : " + purchaseId + " *********");
		}
		
	}

	private static void listAllMobiles() throws MobileException {
		List<Mobile> mobileList = mobileService.listAllMobiles();
		for(Mobile mob:mobileList)
			mob.print();
		
	}

	private static void removeMobile() {
		int mobileId = 0;
		try {
			// accept trainee id to be deleted
			System.out.println("Enter Mobile Id to be deleted");
			mobileId = sc.nextInt();
			
			int status = mobileService.removeMobile(mobileId);
			if (status == 1) {
				myLogger.info("Mobile Details Removed!!");
				System.out.println("Mobile Details Removed!!");
			} else {
				myLogger.error("Mobile Details NOT Removed!!");
				System.err.println("Mobile Details NOT Removed!!");
			}

		} catch (MobileException e) {
			myLogger.error("Something went wrong..."
					+ "while Removing Record..." + e.getMessage());
			System.out.println("Something went wrong..."
					+ "while Removing Record..." + e.getMessage());
		}
		
	}

	private static void searchMobile() {
		int mobileId = 0;
		double maxPrice;
		List<Mobile> mobileList = null;
		double minPrice;
		try {
			System.out.println("Enter Mininmum price");		
			minPrice= sc.nextDouble();
			System.out.println("Enter Maximum price");		
			maxPrice = sc.nextDouble();
			mobileList = mobileService.searchMobile(minPrice, maxPrice);
			// remove the trainee if it is not null
			if (mobileList != null) {
				for(Mobile mob : mobileList)
					mob.print();
			} else {
				myLogger.error("Trainee Not Exists!!");
				System.err.println("Trainee Does Not exists!!");
			}
		} catch (MobileException e) {
			myLogger.error("Something went wrong..."
					+ "while Searching Record..." + e.getMessage());
			
			
			System.out.println("Something went wrong..."
					+ "while Searching Record..." + e.getMessage());
		}
		
	}

	private static void exit() {
		// TODO Auto-generated method stub
		
	}

	private static int showMenu(int option) throws MobileException {
		System.out.println("\n_____________________________________\n"
				+ "\nMobile & Purchase Details\n"
				+ "\n_____________________________________\n"

				+ "\nEnter your Choice (1-6)\n" 
				+ "\n 1. Add Purchase Details"
				+ "\n 2. Display All Mobile Details"
				+ "\n 3. Remove Mobile Details" 
				+ "\n 4. Search Trainee Details"
				+ "\n 5. Exit"
				+ "\n_____________________________________\n");
		option = sc.nextInt();

		return option;
	}
	

	
}

/**
 * 
 */
package com.capgemini.mobile.service;

import java.util.List;

import com.capgemini.mobiles.bean.Mobile;
import com.capgemini.mobiles.exception.MobileException;
import com.capgemini.purchase.bean.Purchase;

/**
 * @author shreya
 *
 */
public interface IMobileService {
	public int insertPurchaseDetails(Purchase purchase)throws MobileException;
	public List<Mobile> listAllMobiles()throws MobileException;
	public int removeMobile(int mobileId)throws MobileException;
	public  List<Mobile> searchMobile(double minPrice,double maxPrice)throws MobileException;
	
	
	//validate methods
	public boolean validateId(int id)throws MobileException;
	public boolean validateName(String input)throws MobileException;
	public boolean validatePhoneNo(String phone)throws MobileException;
	public boolean validateEmail(String input)throws MobileException;
	/*public boolean validateDate(String dob)throws MobileException;*/
}

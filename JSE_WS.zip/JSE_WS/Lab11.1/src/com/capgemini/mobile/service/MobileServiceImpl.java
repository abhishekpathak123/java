package com.capgemini.mobile.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.mobile.dao.IMobileDao;
import com.capgemini.mobile.dao.MobileDaoImpl;
import com.capgemini.mobile.service.IMobileService;
import com.capgemini.mobiles.bean.Mobile;
import com.capgemini.mobiles.exception.MobileException;
import com.capgemini.purchase.bean.Purchase;

public class MobileServiceImpl implements IMobileService {
	private static IMobileDao mobileDao;
	static{
		mobileDao = new MobileDaoImpl();
	}
	@Override
	public int insertPurchaseDetails(Purchase purchase) throws MobileException {
		return mobileDao.insertPurchaseDetails(purchase);
	}

	@Override
	public List<Mobile> listAllMobiles() throws MobileException {
		
		return mobileDao.listAllMobiles();
	}

	@Override
	public int removeMobile(int mobileId) throws MobileException {
		// TODO Auto-generated method stub
		return mobileDao.removeMobile(mobileId);
	}

	@Override
	public List<Mobile> searchMobile(double minPrice, double maxPrice)
			throws MobileException {
		// TODO Auto-generated method stub
		return mobileDao.searchMobile(minPrice, maxPrice);
	}

	@Override
	public boolean validateId(int id) throws MobileException {
		String input = String.valueOf(id);

		// creating regex pattern String
		String patternStr = "^[0-9]{4}$";// only 4 digits
		// Now create Pattern object.

		Pattern pattern = Pattern.compile(patternStr);
		// Now create matcher object.
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}

	@Override
	public boolean validateName(String input) throws MobileException {
		// creating regex pattern String
				String patternStr = "^[A-Z][a-z]{2,20}$";
				// 3-20 char, first letter must be in caps
				
				// Now create Pattern object.
				Pattern pattern = Pattern.compile(patternStr);
				// Now create matcher object.
				Matcher matcher = pattern.matcher(input);
				//now matcher matches
				return matcher.matches();
	}

	@Override
	public boolean validatePhoneNo(String phoneNo) throws MobileException {
		String input = String.valueOf(phoneNo);
		// creating regex pattern String
		String patternStr = "^[789][0-9]{9}$";
		// 10 digits phone number
		// 1st number must start with 7 or 8 or 9
		// followed by 9 digits
		// Now create matcher object.

		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}

	@Override
	public boolean validateEmail(String input) throws MobileException {
		String patternStr = 
				"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		// must be in proper email format
		// Now create matcher object.

		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}

	/*@Override
	public boolean validateDate(String purchaseDate) throws MobileException {
		String dobRegex = "(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)";
		// formatting String dob to LocalDate
		DateTimeFormatter formatter = 
				DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate enteredDate = LocalDate.parse(purchaseDate, formatter);
		// student should be min 21 years
		LocalDate today = LocalDate.now();
		LocalDate expectedDate = today.minusYears(20);
		Pattern dobPatter = Pattern.compile(dobRegex);
		Matcher dobMatcher = dobPatter.matcher(purchaseDate);
		if (dobMatcher.matches()) {
			if (enteredDate.isBefore(expectedDate)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}*/

}

/**
 * 
 */
package com.capgemini.mobile.dao;

import java.util.List;

import com.capgemini.mobiles.bean.Mobile;
import com.capgemini.mobiles.exception.MobileException;
import com.capgemini.purchase.bean.Purchase;

/**
 * @author shreya
 *
 */
public interface IMobileDao {
	public int insertPurchaseDetails(Purchase purchase)throws MobileException;
	public List<Mobile> listAllMobiles()throws MobileException;
	public int removeMobile(int mobileId)throws MobileException;
	public  List<Mobile> searchMobile(double minPrice,double maxPrice)throws MobileException;
	public int getUniquePurchaseId()throws MobileException;
	public int getMobileQuantity(int mobileId)throws MobileException;
	public int updateMobileQuantity(int mobileId,int quantity)throws MobileException;
}

/**
 * 
 */
package com.capgemini.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.jdbc.util.DBUtil;
import com.capgemini.mobiles.bean.Mobile;
import com.capgemini.mobiles.exception.MobileException;
import com.capgemini.purchase.bean.Purchase;

/**
 * @author shreya
 *
 */
public class MobileDaoImpl implements IMobileDao {
	private Connection connection;
	private static Logger myLogger = null;
	
	
	static {
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(MobileDaoImpl.class.getName());
	}
	
	public MobileDaoImpl() {
		try {
			connection = new DBUtil().obtainConnection();
			myLogger.info("Connection Obtained ... at DAO");
		} catch (MobileException e) {
			myLogger.error("ERROR : " + e);
			System.err.println(e.getMessage());
		}
	}
	@Override
	public int insertPurchaseDetails(Purchase purchase) throws MobileException {
		myLogger.info("insertPurchaseDetails() invoked in EmployeeDaoImpl!!");
		System.out.println("Adding Employee record.... Kindly have patience!!");
		String sql = "insert into purchasedetails values(purchase_seq.NEXTVAL,?,?,?,?,?)";
		PreparedStatement pst = null;
		int insertRec = 0;
		int purchaseId = 0;
		MobileDaoImpl mobileDao = new MobileDaoImpl();//because calling 3 funcs
		int mobileId = purchase.getMobileId();
		int quantity = mobileDao.getMobileQuantity(mobileId);
		try {// obtain ps
			
			connection.setAutoCommit(false);// transaction starts
			if(quantity > 0){
				
				pst = connection.prepareStatement(sql);
				// set the values for place holders
				pst.setString(1, purchase.getcName());
				pst.setString(2, purchase.getMailId());
				pst.setString(3, purchase.getPhoneNo());
				pst.setDate(4, java.sql.Date.valueOf(purchase.getPurchaseDate()));
				pst.setInt(5, mobileId);
				insertRec = pst.executeUpdate();
				purchaseId = getUniquePurchaseId();
				purchase.setPurchaseId(purchaseId);
				
				if(insertRec > 0){
					
					int updateRec = mobileDao.updateMobileQuantity(mobileId,quantity-1);
				}else{
					myLogger.error("Not able to insert purchase details of mobileId");
				}
				connection.commit();
				
			}
			else{
				myLogger.error(mobileId+" is not in stock");
			}
		}catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Inserting Trainee failed  "
					+ e.getMessage());
			throw new MobileException("ERRROR :  Inserting Trainee failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Inserting Trainee failed "
						+ e.getMessage());
				throw new MobileException(
						"ERRROR : Inserting Trainee failed " + e.getMessage());
			}}
		return purchaseId;
	}

	@Override
	public List<Mobile> listAllMobiles() throws MobileException {
		ArrayList<Mobile> mobileList = null;
		Statement st = null;
		ResultSet rs = null;
		Mobile mobile = null;
		String sql = "select * from mobiles";
		try {
			// obtain st
			st = connection.createStatement();
			rs = st.executeQuery(sql);
			mobileList = new ArrayList<>();
			while (rs.next()) {
				mobile = new Mobile();
				// fetch the column data
				// and set to the trainee object
				mobile.setMobileId(rs.getInt(1));
				mobile.setName(rs.getString(2));
				mobile.setPrice(rs.getDouble(3));
				mobile.setQuantity(rs.getInt(4));
				
				mobileList.add(mobile);
			}
		} catch (SQLException e) {
			myLogger.error("TraineeList not found , error occured : "
					+ e.getMessage());
			throw new MobileException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("TraineeList not found , error occured :"
						+ e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return mobileList;
	}

	@Override
	public int removeMobile(int mobileId) throws MobileException {
		myLogger.info("------------------Deleting Traineeloyee Records----------------");
		PreparedStatement ps = null;
		String sql = "delete from mobiles where mobileid=?";// '?'
		int noOfRec = 0; // placeholder
		try {
			// start the transaction boundary
			connection.setAutoCommit(false);
			// obatain ps object
			ps = connection.prepareStatement(sql);
			// prepare the pre-compiled statement
			// now we will set the dynamic(runtime) values of ps
			// placeholder-1
			ps.setInt(1, mobileId);
			// execute the insert query(DML)-executeUpdate()
			noOfRec = ps.executeUpdate();
			connection.commit();// transaction ends
		} catch (SQLException e) {
			throw new MobileException("Issue in Deleting emp : " + e);
		} finally {
			if (ps != null)
				try {
					ps.close();
					connection.rollback();// if something wrong then rollback
				} catch (SQLException e) {
					throw new MobileException(
							"Issue while closing resource, which are null");
				}
		}
		return noOfRec;
	}

	@Override
	public  List<Mobile> searchMobile(double minPrice, double maxPrice)
			throws MobileException {
		myLogger.info("searchMobile() in TraineeDaoImpl invoked!!");
		String sql = "SELECT * FROM mobiles WHERE price BETWEEN ? AND ? ";
		Mobile mobile = null;
		ArrayList<Mobile> mobileList = null;
		PreparedStatement pst = null;
		
		try {
			// obtaining pst
			mobileList = new ArrayList<>();
			pst = connection.prepareStatement(sql);
			pst.setDouble(1, minPrice);
			pst.setDouble(2, maxPrice);
			ResultSet rs = pst.executeQuery();// executing the sql
			while (rs.next()) {
				myLogger.info("Mobile record found ");
				// create the object of trainee
				mobile = new Mobile();
				// mapping the value from db to trainee object
				mobile.setMobileId(rs.getInt(1));
				mobile.setName(rs.getString(2));
				mobile.setPrice(rs.getDouble(3));
				mobile.setQuantity(rs.getInt(4));
				mobileList.add(mobile);
				
			} 
		} catch (SQLException e) {
			myLogger.error("ERRROR " + "Searching Mobile details failed "
					+ e.getMessage());
			throw new MobileException("Searching Mobile details failed "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ERRROR " + "Searching Mobile details failed "
						+ e.getMessage());
				throw new MobileException(
						"Searching Mobile details failed " + e.getMessage());
			}
		}
		return mobileList;
		
		
	}

	@Override
	public int getUniquePurchaseId() throws MobileException {
		myLogger.info("Generating unique TraineeId");
		String sql = "SELECT purchase_seq.CURRVAL FROM dual";
		int purchaseId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				purchaseId = rs.getInt(1);
				myLogger.info("auto-generated purchaseId by sequence : "
						+ purchaseId);
			} else {
				myLogger.error("purchaseId not auto generated , error occured ");
			}
		} catch (SQLException e) {
			myLogger.error("purchaseId not auto generated , error occured : "
					+ e.getMessage());
			throw new MobileException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("purchaseId not auto generated , error occured :"
						+ e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		
		return purchaseId;
	}

	@Override
	public int getMobileQuantity(int mobileId) throws MobileException {
		int qty = 0;
		
		String sql = "SELECT quantity from mobiles where mobileid=?";
		PreparedStatement pst = null;
		try {
			pst = connection.prepareStatement(sql);
			pst.setInt(1, mobileId);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				myLogger.info("mobile record found");
				qty = rs.getInt("quantity");
			}else{
				myLogger.error("ERROR"+"mobileid not found");
			}
			
		} catch (SQLException e) {
			myLogger.error("mobileid not found , error occured : "
					+ e.getMessage());
			throw new MobileException(e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("mobileid not found , error occured :"
						+ e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return qty;
	}

	@Override
	public int updateMobileQuantity(int mobileId, int quantity)
			throws MobileException {
		Mobile mobile = new Mobile();
	
		
		String sql = "update mobiles set quantity = quantity - 1 where mobileid=?";
		PreparedStatement pst = null;
		int result = 0;
		try {// obtain ps
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);
			pst.setInt(1, mobileId);
			result = pst.executeUpdate();
			myLogger.info("Mobile Id : " + mobileId + " ,updated");

			connection.commit();
			
		
	}catch (SQLException e) {
		myLogger.error("ERRROR :  " + "Updating Trainee failed  "
				+ e.getMessage());

		throw new MobileException("ERRROR :  Updating Trainee failed  "
				+ e.getMessage());
	} finally {
		try {
			if (pst != null)
				pst.close();
			// if exception then transaction will rollback
			connection.rollback();
		} catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Updating Trainee failed "
					+ e.getMessage());
			throw new MobileException("ERRROR : Updating Trainee failed "
					+ e.getMessage());
		}
		}
		return result;
	}
	
}

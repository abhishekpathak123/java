/**
 * 
 */
package com.capgemini.purchase.bean;

import java.time.LocalDate;



/**
 * @author shreya
 *
 */
public class Purchase {
	private int purchaseId;
	private String cName;
	private String mailId;
	private String phoneNo;
	private LocalDate purchaseDate;
	private int mobileId;
	public Purchase() {
		// TODO Auto-generated constructor stub
	}
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	@Override
	public String toString() {
		return "Purchase [purchaseId=" + purchaseId + ", cName=" + cName
				+ ", mailId=" + mailId + ", phoneNo=" + phoneNo
				+ ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId
				+ "]";
	}
	public Purchase(int purchaseId, String cName, String mailId,
			String phoneNo, LocalDate purchaseDate, int mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.cName = cName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}
	public void print() {
		System.out.println("\n________________________________________"
				+ "\n	Purchase Details					"
				+ "\n________________________________________"
				+ "\n	Purchase Id 	    	: " + purchaseId
				+ "\n	Customer Name			: " + cName
				+ "\n	Customer MailId    	 	: " + mailId
				+ "\n	Customer PhoneNo		: " + phoneNo
				+ "\n	Customer Purchase Date	: " + purchaseDate
				+ "\n	Mobile Id 	    		: " + mobileId
				+ "\n________________________________________");
	}
}

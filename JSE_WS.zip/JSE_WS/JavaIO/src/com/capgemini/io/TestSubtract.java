/**
 * 
 */
package com.capgemini.io;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author shreya
 *
 */
public class TestSubtract {

	@Test
	public void testSub() {
		int result = 15-10;
		assertEquals(5, result);
	}

}

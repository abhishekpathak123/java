/**
 * 
 */
package com.capgemini.io;

import java.io.IOException;

/**
 * @author shreya
 *
 */
public class DemoIO1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String name;
		byte[] buffer;
		buffer = new byte[100];
		try{
			System.out.println("Enter your name: ");
			int length = System.in.read(buffer);
			System.out.println("Bytes Read: "+length);
			name = new String(buffer,0,length).trim();
			System.out.println("Hello "+name);
		}catch(IOException ex){
			System.out.println("Error :"+ex.getMessage());
		}

	}

}

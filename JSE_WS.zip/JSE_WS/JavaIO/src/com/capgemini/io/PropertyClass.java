/**
 * 
 */
package com.capgemini.io;

import java.util.Enumeration;
import java.util.Properties;

/**
 * @author shreya
 *
 */
public class PropertyClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Properties ps = System.getProperties();
		System.out.println("Operating System: "+ps.getProperty("os.name"));
		System.out.println("OS Arch: "+ps.getProperty("os.arch"));
		
		Enumeration<Object> names = ps.keys();
		while(names.hasMoreElements()){
			String key = names.nextElement().toString();
			String value = ps.getProperty(key);
			System.out.println(key +" = "+value);
		}

	}

}

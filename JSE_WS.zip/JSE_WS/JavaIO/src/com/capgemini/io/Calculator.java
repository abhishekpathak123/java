/**
 * 
 */
package com.capgemini.io;

/**
 * @author shreya
 *
 */
public class Calculator {

	public static int divide(int divisor)
	{
		int result = 0;
		result = 100/divisor;
		return result;
	}

}

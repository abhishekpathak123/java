package com.capgemini.io;
import java.io.*;
/**
 * @author shreya
 *
 */
public class LineReader {
	public static void main(String[] args) {
		try{
			FileReader rd = new FileReader("P:\\data\\input.txt");
			BufferedReader br = new BufferedReader(rd);
			LineNumberReader ln = new LineNumberReader(br);
			String line = ln.readLine();
			while (line != null) {
				System.out.println(ln.getLineNumber()+" "+line);
				line = ln.readLine();
				
			}
		}catch(IOException ex){
			ex.printStackTrace();
		}
	}
}

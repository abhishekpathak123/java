/**
 * 
 */
package com.capgemini.io;

import java.io.File;
import java.util.Date;


/**
 * @author shreya
 *
 */
public class FileDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String str = "P:\\data\\input.txt";
		File file = new File(str);
		System.out.println("Is it a file? "+file.isFile());
		System.out.println("Is it a folder? "+file.isDirectory());
		System.out.println("Last change :"+new Date(file.lastModified()));

	}

}

/**
 * 
 */
package com.capgemini.io;

import java.io.IOException;
import java.util.Properties;

/**
 * @author shreya
 *
 */
public class ReadThemAll {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		Properties ps = new Properties();
		ps.load(ReadThemAll.class.getResourceAsStream("db.properties"));
		System.out.println("User "+ps.getProperty("db.user"));
		System.out.println("Database "+ps.getProperty("db.name"));

	}

}

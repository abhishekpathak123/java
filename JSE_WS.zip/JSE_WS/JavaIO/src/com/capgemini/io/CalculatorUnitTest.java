/**
 * 
 */
package com.capgemini.io;

import static org.junit.Assert.*;


import java.util.Arrays;
import java.util.Collection;





import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

/**
 * @author shreya
 *
 */
@RunWith(Parameterized.class)
public class CalculatorUnitTest {

		@Parameterized.Parameters
		public static Collection data()
		{
			return Arrays.asList(new Object[][] {{50,4},{100,1},{50,2},{25,4},{5,20}});
		}
		private int input;
		private int expected;
		public CalculatorUnitTest(int input,int expected)
		{
			this.input = input;
			this.expected = expected;
		}
		public void TestMethos()
		{
			System.out.println("Running Parameterized Tests");
			assertEquals(expected, Calculator.divide(input));
		}

	

}

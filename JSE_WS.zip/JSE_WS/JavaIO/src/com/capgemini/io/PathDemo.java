/**
 * 
 */
package com.capgemini.io;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author shreya
 *
 */
public class PathDemo {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		Path path = Paths.get("P:\\data\\input1.txt");
		System.out.println(path.getNameCount());
		System.out.println(path.getFileName());
		System.out.println(path.getRoot());
		File file = path.toFile();
		System.out.println("Size of File :"+file.length());
		Files.createFile(path);
	}

}

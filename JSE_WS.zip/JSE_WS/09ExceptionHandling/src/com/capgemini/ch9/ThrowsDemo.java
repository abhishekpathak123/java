/**
 * 
 */
package com.capgemini.ch9;

/**
 * @author shreya
 *
 */
public class ThrowsDemo {
		public static void main(String[] args) throws ArithmeticException{
			/*int n1,n2;
			n1 = 10; 
			n2 = 0;
			double div = n1/n2;
			System.out.println("div is : "+div);*/
			try {
				sayHello(null);
			} catch (NullPointerException e) {
				System.out.println("Object is not initialized..." + e.getMessage());
				/*e.printStackTrace();*/
			}
		}

		private static void sayHello(String string) throws NullPointerException {
			System.out.println("Hello , "+string.toUpperCase());
		}
}

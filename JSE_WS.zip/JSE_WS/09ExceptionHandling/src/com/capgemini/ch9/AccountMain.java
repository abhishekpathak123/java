/**
 * 
 */
package com.capgemini.ch9;

import com.capgemini.ch9.exception.LowBalanceException;

/**
 * @author shreya
 *
 */
public class AccountMain {

	/**
	 * @param args
	 * @throws LowBalanceException 
	 */
	public static void main(String[] args) throws LowBalanceException {
		Accounts a1 = new Accounts(101,"Shreya", 1000);
		try {
			a1.withDraw(1100);
		} catch (LowBalanceException e) {
			System.err.println(e.getMessage());
		}
	}

}

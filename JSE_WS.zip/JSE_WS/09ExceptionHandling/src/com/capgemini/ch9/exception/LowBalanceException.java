/**
 * 
 */
package com.capgemini.ch9.exception;

/**
 * @author shreya
 *
 */
public class LowBalanceException extends Exception {

	
	private static final long serialVersionUID = -918876851357599978L;

	public LowBalanceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LowBalanceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}

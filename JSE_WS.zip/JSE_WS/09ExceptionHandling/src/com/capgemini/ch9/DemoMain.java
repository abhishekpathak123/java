/**
 * 
 */
package com.capgemini.ch9;

/**
 * @author shreya
 *
 */
public class DemoMain {
		public static void main(String[] args) {
			int n1, n2;
			double div = 0;
			DemoMain d1 = null;
			//accepting nos from command line arg
			try {
				d1.sayHello("Shreya");
			n1 = Integer.parseInt(args[0]);
			n2 = Integer.parseInt(args[1]);
			
				div = n1/n2;
			} catch (ArithmeticException e) {
				/*e.printStackTrace();*///at development time
				System.out.println("Number cannot be divisible by zero");
			}catch (ArrayIndexOutOfBoundsException e) {
				System.out.println("Array values not passed through command Line");
			}catch (NumberFormatException e) {
				System.out.println("Input should be only numbers... "+e.getMessage());
			}catch (NullPointerException e) {
				System.out.println("Object should be initialized");
			}
			catch (Exception e) {
				System.out.println("Sorry Boss!! Something went wrong");
				e.printStackTrace();
			}finally{
				System.out.println("Div is: "+div);
			}
			
		}
		public void sayHello(String name){
			System.out.println("Hello ,"+name);
		}
}

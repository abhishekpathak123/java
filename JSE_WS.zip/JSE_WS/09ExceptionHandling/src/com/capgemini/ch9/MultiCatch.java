package com.capgemini.ch9;

public class MultiCatch {

	public static void main(String[] args) {
		int n1,n2;
		double div=0;
		try {
			n1=Integer.parseInt(args[0]);
			n2=Integer.parseInt(args[1]);		
			div=n1/n2;
		} catch (ArithmeticException |
				ArrayIndexOutOfBoundsException |
				NumberFormatException| 
				NullPointerException 
				e) {
			System.out.println("Sorry Boss!! "
					+ "Something went wrong..."
					+e.getMessage());
			//e.printStackTrace();
		}
		finally{
			System.out.println("Div is: "+div);			
		}
	}

}

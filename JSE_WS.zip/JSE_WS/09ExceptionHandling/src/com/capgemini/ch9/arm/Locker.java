/**
 * 
 */
package com.capgemini.ch9.arm;

/**
 * @author Smita
 *
 */
public class Locker implements AutoCloseable{
	public void open(){
		System.out.println("....Opening the Locker :) ");
	}

	public void close(){
		System.out.println("....Closing the Locker :( ");
	}
}

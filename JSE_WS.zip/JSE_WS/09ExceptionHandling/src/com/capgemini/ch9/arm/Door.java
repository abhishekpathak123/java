/**
 * 
 */
package com.capgemini.ch9.arm;

/**
 * @author Smita
 *
 */
//or Closeable
public class Door implements AutoCloseable{
	public void open(){
		System.out.println("....Opening the Door :) ");
	}
	@Override
	public void close(){
		System.out.println("....Closing the Door :( ");
	}
}

/**
 * 
 */
package com.capgemini.ch9.arm;

/**
 * @author Smita
 *
 */
public class DoorClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//try with resource block
		//can only be used for classes which implements
		//AutoClosable or Closeable interface
		
		try(    Door myDoor = new Door();
				Locker locker = new Locker();
			){
			myDoor.open();
			locker.open();
		}
		//myDoor.close();

	}

}

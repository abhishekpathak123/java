/**
 * 
 */
package com.capgemini.ch9;

import com.capgemini.ch9.exception.LowBalanceException;

/**
 * @author Smita
 *
 */
public class Accounts {
	int accId;
	String accHolderName;
	double bal;
	public Accounts() {
		// TODO Auto-generated constructor stub
	}
	public void withDraw(double amount) throws LowBalanceException{
		if(bal < amount){
			throw new LowBalanceException(
					"Balance is lower than amount!!" + 
			"\n Your current balance is :"+bal
			+"\n Trying to withdraw "+amount);
		}else{
		bal-=amount;
		System.out.println(" Withdrawal successful !!!"
				+ "\n Balance After Withdrawal is : "+bal);
		}
	}
	/**
	 * @param accId
	 * @param accHolderName
	 * @param bal
	 */
	public Accounts(int accId, String accHolderName, double bal) {
		super();
		this.accId = accId;
		this.accHolderName = accHolderName;
		this.bal = bal;
	}
	/**
	 * @return the accId
	 */
	public int getAccId() {
		return accId;
	}
	/**
	 * @param accId the accId to set
	 */
	public void setAccId(int accId) {
		this.accId = accId;
	}
	/**
	 * @return the accHolderName
	 */
	public String getAccHolderName() {
		return accHolderName;
	}
	/**
	 * @param accHolderName the accHolderName to set
	 */
	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}
	/**
	 * @return the bal
	 */
	public double getBal() {
		return bal;
	}
	/**
	 * @param bal the bal to set
	 */
	public void setBal(double bal) {
		this.bal = bal;
	}
}	

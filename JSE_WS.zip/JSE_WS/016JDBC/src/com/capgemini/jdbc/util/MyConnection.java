package com.capgemini.jdbc.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author shreya
 *
 */
public class MyConnection {
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String driver="oracle.jdbc.driver.OracleDriver";
		String username="system";
		String password="sys";
		//step 1 : load register the driver
		//Class.forName(driver);//to load the class dynamically
		System.out.println("Driver loaded and registered!");
		//step 2 : obtain the connection
		Connection connection = DriverManager.getConnection(url, username, password);
		if(connection != null)
				System.out.println("Connection obtained");
		else
			System.out.println("Connection not obtained");
	}
}

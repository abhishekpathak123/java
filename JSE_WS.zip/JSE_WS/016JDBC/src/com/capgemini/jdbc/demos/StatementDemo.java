package com.capgemini.jdbc.demos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.capgemini.jdbc.exception.MyException;
import com.capgemini.jdbc.util.DBUtil;

/**
 * @author shreya
 *
 */
public class StatementDemo {
	public static void main(String[] args) throws MyException {
		Connection con = null;
		try{
		con = new DBUtil().obtainConnection();
		if(con != null)
				System.out.println("Connection Obtained!!");
		else
				System.out.println("Connection NOT Obtained!!");
		}catch(MyException e){
			System.out.println(e);
		}
//execute simple query
		Statement st = null;
		ResultSet rs = null;
		Scanner sc = new Scanner(System.in);
		String sql = "select * from myemp";
		
//prepared statement
		PreparedStatement pst = null;
		String insertsql = "insert into myemp values"+
								"(?,?,?)";//placeholder
		try{
			pst = con.prepareStatement(insertsql);
			System.out.println("Enter emp Id");
			pst.setInt(1, sc.nextInt());
			System.out.println("Enter emp Name");
			pst.setString(2, sc.next());
			System.out.println("Enter emp Salary");
			pst.setDouble(3, sc.nextDouble());
			
			
			//execute DML statement
			int noOfRec = pst.executeUpdate();
			if(noOfRec > 0)
				System.out.println(noOfRec + "...Emp Record inserted!");
			else
				System.out.println("Emp Record NOT inserted");
			String updateSql = "update myemp set emp_name=?"
									+"where emp_id=?";
			pst.close();
			pst = con.prepareStatement(updateSql);
			//set place holders values
			System.out.println("Enter new emp Name");
			pst.setString(1, sc.next());
			System.out.println("Enter emp Id");
			pst.setInt(2, sc.nextInt());
			noOfRec = pst.executeUpdate();
			if(noOfRec > 0)
				System.out.println(noOfRec + "...Emp Record updated!");
			else
				System.out.println("Emp Record NOT updated");
			pst.close();
			
			String delSql = "delete from myemp where emp_id=?";
			pst = con.prepareStatement(delSql);
			System.out.println("Enter emp Id");
			pst.setInt(1, sc.nextInt());
			
			noOfRec = pst.executeUpdate();
			if(noOfRec > 0)
				System.out.println("Deleted");
			else
				System.out.println("Cannot deleted");
			pst.close();
			
		}catch (SQLException e){
			throw new MyException("Problem in obtaining"
					+ "statement object..." +e.getMessage());
		}finally{
			if(pst != null)
				try{
					pst.close();
				}catch(SQLException e){
					throw new MyException("Problem in Closing"
							+ "statement object already closed" +"..."+e.getMessage());
				}
		}
		
		try{
			st = con.createStatement();
			rs = st.executeQuery(sql);
			//Iterate through rs
			while(rs.next()){
				System.out.println(rs.getInt(1)+"\t"+rs.getString("emp_name")+"\t"+rs.getDouble(3));
			}
			
		}catch (SQLException e){
			throw new MyException("Problem in obtaining"
					+ "statement object..." +e.getMessage());
		}finally{
			if(st != null)
				try{
					st.close();
				}catch(SQLException e){
					throw new MyException("Problem in Closing"
							+ "statement object already closed" +"..."+e.getMessage());
				}
		}
	}

}

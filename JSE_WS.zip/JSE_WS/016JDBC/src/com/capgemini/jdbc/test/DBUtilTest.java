/**
 * 
 */
package com.capgemini.jdbc.test;

import static org.junit.Assert.*;

import java.sql.Connection;


import org.junit.AfterClass;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.jdbc.exception.MyException;
import com.capgemini.jdbc.util.DBUtil;

/**
 * @author shreya
 *
 */
public class DBUtilTest {
	static DBUtil dbUtil;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUp() throws Exception {
		dbUtil = new DBUtil();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDown() throws Exception {
	}

	@Test
	public void testConnection() throws MyException {
		Connection conn = dbUtil.obtainConnection();
		assertNull("Connection NOT Obtained",conn);
	}

}

/**
 * 
 */
package com.capgemini.jdbc.exception;

/**
 * @author shreya
 *
 */
public class MyException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4203949429929605295L;

	public MyException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	

}

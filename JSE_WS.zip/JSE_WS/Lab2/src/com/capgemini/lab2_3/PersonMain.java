/**
 * 
 */
package com.capgemini.lab2_3;

/**
 * @author shreya
 *
 */
public class PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person person = new Person();
		System.out.println(person);
		
		String firstName="Shreyanshi";
		String lastName="Sinha";
		
		char gender = 'F';
		Person person1 = new Person(firstName, lastName, gender);
		
		System.out.println("\n______________________________________________"
						    +"\n 		Person Details"
							+"\n______________________________________________"
							+"\n	First Name  :   "+person1.getFirstName()
							+"\n	Last Name   :   "+person1.getLastName()
							+"\n	Gender      :   "+person1.getGender()	
							+"\n______________________________________________");
						
	}

}

/**
 * 
 */
package com.capgemini.lab2_2;

/**
 * @author shreya
 *
 */
public class CheckNumber {
public static void main(String[] args) {
	int number=Integer.parseInt(args[0]);
	if(number > 0)
	{
		System.out.println(number+" is a Positive number");
	}
	else
	{
		System.out.println(number+" is a Negative number");
	}
}
}

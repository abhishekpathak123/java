/**
 * 
 */
package com.capgemini.lab2_5;

/**
 * @author shreya
 *
 */
public class Person {
	//instance var
	private String firstName;
	private String lastName;
	private Gender gender;//has a relationship
	private long phoneNo;
	//default constructor
	public Person() {
		
		
	}
	public Person(String firstName, String lastName, Gender gender, long phoneNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.phoneNo = phoneNo;
	}
	//toString method
	@Override
	public String toString() {
		return "Person [firstName=" + firstName + ", lastName=" + lastName
				+ ", gender=" + gender + ", phoneNo=" + phoneNo + "]";
	}
	//getters and setters
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	
	
}

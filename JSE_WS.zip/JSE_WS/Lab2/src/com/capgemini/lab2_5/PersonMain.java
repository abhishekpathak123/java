/**
 * 
 */
package com.capgemini.lab2_5;

import java.util.Scanner;

import com.capgemini.lab2_4.Person;

/**
 * @author shreya
 *
 */
public class PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your fname\n");
		String firstName=sc.next();
		System.out.println("Enter your lname\n");
		String lastName=sc.next();
		System.out.println("Enter your gender\n");
		String gen=sc.next().toUpperCase();
		/*char gender=gen.charAt(0);*/
		Gender gender = Gender.valueOf(gen);
		
		
		System.out.println("Enter your mobile number\n");
		long phone = sc.nextLong();
		Person person1 = new Person(firstName, lastName, gender, phone);
		
		display(person1);
	}
	static void display(Person person1)
	{
		System.out.println("\n______________________________________________"
			    +"\n 		Person Details"
				+"\n______________________________________________"
				+"\n	First Name  :   "+person1.getFirstName()
				+"\n	Last Name   :   "+person1.getLastName()
				+"\n	Gender      :   "+person1.getGender()
				+"\n	PhoneNO     :   "+person1.getPhoneNo()
				+"\n______________________________________________");

	}

}

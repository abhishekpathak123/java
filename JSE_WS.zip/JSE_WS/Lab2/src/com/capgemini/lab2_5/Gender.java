/**
 * 
 */
package com.capgemini.lab2_5;

/**
 * @author shreya
 *
 */
public enum Gender {
	M,F;
}

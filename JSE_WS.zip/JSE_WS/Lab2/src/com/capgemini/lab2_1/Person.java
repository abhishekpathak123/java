package com.capgemini.lab2_1;
/**
 * @author shreya
 *
 */
public class Person {
	public static void main(String[] args) {
		String firstName="Divya";
		String lastName="Bharathi";
		char gender='F';
		int age=20;
		float weight=85.5f;
		System.out.println("\n______________________________________________"
						    +"\n 		Person Details"
							+"\n______________________________________________"
							+"\n	First Name  :   "+firstName
							+"\n	Last Name   :   "+lastName	
							+"\n	Gender      :   "+gender	
							+"\n	Age         :   "+age
							+"\n	Weight      :   "+weight
							+"\n______________________________________________");
						
	}
}

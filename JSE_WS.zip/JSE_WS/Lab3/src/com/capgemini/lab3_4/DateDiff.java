/**
 * 
 */
package com.capgemini.lab3_4;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

/**
 * @author shreya
 *
 */
public class DateDiff {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		acceptDate();

	}

	private static void acceptDate() {
		Scanner scan = new Scanner(System.in);
		int days,month,year,days1,month1,year1;
		System.out.println("Enter from date in dd-mm-yyyy format");
		days = scan.nextInt();
		month = scan.nextInt();
		year = scan.nextInt();
		System.out.println("Enter from date in dd-mm-yyyy format");
		days1 = scan.nextInt();
		month1 = scan.nextInt();
		year1 = scan.nextInt();
		LocalDate from = LocalDate.of(year, month, days);
		LocalDate to = LocalDate.of(year1, month1, days1);
		Period period = from.until(to);
		
		System.out.println("Days :"+period.getDays()+"\nMonths :"+period.getMonths()
				+"\nYear :"+period.getYears());
		
		
	}
	

}

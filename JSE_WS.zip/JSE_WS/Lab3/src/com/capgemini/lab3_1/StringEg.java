/**
 * 
 */
package com.capgemini.lab3_1;

import java.util.Scanner;

/**
 * @author shreya
 *
 */
public class StringEg {


	public static void main(String[] args) {
		System.out.println("Please choose an option");
		Scanner scan = new Scanner(System.in);
		
		do{			
			int option=0;
			System.out.println(
					"\n_____________________________________\n"
							+ "\nString Operations\n"
							+"\n_____________________________________\n"

							+ "\nEnter your Choice\n"
							+"\n 1. Concat string"
							+"\n 2. Replace odd with #"
							+"\n 3. Remove duplicate character"
							+"\n 4. Change odd characters to uppercase"
							+"\n 5. Exit"
							+"\n_____________________________________\n");
			option = scan.nextInt();
			switch (option) {
			case 1:concatString();
			break;
			case 2:replaceOdd();
			break;
			case 3:removeDup();
			break;
			case 4:changeOdd();
			break;
			case 5:exit();
			break;
			default:
				System.out.println("Wrong option entered"
						+ "\n kindly enter choice (1-3) only");
				break;
			}
		}while(true);

	}

	private static void concatString() {

		System.out.println("Enter the string");
		Scanner scan = new Scanner(System.in);
		String str = scan.next();
		System.out.println("Concatenated String :"+str.concat(str));

	}
	private static void replaceOdd() {
		System.out.println("Enter the string");
		Scanner scan = new Scanner(System.in);
		String str = scan.next();
		/* int odd=1;*/

		for (int i = 0; i <str.length(); i+=2) {

			str = str.replace(str.charAt(i),'#');

		}
		System.out.println("String Replaced with # :"+str);

	}

	private static void removeDup() {
		System.out.println("Enter the string");
		Scanner scan = new Scanner(System.in);
		String str = scan.next();
		String str2="";
		char str1;
		/*System.out.println("Removed duplicates :"+str.charAt(str.compareTo(str)));
		 */
		for (int i = 0; i < str.length(); i++) {
			str1=str.charAt(i);
			if(str1 != ' '){
				str2 += str1;
				str = str.replace(str1,' ');
			}
		}
		System.out.println("Removed duplicates :"+str2);
	}
	private static void changeOdd() {
		System.out.println("Enter the string");
		Scanner scan = new Scanner(System.in);
		String str = scan.next();
		char ch;
		for (int i = 0; i < str.length(); i++) {
			ch = str.charAt(i);
			if(i % 2==0){
				System.out.print(Character.toUpperCase(ch));
			}
			else{
				System.out.print(str.charAt(i));
			}

		}

	}

	private static void exit() {
		Scanner scan = new Scanner(System.in);
		System.out.println(
				"Thankyou for using"
				+"    Do Visit Again!!!");
		scan.close();
		System.exit(0);

	}



}

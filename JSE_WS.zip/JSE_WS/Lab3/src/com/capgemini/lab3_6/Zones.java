/**
 * 
 */
package com.capgemini.lab3_6;

/**
 * @author shreya
 *
 */
public enum Zones {
	AMERICA/NEW_YORK , EUROPE/LONDON , ASIA/TOKYO , US/PACIFIC,AFRICA/CAIRO , AUSTRALIA/SYDNEY;
	
}

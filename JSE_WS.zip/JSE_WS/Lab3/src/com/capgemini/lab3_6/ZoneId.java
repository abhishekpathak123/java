/**
 * 
 */
package com.capgemini.lab3_6;

import java.time.ZonedDateTime;
import java.util.Scanner;

/**
 * @author shreya
 *
 */
public class ZoneId {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		acceptZoneId();

	}

	private static void acceptZoneId() {
		String zones;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Zone id:\n");
		zones = sc.next();
		Zones zone = Zones.valueOf(zones);
		
	}

}

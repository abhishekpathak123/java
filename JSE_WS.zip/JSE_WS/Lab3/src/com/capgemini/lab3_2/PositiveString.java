/**
 * 
 */
package com.capgemini.lab3_2;

import java.util.Scanner;

/**
 * @author shreya
 *
 */
public class PositiveString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the String");
		String str = scan.next();
		if(check(str)==true){
			System.out.println(str +" is a Positive String");
		}
		else{
			System.out.println(str +" is a Negative String");
		}
	}

	private static boolean check(String str) {
		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			for (int j = i+1; j < str.length(); j++) {
				if(str.charAt(i) <= str.charAt(j)){
					count++;
				}
			}
			if(count > 1){
				return true;
			}
		}
		return false;
	}

}

/**
 * 
 */
package com.capgemini.lab3_5;

import java.time.LocalDate;
import java.util.Scanner;

/**
 * @author shreya
 *
 */
public class ProductPurchase {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		calculateExpiry();

	}

	private static void calculateExpiry() {
		Scanner scan = new Scanner(System.in);
		int day,month,year,waranteeMonths,waranteeYear;
		System.out.println("Enter the product purchase date in dd-mm-yyyy format");
		day = scan.nextInt();
		month = scan.nextInt();
		year = scan.nextInt();
		System.out.println("Enter Warantee period in months and years");
		waranteeMonths = scan.nextInt();
		waranteeYear = scan.nextInt();
		LocalDate period = LocalDate.of(year, month, day);
		period = period.plusMonths(waranteeMonths);
		period = period.plusYears(waranteeYear);
		System.out.println("Your product's warantee expires on "+period);
	}

}

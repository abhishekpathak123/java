/**
 * 
 */
package com.capgemini.lab3_3;

import java.time.*;
import java.util.Scanner;

/**
 * @author shreya
 *
 */
public class DatePrint {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		acceptDate();

	}

	private static void acceptDate() {
		Scanner scan = new Scanner(System.in);
		int days,month,year;
		System.out.println("Enter date in dd-mm-yyyy format");
		days = scan.nextInt();
		month = scan.nextInt();
		year = scan.nextInt();
		LocalDate start = LocalDate.of(year, month, days);
		LocalDate now = LocalDate.now();
		Period period = start.until(now);
		
		System.out.println("Days :"+period.getDays()+"\nMonths :"+period.getMonths()
				+"\nYear :"+period.getYears());
		
	}

}

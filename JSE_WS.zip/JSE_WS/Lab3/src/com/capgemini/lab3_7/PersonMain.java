/**
 * 
 */
package com.capgemini.lab3_7;

import java.util.Scanner;



/**
 * @author shreya
 *
 */
public class PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		 String firstName;
		 String lastName;
		 char gender;
		 System.out.println("Enter ur first name :");
		 firstName = scan.next();
		 System.out.println("Enter ur last name :");
		 lastName = scan.next();
		 System.out.println("gender :");
		 String temp = scan.next();
		 gender = temp.charAt(0);
		 int day,month,year;
		 System.out.println("Enter dobin dd-mm-yyyy format");
		 day = scan.nextInt();
		 month = scan.nextInt();
		 year = scan.nextInt();
		 Person person = new Person(firstName, lastName, gender, day, month, year);
		 System.out.println("\n______________________________________________"
				    +"\n 		Person Details"
					+"\n______________________________________________"
					+"\n	Name        :   "+person.getFullName(firstName,lastName)
					+"\n	Gender      :   "+person.getGender()	
					+"\n	Age         :   "+person.calAge(day, month, year)
					+"\n______________________________________________");
		

	}

	

}

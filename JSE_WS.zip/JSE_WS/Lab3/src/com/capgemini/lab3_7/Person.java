/**
 * 
 */
package com.capgemini.lab3_7;

import java.time.LocalDate;
import java.time.Period;

/**
 * @author shreya
 *
 */
public class Person {
	//instance var
			private String firstName;
			private String lastName;
			private char gender;
			
			public Person(String firstName, String lastName, char gender,
					int day, int month, int year) {
				super();
				this.firstName = firstName;
				this.lastName = lastName;
				this.gender = gender;
				this.day = day;
				this.month = month;
				this.year = year;
			}
			private int day,month,year;
			public int calAge(int day,int month,int year){
				LocalDate now = LocalDate.now();
				LocalDate cal = LocalDate.of(year, month, day);
				Period age = cal.until(now);
				return age.getYears();
			}
			public String getFullName(String firstName,String lastName)
			{
				String name = firstName + " " + lastName;
				return name;
				
			}
			public Person() {
				// TODO Auto-generated constructor stub
			}
			public String getFirstName() {
				return firstName;
			}
			public void setFirstName(String firstName) {
				this.firstName = firstName;
			}
			public String getLastName() {
				return lastName;
			}
			public void setLastName(String lastName) {
				this.lastName = lastName;
			}
			public char getGender() {
				return gender;
			}
			public void setGender(char gender) {
				this.gender = gender;
			}
			public int getDay() {
				return day;
			}
			public void setDay(int day) {
				this.day = day;
			}
			public int getMonth() {
				return month;
			}
			public void setMonth(int month) {
				this.month = month;
			}
			public int getYear() {
				return year;
			}
			public void setYear(int year) {
				this.year = year;
			}
			
}

/**
 * 
 */

/**
 * @author shreya
 *
 */
public class Account {
	private double balance;
	public Account(double initBalance){
		this.balance = initBalance;
	}
	public void deposit(double amt){
		balance += amt;
	}
	public void withdraw(double amt){
		balance -= amt;
	}
	public double getBalance(){
		return balance; 
	}
}

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * 
 */

/**
 * @author shreya
 *
 */
public class AccountTest {
private Account account;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		System.out.println("Creating new account instance");
		account = new Account(500);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		System.out.println("Destroying old account instance");
		account = null;
	}

	/**
	 * Test method for {@link Account#deposit(double)}.
	 */
	@Test
	public void testDeposit() {
		account.deposit(5000);
		assertEquals(5500,account.getBalance(),0.01);
		
	}

	/**
	 * Test method for {@link Account#withdraw(double)}.
	 */
	@Test
	public void testWithdraw() {
		account.withdraw(100);
		assertEquals(400,account.getBalance(),0.01);
	}

}

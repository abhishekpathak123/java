package com.cg.eis.service;

import com.cg.eis.bean.Employee;

/**
 * @author shreya
 *
 */
public interface IEmployeeService {
	public int addEmployeeDetails(Employee employee);
	public void findInsuranceScheme(int sal);
	public Employee searchEmployee(int id);
}

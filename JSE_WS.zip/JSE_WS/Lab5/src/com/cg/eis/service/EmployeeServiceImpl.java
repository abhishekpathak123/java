/**
 * 
 */
package com.cg.eis.service;


import java.util.Scanner;

import com.cg.eis.bean.Employee;

/**
 * @author shreya
 *
 */
public class EmployeeServiceImpl implements IEmployeeService{
	private static Employee employee;
	private static Employee [] employeeList;
	private static int size=0;
	static{
		employee = new Employee();
		employeeList = new Employee[5];
	}
	@Override
	public int addEmployeeDetails(Employee employee) {
		
		employeeList[size++]=employee;
		
		return 1;
	}
	@Override
	public void findInsuranceScheme(int sal) {
		
	
		
		if(sal > 5000 && sal < 20000)
		{
			employee.setDesignation("System Associate");
			employee.setInsuranceScheme("Scheme C");
		}
		else if(sal >=20000 && sal < 40000)
		{
			employee.setDesignation("Programmer");
			employee.setInsuranceScheme("Scheme B");
		}
		else if(sal >=40000)
		{
			employee.setDesignation("Manager");
			employee.setInsuranceScheme("Scheme A");
		}
		else if(sal < 5000)
		{
			employee.setDesignation("Clerk");
			employee.setInsuranceScheme("No Scheme");
		}
		
	}
	@Override
	public Employee searchEmployee(int id) {
		
		
		for (int i = 0; i < employeeList.length; i++) {
			if(employeeList[i].getId()==id){
				employee = employeeList[i];
				employee.print();
				break;
			}
		}
		return employee;
		
		
	}
}

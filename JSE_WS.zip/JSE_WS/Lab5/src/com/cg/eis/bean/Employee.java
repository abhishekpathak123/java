package com.cg.eis.bean;

/**
 * @author shreya
 *
 */
public class Employee {
		private int id;
		private String name;
		public double salary;
		private String designation;
		private String insuranceScheme;
		private static int numId;
		static{
			numId = 1000 + (int)(Math.random()*123.123);
		}
		
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public Employee() {
			
		}
		//overloaded constructor
		public Employee(int id, String name, double salary, String designation,
				String insuranceScheme) {
			super();
			this.id = id;
			this.name = name;
			this.salary = salary;
			this.designation = designation;
			this.insuranceScheme = insuranceScheme;
		}
		//getters and setters
		public String getName() {
			return name;
		}
		public void setName(String name) {
			id = numId++;
			this.name = name;
		}
		public double getSalary() {
			return salary;
		}
		public void setSalary(double salary) {
			this.salary = salary;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getInsuranceScheme() {
			return insuranceScheme;
		}
		public void setInsuranceScheme(String insuranceScheme) {
			this.insuranceScheme = insuranceScheme;
		}
		@Override
		public String toString() {
			return "Employee [id=" + id + ", name=" + name + ", salary="
					+ salary + ", designation=" + designation
					+ ", insuranceScheme=" + insuranceScheme + "]";
		}
		
		public void print() {
			System.out.println("\n______________________________________________"
				    +"\n 		Employee Details"
					+"\n______________________________________________"
					+"\n	Employee Id       :   " +id
					+"\n	Name              :   "+name
					+"\n	Salary            :   "+salary	
					+"\n	Designation       :   "+designation
					+"\n	Scheme            :   "+insuranceScheme
					+"\n______________________________________________");
			
		}
	  
		
}

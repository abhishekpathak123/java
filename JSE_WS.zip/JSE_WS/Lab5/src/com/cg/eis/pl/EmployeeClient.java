/**
 * 
 */
package com.cg.eis.pl;

import java.util.Scanner;



import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.IEmployeeService;

/**
 * @author shreya
 *
 */
public class EmployeeClient{
	private static IEmployeeService employeeService;
	private static Scanner sc;
	private static Employee employee;
	private static Employee[] employeeList;
	//static block to initialize static members
	static{
		sc = new Scanner(System.in);
		employeeService=new EmployeeServiceImpl();
		employee = new Employee();
		employeeList = new Employee[5];
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		do{
			int option=0;
			
			System.out.println(
					"\n_____________________________________\n"
							+ "\nEmployee Details\n"
							+"\n_____________________________________\n"
					
							+ "\nEnter your Choice\n"
							+"\n 1. Add Employee Details"
							+"\n 2. Find Scheme"
							+"\n 3. Display Employee Details"
							+"\n 4. Exit"
					+"\n_____________________________________\n");
			
			option = sc.nextInt();
			
			switch (option) {
			case 1:addEmployeeDetails();
				break;
			case 2:findInsuranceScheme(employee.getSalary());
				break;
			case 3:searchEmployee();
				break;
			case 4:exit();
			break;
			
			default:
				System.out.println("Wrong option entered"
						+ "\n kindly enter choice (1-4) only");
				break;
			}
		}while(true);


	}
	private static Employee searchEmployee() {
		System.out.println("Enter Employee Id to be Searched");
		int employeeId=sc.nextInt();
		//search the trainee weather it exists or not
		employee=employeeService.searchEmployee(employeeId);
		//remove the trainee if it is not null
		if(employee!=null)
		{
			employee.print();
		}else{
			System.out.println("employee Does Not exists!!");
		}
		return employee;
		
	}
	private static void findInsuranceScheme(double salary) {
		if(salary > 5000 && salary < 20000)
		{
			employee.setDesignation("System Associate");
			employee.setInsuranceScheme("Scheme C");
		}
		else if(salary >=20000 && salary < 40000)
		{
			employee.setDesignation("Programmer");
			employee.setInsuranceScheme("Scheme B");
		}
		else if(salary >=40000)
		{
			employee.setDesignation("Manager");
			employee.setInsuranceScheme("Scheme A");
		}
		else if(salary <5000)
		{
			employee.setDesignation("Clerk");
			employee.setInsuranceScheme("No Scheme");
		}
	
		
		
	}
	private static void addEmployeeDetails() {
		System.out.println("Enter employee name :");
		String name = sc.next();
		employee.setName(name);
		System.out.println("Enter salary :");
		Double sal = sc.nextDouble();
		employee.setSalary(sal);
		findInsuranceScheme(sal);
		int status=employeeService.addEmployeeDetails(employee);
		if(status==1)
		{
			System.out.println("employee Addedd  successfully");
			employee.print();
		}else{
			System.out.println("employee Does Not added!!");
		}
	}
	private static void exit() {
		System.out.println(
				"Thankyou for using Trainee App"
				+"    Do Visit Again!!!");
		sc.close();
		System.exit(0);
		
	}
	
	
	
		
}



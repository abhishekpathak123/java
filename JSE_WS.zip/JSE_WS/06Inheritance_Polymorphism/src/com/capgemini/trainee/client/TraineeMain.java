/**
 * 
 */
package com.capgemini.trainee.client;

import com.capgemini.date.MyDate;
import com.capgemini.trainee.java.JavaTrainee;

/**
 * @author shreya
 *
 */
public class TraineeMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JavaTrainee javaTrainee = new JavaTrainee("Shreyanshi", "Sinha", 8758863918l, "shrey@gmail.com", new MyDate(11, 11, 1999), "Hospital_Management", "Spring_JPA");
		javaTrainee.print();

	}

}

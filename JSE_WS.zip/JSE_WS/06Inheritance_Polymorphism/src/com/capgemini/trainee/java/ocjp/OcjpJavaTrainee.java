/**
 * 
 */
package com.capgemini.trainee.java.ocjp;

import com.capgemini.date.MyDate;
import com.capgemini.trainee.java.JavaTrainee;

/**
 * @author shreya
 *
 */
public class OcjpJavaTrainee extends JavaTrainee{
	private String cert;
	public OcjpJavaTrainee() {
		System.out.println("No_arg OcjpJavaTrainee");
	}
	
	public OcjpJavaTrainee(String firstName, String lastName, long phoneno,
			String email, MyDate dob, String project, String tools, String cert) {
		super(firstName, lastName, phoneno, email, dob, project, tools);
		this.cert = cert;
		System.out.println("Overloaded Ocjp constr");
	}

	public String getCert() {
		return cert;
	}
	public void setCert(String cert) {
		this.cert = cert;
	}
	
	
}

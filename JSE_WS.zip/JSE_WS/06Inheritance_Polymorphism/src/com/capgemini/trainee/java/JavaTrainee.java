package com.capgemini.trainee.java;

import com.capgemini.date.MyDate;
import com.capgemini.trainee.Trainee;

public class JavaTrainee extends Trainee {
	private String project;
	private String tools;
	public JavaTrainee() {
		System.out.println("NO-Arg JavaTrainee constructor");
	}
public JavaTrainee(String firstName, String lastName, long phoneno,
			String email, MyDate dob, String project, String tools) {
		super(firstName, lastName, phoneno, email, dob);
		this.project = project;
		this.tools = tools;
		System.out.println("Overloaded trainee constructor");
	}


@Override
public void print() {
	// TODO Auto-generated method stub
	super.print();
	System.out.println("\n Project          :"+project
						+"\n Tools            :"+tools
						+"\n______________________________________________");
}
		

//getters and setters
		public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getTools() {
		return tools;
	}
	public void setTools(String tools) {
		this.tools = tools;
	}
	
}

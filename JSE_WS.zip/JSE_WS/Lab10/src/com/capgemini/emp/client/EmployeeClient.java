/**
 * 
 */
package com.capgemini.emp.client;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.emp.bean.Employee;
import com.capgemini.employee.exception.EmployeeException;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.IEmployeeService;

/**
 * @author shreya
 *
 */
public class EmployeeClient {
	private static IEmployeeService employeeService;
	private static Scanner sc;
	private static Employee employee;
	private static Logger myLogger = null;
		static{
			PropertyConfigurator.configure("resources/log4j.properties");
			myLogger = Logger.getLogger(EmployeeClient.class.getName());
			sc = new Scanner(System.in);
			employeeService=new EmployeeServiceImpl();
			employee = new Employee();
			
		}
			
	public static void main(String[] args) {
		int option=0;
		try{
		do{
			option = showMenu(option);
			
			
			
			
			switch (option) {
			case 1:addEmployee();
			break;
			case 2:updateEmployee();
			break;
			case 3:searchEmployee();
			break;
			case 4:listAllEmployee();
			break;
			case 5:deleteEmployee();
			break;
			case 6:sortBySal();
			break;
			case 7:exit();
			break;
			default:
				System.out.println("Wrong option entered"
						+ "\n kindly enter choice (1-7) only");
				break;
			}
		}while (true);
			
	
		} catch(EmployeeException e){
		myLogger.error("Something went wrong at client code..."
				+ e.getMessage());
		System.out.println("Something went wrong at client code..."
				+ e.getMessage());
		}
	 catch (InputMismatchException e) {
		myLogger.error("Input should be only Numbers ");
		System.out.println("Input should be only Numbers ");
	}
	}
	


	private static int showMenu(int option) throws EmployeeException {
		System.out.println(
				"\n_____________________________________\n"
						+ "\nEmployee Details\n"
						+"\n_____________________________________\n"
				
						+ "\nEnter your Choice\n"
						+"\n 1. Add Employee Details"
						+"\n 2. Update Employee"
						+"\n 3. Search Employee By Scheme"
						+"\n 4. List All Employee"
						+"\n 5. Delete Employee"
						+"\n 6. Sort Employee By salary"
						+"\n 7. Exit"
				+"\n_____________________________________\n");
		option = sc.nextInt();
		return option;
	}


	private static void addEmployee() throws EmployeeException{
		Employee employee=  new Employee();
		System.out.println("Enter employee name:");
		String name = sc.next();
		System.out.println("Emter employee salary");
		Double sal = sc.nextDouble();
		employee.setName(name);
		employee.setSalary(sal);
		employee = employeeService.findInsurance(employee);
		/*try{*/
			int id = employeeService.addEmployee(employee);
		if(id < 0){
			System.err.println("Employee could not be added");
		}
		else{
			System.out.println("Employee Addedd  successfully"
					+ "\n ******Unique Trainee Id : " + id + " *********");
		}
	/*	}catch(EmployeeException e){
			myLogger.error("Employee could not be added"+e.getMessage());
		}*/
		
		
	}

	private static void updateEmployee() throws EmployeeException{
		System.out.println("Enter empId to be updated");
		int empId = sc.nextInt();
	
				
		
			
		employee = employeeService.search(empId);
		// remove the trainee if it is not null
		if (employee != null) {
			System.out.println("Enter empName to be modified");
			String name = sc.next();
			// accept all the trainee details to be updated
			employee.setName(name);
		
			int status = employeeService.updateEmployee(employee);
			if (status == 1) {
				myLogger.info("Employee Updated!!");
				System.out.println("Employee Updated successfully!!");
			} else {
				myLogger.error("Employee NOT Updated!!");
				System.err.println("Employee NOT Updated!!");
			}
		} else {
			System.out.println("Employee Does Not exists!!");
		}
	
		
	}

	private static void searchEmployee() throws EmployeeException{
		System.out.println("Enter the Scheme to be searched");
		Scanner scan = new Scanner(System.in);
		String scheme = scan.nextLine();
		List<Employee> employeeList = new ArrayList<Employee>();
		try{
			employeeList= employeeService.searchEmployee(scheme);
		if(employeeList != null){
		for(Employee emp:employeeList){
			emp.print();
		}
		}
		else
		{
			System.out.println("No employees under that scheme");
		}}
		catch(EmployeeException e){
			System.out.println(e.getMessage());
		}
	}

	private static void listAllEmployee() throws EmployeeException{
		List<Employee> employeeList = new ArrayList<Employee>();
		try {
			employeeList = employeeService.listAllEmployee();
			if(employeeList != null){
				for(Employee emp:employeeList){
					emp.print();
				}
				}
				else
				{
					System.out.println("Cant be sorted");
				}
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
		}
		
	}

	private static void deleteEmployee() throws EmployeeException{
		System.out.println("Enter empId to delete");
		int empId = sc.nextInt();
		int id = 0;
		try {
			id = employeeService.deleteEmployee(empId);
			if(id < 0){
				System.out.println("Error in delete");
			}
			else{
				System.out.println("deleted successfully");
			}
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
		}
		 
		
		
	}

	private static void sortBySal() throws EmployeeException{
		List<Employee> employeeList = new ArrayList<Employee>();
		try {
			 employeeList= employeeService.sort();
			 if(employeeList != null){
					for(Employee emp:employeeList){
						emp.print();
					}
					}
					else
					{
						System.out.println("Cant be sorted");
					}
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
		}
		
	}
	private static void exit() throws EmployeeException{
		myLogger.info("Ending Application at "+LocalDateTime.now());
		System.out.println("Thankyou for using Employee App"
				+ "    Do Visit Again!!!");
		sc.close();
		System.exit(0);
		
	}

	}



/**
 * 
 */
package com.capgemini.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.emp.bean.Employee;
import com.capgemini.employee.exception.EmployeeException;
import com.capgemini.jdbc.util.DBUtil;


/**
 * @author Smita
 *
 */
public class EmployeeDaoImpl implements IEmployeeDao {
	// step 1 :declare Connection and Logger variables
	private Connection connection;
	private static List<Employee> employeeList;
	private static Logger myLogger = null;
	// step 2 :static blog for logger code
	static {
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(EmployeeDaoImpl.class.getName());
		employeeList = new ArrayList<Employee>();
	}

	// step 3 : obtain connection in the constructor
	public EmployeeDaoImpl() {
		try {
			connection = new DBUtil().obtainConnection();
			myLogger.info("Connection Obtained ... at DAO");
		} catch (EmployeeException e) {
			myLogger.error("ERROR : " + e);
			System.err.println(e.getMessage());
		}
	}

	// step 4 : override methods
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.emp.dao.IEmployeeDao#addEmployee(com.capgemini.emp.bean
	 * .Employee)
	 */
	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		myLogger.info("addEmployee() invoked in EmployeeDaoImpl!!");
		System.out.println("Adding Employee record.... Kindly have patience!!");
		String sql = "insert into emp values(myEmp_seq.NEXTVAL,?,?,?,?)";
		PreparedStatement pst = null;
		int result = 0;
		int empId = 0;
		try {// obtain ps
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);// transaction starts

			// set the values for place hodlers
			pst.setString(1, employee.getName());
			pst.setDouble(2, employee.getSalary());
			pst.setString(3,employee.getDesignation());
			pst.setString(4,employee.getInsuranceScheme());
			// execute DML query
			result = pst.executeUpdate();
			empId = getEmployeeId();
			// set the empId of the current employee object
			employee.setId(empId);
			myLogger.info("Employee details getting inserted "
					+ "....unique EmpID : " + empId);

			connection.commit();// if insert successful the commit the
								// transaction
		} catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Inserting Employee failed  "
					+ e.getMessage());
			throw new EmployeeException("ERRROR :  Inserting Employee failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Inserting Employee failed "
						+ e.getMessage());
				throw new EmployeeException(
						"ERRROR : Inserting Employee failed " + e.getMessage());
			}
		}
		return empId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.emp.dao.IEmployeeDao#updateEmployee(com.capgemini.emp.bean
	 * .Employee)
	 */
	@Override
	public int updateEmployee(Employee employee) throws EmployeeException {
		myLogger.info("updateEmployee() invoked in EmployeeDaoImpl!!");

		System.out
				.println("Updating Employee record.... Kindly have patience!!");
		String sql = "update emp set emp_name=?"
				+ "where emp_id=?";
		PreparedStatement pst = null;
		int result = 0;
		try {// obtain ps
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);// transaction starts
			// getting the auto_generated id from the getNextCustId()
			int empId = employee.getId();
			// set the values for place hodlers		
			
			pst.setString(1, employee.getName());
			pst.setInt(2, employee.getId());
			
			myLogger.info("Employee details getting Updated ....");
			// execute DML query
			result = pst.executeUpdate();
			// now updating into MyEmployee table only if the first
			// insert is successful
			// getting the auto_generated id from the getNextEmployeeId()
			myLogger.info("Employee Id : " + empId + " ,updated");

			connection.commit();// if insert successful the commit the
								// transaction
		} catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Updating Employee failed  "
					+ e.getMessage());

			throw new EmployeeException("ERRROR :  Updating Employee failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Updating Employee failed "
						+ e.getMessage());
				throw new EmployeeException(
						"ERRROR : Updating Employee failed " + e.getMessage());
			}
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.emp.dao.IEmployeeDao#searchEmployee(int)
	 */
	@Override
	public List<Employee> searchEmployee(String  scheme) throws EmployeeException {
		myLogger.info("searchEmployee() in EmployeeDaoImpl invoked!!");
		String sql = "select * from emp where scheme = ?";
		Employee employee = null;
		ArrayList<Employee> empList = null;
		ResultSet resultSet = null;
		PreparedStatement pst = null;
		try {
			// obtaining pst
			empList = new ArrayList<>();
			pst = connection.prepareStatement(sql);
			pst.setString(1, scheme);// setting the empId
			 resultSet = pst.executeQuery();// executing the sql
			while(resultSet.next()) {
				myLogger.info("Employee record found ");
				//create the object of employee
				employee = new Employee();
				//mapping the value from db to employee object
				employee.setId(resultSet.getInt(1));
				employee.setName(resultSet.getString(2));
				employee.setSalary(resultSet.getDouble(3));
				employee.setDesignation(resultSet.getString(4));
				employee.setInsuranceScheme(resultSet.getString(5));
				empList.add(employee);
				//convert sql date to LocalDate
				//java.sql.Date sqlDate= resultSet.getDate(4);//getting sql date
				//LocalDate dob=sqlDate.toLocalDate();//convert sql date to LocalDate
							
			} 
		} catch (SQLException e) {
			myLogger.error("ERRROR " + "Searching Employee details failed "
					+ e.getMessage());
			throw new EmployeeException("Searching Employee details failed "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ERRROR " + "Searching Employee details failed "
						+ e.getMessage());
				throw new EmployeeException("Searching Employee details failed "
						+ e.getMessage());
			}
		}
		return empList;// returning employee list
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.emp.dao.IEmployeeDao#listAllEmployee()
	 */
	@Override
	public List<Employee> listAllEmployee() throws EmployeeException {
		ArrayList<Employee> empList = null;
		Statement st = null;
		ResultSet rs = null;
		Employee employee = null;
		String sql = "select * from emp";
		try {
			// obtain st
			st = connection.createStatement();
			rs = st.executeQuery(sql);
			empList = new ArrayList<>();
			while (rs.next()) {
				employee = new Employee();
				// fetch the column data
				// and set to the employee object
				employee.setId(rs.getInt(1));
				employee.setName(rs.getString(2));
				employee.setSalary(rs.getDouble(3));
				employee.setDesignation(rs.getString(4));
				employee.setInsuranceScheme(rs.getString(5));
				// add the employee object to the list
				empList.add(employee);
			}
		} catch (SQLException e) {
			myLogger.error("EmpList not found , error occured : "
					+ e.getMessage());
			throw new EmployeeException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("EmpList not found , error occured :"
						+ e.getMessage());
				throw new EmployeeException(e.getMessage());
			}
		}
		return empList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.emp.dao.IEmployeeDao#deleteEmployee(int)
	 */
	@Override
	public int deleteEmployee(int empId) throws EmployeeException {
		myLogger.info("------------------Deleting Employee Records----------------");
		PreparedStatement ps = null;
		String sql = "delete from emp where emp_id=?";// '?'
		int noOfRec = 0; // placeholder
		try {
			// start the transaction boundary
			connection.setAutoCommit(false);
			// obatain ps object
			ps = connection.prepareStatement(sql);
			// prepare the pre-compiled statement
			// now we will set the dynamic(runtime) values of ps
			// placeholder-1
			ps.setInt(1, empId);
			// execute the insert query(DML)-executeUpdate()
			noOfRec = ps.executeUpdate();
			connection.commit();// transaction ends
		} catch (SQLException e) {
			throw new EmployeeException("Issue in Deleting emp : " + e);
		} finally {
			if (ps != null)
				try {
					ps.close();
					connection.rollback();// if something wrong then rollback
				} catch (SQLException e) {
					throw new EmployeeException(
							"Issue while closing resource, which are null");
				}
		}
		return noOfRec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.emp.dao.IEmployeeDao#getEmployeeId()
	 */
	@Override
	public int getEmployeeId() throws EmployeeException {
		myLogger.info("Generating unique EmpId");
		String sql = "SELECT myEmp_seq.CURRVAL FROM dual";
		int empId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				empId = rs.getInt(1);
				myLogger.info("auto-generated EmpId by sequence : " + empId);
			} else {
				myLogger.error("EmpId not auto generated , error occured ");
			}
		} catch (SQLException e) {
			myLogger.error("EmpId not auto generated , error occured : "
					+ e.getMessage());
			throw new EmployeeException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("EmpId not auto generated , error occured :"
						+ e.getMessage());
				throw new EmployeeException(e.getMessage());
			}
		}
		return empId;
	}

	@Override
	public List<Employee> sort() throws EmployeeException {
		
		ArrayList<Employee> empList = null;
		Statement st = null;
		ResultSet rs = null;
		Employee employee = null;
		String sql = "select * from emp order by emp_sal";
		try {
			// obtain st
			st = connection.createStatement();
			rs = st.executeQuery(sql);
			empList = new ArrayList<>();
			while (rs.next()) {
				employee = new Employee();
				// fetch the column data
				// and set to the employee object
				employee.setId(rs.getInt(1));
				employee.setName(rs.getString(2));
				employee.setSalary(rs.getDouble(3));
				employee.setDesignation(rs.getString(4));
				employee.setInsuranceScheme(rs.getString(5));
				// add the employee object to the list
				empList.add(employee);
			}
		} catch (SQLException e) {
			myLogger.error("EmpList not found , error occured : "
					+ e.getMessage());
			throw new EmployeeException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("EmpList not found , error occured :"
						+ e.getMessage());
				throw new EmployeeException(e.getMessage());
			}
		}
		return empList;
	}

	@Override
	public Employee search(int empId) throws EmployeeException {
	
		myLogger.info("searchEmployee() in EmployeeDaoImpl invoked!!");
		String sql = "SELECT * FROM emp where emp_id=?";
		Employee employee = null;
		PreparedStatement pst = null;
		try {
			// obtaining pst
			pst = connection.prepareStatement(sql);
			pst.setInt(1, empId);// setting the traineeId
			ResultSet rs = pst.executeQuery();// executing the sql
			if (rs.next()) {
				myLogger.info("Employee record found ");
				// create the object of trainee
				employee = new Employee();
				// mapping the value from db to trainee object
				employee.setId(rs.getInt(1));
				employee.setName(rs.getString(2));
				employee.setSalary(rs.getDouble(3));
				employee.setDesignation(rs.getString(4));
				employee.setInsuranceScheme(rs.getString(5));
				

			} else {
				myLogger.error("ERRROR " + "EmployeeId does Not Exits");
				throw new EmployeeException("EmployeeId does Not Exits , ");
			}
		} catch (SQLException e) {
			myLogger.error("ERRROR " + "Searching Employee details failed "
					+ e.getMessage());
			throw new EmployeeException("Searching Employee details failed "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ERRROR " + "Searching Employee details failed "
						+ e.getMessage());
				throw new EmployeeException(
						"Searching Employee details failed " + e.getMessage());
			}
		}
	
		return employee;
	}

}

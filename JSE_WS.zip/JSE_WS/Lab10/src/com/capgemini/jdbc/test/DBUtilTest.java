/**
 * 
 */
package com.capgemini.jdbc.test;

import static org.junit.Assert.*;

import java.sql.Connection;



import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;



import com.capgemini.employee.exception.EmployeeException;
import com.capgemini.jdbc.util.DBUtil;

/**
 * @author shreya
 *
 */
public class DBUtilTest {
	static DBUtil dbUtil;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUp() throws Exception {
		dbUtil = new DBUtil();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDown() throws Exception {
	}

	@Test
	public void testConnection() throws EmployeeException {
		Connection conn = dbUtil.obtainConnection();
		assertNull("Connection NOT Obtained",conn);
	}

}

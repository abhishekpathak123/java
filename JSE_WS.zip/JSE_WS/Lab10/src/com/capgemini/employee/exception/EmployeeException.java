/**
 * 
 */
package com.capgemini.employee.exception;

/**
 * @author shreya
 *
 */
public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4203949429929605295L;

	public EmployeeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	

}

package com.cg.eis.service;

import java.util.List;

import com.capgemini.emp.bean.Employee;
import com.capgemini.employee.exception.EmployeeException;




/**
 * @author shreya
 *
 */
public interface IEmployeeService {
	public int addEmployee(Employee employee)
			throws EmployeeException;
	public int updateEmployee(Employee employee)
			throws EmployeeException;
	public List<Employee> searchEmployee(String scheme)
			throws EmployeeException;
	public List<Employee> listAllEmployee()
			throws EmployeeException;
	public int deleteEmployee(int empId)
			throws EmployeeException;
	public List<Employee> sort() throws EmployeeException;
	public Employee search(int empId) throws EmployeeException;
	public Employee findInsurance(Employee employee) throws EmployeeException;
	
}

/**
 * 
 */
package com.cg.eis.service;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
















import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.emp.bean.Employee;
import com.capgemini.emp.dao.EmployeeDaoImpl;
import com.capgemini.emp.dao.IEmployeeDao;
import com.capgemini.employee.exception.EmployeeException;





/**
 * @author shreya
 *
 */
public class EmployeeServiceImpl implements IEmployeeService{
	private static IEmployeeDao employeedao;
	
	static{
		employeedao = new EmployeeDaoImpl();
	}

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		return employeedao.addEmployee(employee);
	}

	@Override
	public int updateEmployee(Employee employee) throws EmployeeException {
		
		return employeedao.updateEmployee(employee);
	}

	@Override
	public List<Employee> searchEmployee(String scheme) throws EmployeeException {
		
		return employeedao.searchEmployee(scheme);
	}

	@Override
	public List<Employee> listAllEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeedao.listAllEmployee();
	}

	@Override
	public int deleteEmployee(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeedao.deleteEmployee(empId);
	}

	@Override
	public List<Employee> sort() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeedao.sort();
	}

	@Override
	public Employee search(int empId) throws EmployeeException {
		
		return employeedao.search(empId);
	}

	@Override
	public Employee findInsurance(Employee employee) throws EmployeeException {
		double sal = employee.getSalary();
		String designation = employee.getDesignation();
		String insuranceScheme = employee.getInsuranceScheme();
		if(sal > 5000 && sal < 20000)
		{
			designation="System Associate";
			insuranceScheme ="Scheme C";
		}
		else if(sal >=20000 && sal < 40000)
		{
			designation="Programmer";
			insuranceScheme ="Scheme B";
		}
		else if(sal >=40000)
		{
			designation="Manager";
			insuranceScheme ="Scheme A";
		}
		else if(sal < 5000)
		{
			designation="Clerk";
			insuranceScheme ="No Scheme";
		}
		employee.setDesignation(designation);
		employee.setInsuranceScheme(insuranceScheme);
		return employee;
	}
	
		
	}


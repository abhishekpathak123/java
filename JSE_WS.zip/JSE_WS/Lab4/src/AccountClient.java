/**
 * 
 */

/**
 * @author shreya
 *
 */
public class AccountClient {
	static Account account = new Account();
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		do{
			int option=0;
			
			System.out.println(
					"\n_____________________________________\n"
							+ "\nAccount Details\n"
							+"\n_____________________________________\n"
					
							+ "\nEnter your Choice\n"
							+"\n 1. Add AccountHolder Details"
							/*+"\n 2. Find Scheme"*/
							+"\n 2. Display AccountHolder Details"
							+"\n 3. Deposit Money"
							+"\n 4. Withdraw Money"
							+"\n 5. Delete Employee"
							+"\n 6. Exit"
					+"\n_____________________________________\n");
			
			option = sc.nextInt();

	}while(true);

}
}

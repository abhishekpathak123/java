/**
 * 
 */

/**
 * @author shreya
 *
 */
public class Account {
	private static long accNum;
	private double balance;
	private Person accHolder;
	static{
		accNum = 1000 + (int)(Math.random()*123.123);
	}
	public void deposit(double balance){
		
	}
	public void withdraw(double balance){
		
	}
	public double getBalance(){
		return balance;
		
	}
	public Account() {
		
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	
}

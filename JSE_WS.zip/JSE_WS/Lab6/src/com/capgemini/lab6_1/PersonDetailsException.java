/**
 * 
 */
package com.capgemini.lab6_1;

/**
 * @author shreya
 *
 */
public class PersonDetailsException extends Exception {
	
	private static final long serialVersionUID = -6672477970405440745L;
	public PersonDetailsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PersonDetailsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
	
}

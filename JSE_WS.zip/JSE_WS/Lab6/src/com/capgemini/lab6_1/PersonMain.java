/**
 * 
 */
package com.capgemini.lab6_1;


import java.util.Scanner;





/**
 * @author shreya
 *
 */
public class PersonMain {
public static Scanner sc = new Scanner(System.in);
	/**
	 * @param args
	 * @throws PersonDetailsException 
	 */
	public static void main(String[] args) throws PersonDetailsException {
		Person person = new Person();
		String fName,lName;
		try{
		System.out.println("Enter first name");
		fName = sc.nextLine();
		if (fName.isEmpty()){
			throw new PersonDetailsException();
		}
		else{
			System.out.println("Enter last name");
			lName = sc.nextLine();
			if (lName.isEmpty()){
				throw new PersonDetailsException();
			}
			else{
			
			
				System.out.println("gender: ");
		String str = sc.next();
		
		char gender = str.charAt(0);
		Person person1 = new Person(fName, lName, gender);
		
		System.out.println("\n______________________________________________"
						    +"\n 		Person Details"
							+"\n______________________________________________"
							+"\n	First Name  :   "+person1.getFirstName()
							+"\n	Last Name   :   "+person1.getLastName()
							+"\n	Gender      :   "+person1.getGender()	
							+"\n______________________________________________");
		}
		}}
		catch(PersonDetailsException e){
			System.err.println("can't be null"
					+"\nerror msg:"+e.getMessage());
		}
	
		
	

	}		}

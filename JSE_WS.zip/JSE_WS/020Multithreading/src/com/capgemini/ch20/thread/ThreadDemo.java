/**
 * 
 */
package com.capgemini.ch20.thread;

/**
 * @author Smita
 *
 */
public class ThreadDemo extends Thread{
//steps to create multithreaded clas in java 
	//1> create a class and extends Thread
	//2> Override run() method to provide business logic
	public ThreadDemo() {
		System.out.println("Thread Born...");
	}
	
	@Override
	public void run() {
		System.out.println("Thread Running..doing its task");
		String tName=Thread.currentThread().getName();
		if(tName.equalsIgnoreCase("t1")){
			for(int task=1;task<=50;task++){
				System.out.println(tName
						+"..completed..task"+task);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		if(tName.equalsIgnoreCase("t2")){
			for(int task=51;task<=100;task++){
				System.out.println(tName
						+"..completed..task"+task);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		//System.out.println(Thread.currentThread());
	}
	public ThreadDemo(String name) {
		super(name);
	}
	public static void main(String[] args) throws InterruptedException {
	//3> In main() create the object of Thread class
		Thread t1 = new ThreadDemo();
		System.out.println("Is Thread isAlive() ..."
				+t1.isAlive());
	//4> invoke start() method on thread object
		t1.setName("T1");
		t1.setPriority(9);	
		System.out.println("T1 priority..."+t1.getPriority());
		t1.start();
		System.out.println("Is Thread isAlive() after invoking start()..."
				+t1.isAlive());
		//t1.yield();
		t1.join();//let me finished the task then allow
		//other waiting thread to join
		Thread t2 = new ThreadDemo("T2");
		//Daemon Thread is the lowest priority threda
		//which runs at the background
		System.out.println("Is T2 Daemon Thread ....."
				+t2.isDaemon());
		t2.setDaemon(true);
		System.out.println("Is T2 Daemon Thread after setDaemon....."
				+t2.isDaemon()
				+"\n priority of Daemon Thread ... "+t2.getPriority());
		t2.start();
		System.out.println("Thread is Ready to run...");

	}

}

package com.capgemini.ch12.generics;

public class Employee implements Comparable<Employee>{
	private int empId;
	private String empName;
	private double empSal;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param empId
	 * @param empName
	 * @param empSal
	 */
	public Employee(int empId, String empName, double empSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + "]";
	}
	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return this.empId-o.empId;
	}
}

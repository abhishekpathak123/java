package com.capgemini.ch12.generics;

/**
 * @author shreya
 *
 */
public class GenericClass<T> {
	private T t;
	public GenericClass(T t) {
		this.t = t;
	}
	public void print(){
		System.out.println(this);
	}
	public T getT() {
		return t;
	}
	public void setT(T t) {
		this.t = t;
	}
	@Override
	public String toString() {
		return "GenericClass [t=" + t + "]";
	}
	
}

/**
 * 
 */
package com.capgemini.ch12.generics;

/**
 * @author shreya
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		GenericClass generic = null;
		String str = "Capgemini India";
		generic = new GenericClass<>(str);
		System.out.println(generic);
		
		Account a1 = new Account("Zara" , 7777);
		generic = new GenericClass<>(a1);
		System.out.println(generic);
		
		Employee e1 = new Employee(111,"Jia" ,876);
		generic = new GenericClass<>(e1);
		System.out.println(generic);
	}

}

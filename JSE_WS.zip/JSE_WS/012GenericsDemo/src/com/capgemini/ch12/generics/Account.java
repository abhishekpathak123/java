/**
 * 
 */
package com.capgemini.ch12.generics;

/**
 * @author Smita
 *
 */
public class Account implements Comparable<Account>{
	private int accId;
	private String accHolderName;
	private int balance;
	private static int numId;
	static{
		numId=(int) (Math.random()*123.12345);
	}
	{
		accId=1000+numId++;
	}
	public Account() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param accId
	 * @param accHolderName
	 * @param balance
	 */
	public Account( String accHolderName, int balance) {
		super();
		this.accHolderName = accHolderName;
		this.balance = balance;
	}
	/**
	 * @return the accId
	 */
	public int getAccId() {
		return accId;
	}
	/**
	 * @param accId the accId to set
	 */
	public void setAccId(int accId) {
		this.accId = accId;
	}
	/**
	 * @return the accHolderName
	 */
	public String getAccHolderName() {
		return accHolderName;
	}
	/**
	 * @param accHolderName the accHolderName to set
	 */
	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}
	/**
	 * @return the balance
	 */
	public int getBalance() {
		return balance;
	}
	/**
	 * @param balance the balance to set
	 */
	public void setBalance(int balance) {
		this.balance = balance;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Account [accId=" + accId + ", accHolderName=" + accHolderName
				+ ", balance=" + balance + "]";
	}
	@Override
	public int compareTo(Account o) {
		// if the obj are equal then 0
		//if calling object is greater then 1
		//if calling object is smaller then -1
		return this.getAccId()-o.getAccId();
		/*return this.getAccHolderName()
				.compareTo(o.getAccHolderName()) ;*/
	}
}

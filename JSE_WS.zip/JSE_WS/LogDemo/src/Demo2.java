import org.apache.log4j.*;
/**
 * @author shreya
 *
 */
public class Demo2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//example of Log4j
		Logger logger = Logger.getLogger("Demo2");
		logger.info("This is info!");
		logger.warn("This is Warning!");
		logger.error("This is error");

	}

}

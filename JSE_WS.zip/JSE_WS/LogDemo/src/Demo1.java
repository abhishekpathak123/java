import java.util.logging.*;
/**
 * @author shreya
 *
 */
public class Demo1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Not a example of Log4j
		Logger logger = Logger.getLogger("Logger1");
		logger.info("This is info!");
		logger.warning("This is Warning!");
		logger.log(Level.SEVERE,"This is error");

	}

}

/**
 * 
 */
package com.capgemini.emp.dao;

import java.util.List;

import com.capgemini.emp.bean.Employee;
import com.capgemini.emp.exception.EmployeeException;

/**
 * @author shreya
 *
 */
public interface IEmployeeDao {
	//CRUD
	public int addEmployee(Employee employee) throws EmployeeException;
	public int updateEmployee(Employee employee) throws EmployeeException;
	public Employee searchEmployee(int empId) throws EmployeeException;
	public List<Employee> listAllEmployee() throws EmployeeException;
	public int deleteEmployee(int empId) throws EmployeeException;
	
	
	//dao    
	//fetch the generated empId from the sequence
	public int getEmployeeId() throws EmployeeException;
}

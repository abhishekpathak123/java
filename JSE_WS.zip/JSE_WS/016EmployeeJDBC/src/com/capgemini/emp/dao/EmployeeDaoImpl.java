/**
 * 
 */
package com.capgemini.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.emp.bean.Employee;
import com.capgemini.emp.exception.EmployeeException;
import com.capgemini.emp.util.DBUtil;

/**
 * @author Smita
 *
 */
public class EmployeeDaoImpl implements IEmployeeDao {
	// step 1 :declare Connection and Logger variables
	private Connection connection;
	private static Logger myLogger = null;
	// step 2 :static blog for logger code
	static {
		PropertyConfigurator
			.configure("resources/log4j.properties");
		myLogger = Logger
		.getLogger(EmployeeDaoImpl.class.getName());
	}
	// step 3 : obtain connection in the constructor
	public EmployeeDaoImpl() {
		try {
			connection = new DBUtil().obtainConnection();
			myLogger.info("Connection Obtained ... at DAO");
		} catch (EmployeeException e) {
			myLogger.error("ERROR : " + e);
			System.err.println(e.getMessage());
		}
	}
	// step 4 : override methods
	/* (non-Javadoc)
	 * @see com.capgemini.emp.dao.IEmployeeDao#addEmployee(com.capgemini.emp.bean.Employee)
	 */
	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		myLogger.info("addEmployee() invoked in EmployeeDaoImpl!!");
		System.out.println("Adding Employee record.... Kindly have patience!!");
		String sql = "insert into myemp values(myEmp_seq.NEXTVAL,?,?)";
		PreparedStatement pst = null;
		int result = 0;
		int empId=0;
		try {// obtain ps
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);// transaction starts
			
				// set the values for place hodlers
				pst.setString(1, employee.getEmpName());
				pst.setDouble(2, employee.getEmpSal());
				
					// execute DML query
				result = pst.executeUpdate();
				empId=getEmployeeId();
				//set the empId of the current employee object
				employee.setEmpId(empId);
				myLogger.info("Employee details getting inserted "
						+ "....unique EmpID : "+empId);
			
			connection.commit();// if insert successful the commit the
								// transaction
		} catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Inserting Employee failed  "
					+ e.getMessage());
			throw new EmployeeException("ERRROR :  Inserting Employee failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Inserting Employee failed "
						+ e.getMessage());
				throw new EmployeeException("ERRROR : Inserting Employee failed "
						+ e.getMessage());
			}
		}
		return empId;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.emp.dao.IEmployeeDao#updateEmployee(com.capgemini.emp.bean.Employee)
	 */
	@Override
	public int updateEmployee(Employee employee) throws EmployeeException {
		
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.emp.dao.IEmployeeDao#searchEmployee(int)
	 */
	@Override
	public Employee searchEmployee(int empId) throws EmployeeException {
		
		return null;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.emp.dao.IEmployeeDao#listAllEmployee()
	 */
	@Override
	public List<Employee> listAllEmployee() throws EmployeeException{
		ArrayList<Employee> empList = null;
		Statement st = null;
		ResultSet rs = null;
		Employee employee=null;
		String sql="select * from myemp";
		try {
			//obtain st
			st=connection.createStatement();
			rs = st.executeQuery(sql);
			empList= new ArrayList<Employee>();
			while(rs.next()){
				employee = new Employee();
				//fetch the column data
				//and set to the employee object
				employee.setEmpId(rs.getInt(1));
				employee.setEmpName(rs.getString(2));
				employee.setEmpSal(rs.getDouble(3));
				//add employee to list
				empList.add(employee);
			}
		} catch (SQLException e) {
			myLogger.error("EmpList not found, error occured : "
					+ e.getMessage());
			throw new EmployeeException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("EmpList not found, error occured :"
						+ e.getMessage());
				throw new EmployeeException(e.getMessage());
			}
		}
			
		
		return empList;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.emp.dao.IEmployeeDao#deleteEmployee(int)
	 */
	@Override
	public int deleteEmployee(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.emp.dao.IEmployeeDao#getEmployeeId()
	 */
	@Override
	public int getEmployeeId() throws EmployeeException {
		myLogger.info("Generating unique EmpId");
		String sql = "SELECT myEmp_seq.CURRVAL FROM dual";
		int empId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				empId = rs.getInt(1);
				myLogger.info("auto-generated EmpId by sequence : "
						+ empId);
			} else {
				myLogger.error("EmpId not auto generated , error occured ");
			}
		}  catch (SQLException e) {
			myLogger.error("EmpId not auto generated , error occured : "
					+ e.getMessage());
			throw new EmployeeException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("EmpId not auto generated , error occured :"
						+ e.getMessage());
				throw new EmployeeException(e.getMessage());
			}
		}
		return empId;
	}

}

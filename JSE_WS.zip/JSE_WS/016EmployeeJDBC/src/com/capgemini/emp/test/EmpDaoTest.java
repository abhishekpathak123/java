/**
 * 
 */
package com.capgemini.emp.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.emp.bean.Employee;
import com.capgemini.emp.dao.EmployeeDaoImpl;
import com.capgemini.emp.exception.EmployeeException;

/**
 * @author shreya
 *
 */
public class EmpDaoTest {
	static EmployeeDaoImpl employeeDao;
	
	@BeforeClass
	public static void testEmpDaoImpl(){
		employeeDao = new EmployeeDaoImpl();
	}

	@Test
	public void testAddEmployee1() throws EmployeeException{
		int empId = employeeDao.addEmployee(new Employee(999,"Raj",999));
		System.out.println("Unique Id :"+empId);
		assertNotEquals(0,empId);
	}
	
	@Test
	public void testAddEmployee2() throws EmployeeException{
		int empId = employeeDao.addEmployee(new Employee(999,"Raj",999));
		System.out.println("Unique Id :"+empId);
		assertTrue(empId > 0);
	}
	
	@Test
	public void testListEmployee1() throws EmployeeException{
		List<Employee> empList = employeeDao.listAllEmployee();
		assertNotNull("Employee List Not Found",empList);
		for(Employee emp:empList)
			System.out.println(emp);
	}
}

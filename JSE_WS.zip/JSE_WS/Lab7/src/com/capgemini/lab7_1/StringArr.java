/**
 * 
 */
package com.capgemini.lab7_1;

import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

/**
 * @author shreya
 *
 */
public class StringArr {

	
	public static void main(String[] args) {
			String[] arr = new String[5];
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the products to be stored");
			for(int i =0;i<arr.length;i++){
				arr[i]= sc.next();
			}
			System.out.println("Sorted order :");
			Arrays.sort(arr);
			for(int i =0;i<arr.length;i++){
				System.out.println(arr[i]);
			}
				
			}
	}



package com.capgemini.lab7_2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;


/**
 * @author shreya
 *
 */
public class StringArray {
static	List<String> list = new ArrayList();
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("Enter the products to be stored");
		for(int i=0;i<5;i++){
			 list.add(sc.next());
		}
		
		Collections.sort(list);
		System.out.println("Sorted order :");
		for(String i:list){
			System.out.println(i);
		}
	}
	
	
}

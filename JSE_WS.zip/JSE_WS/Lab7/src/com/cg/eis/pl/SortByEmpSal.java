/**
 * 
 */
package com.cg.eis.pl;

import java.util.Comparator;

import com.cg.eis.bean.Employee;

/**
 * @author shreya
 *
 */
public class SortByEmpSal implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		
		return (int) (o1.salary-o2.salary);
	}
	
}

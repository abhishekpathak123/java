/**
 * 
 */
package com.cg.eis.pl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;











import java.util.Set;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.IEmployeeService;
import com.cg.emloyee.exception.EmployeeException;

/**
 * @author shreya
 *
 */
public class EmployeeClient{
	private static IEmployeeService employeeService;
	private static Scanner sc;
	private static Employee employee;
	private static List<Employee> employeeList;
	private static HashMap employeeMap;
	//static block to initialize static members
	static{
		sc = new Scanner(System.in);
		employeeService=new EmployeeServiceImpl();
		employee = new Employee();
		employeeMap = new HashMap();
		employeeList = new ArrayList();
	}
	/**
	 * @param args
	 * @throws EmployeeException 
	 */
	public static void main(String[] args) throws EmployeeException {
		
		do{
			int option=0;
			
			System.out.println(
					"\n_____________________________________\n"
							+ "\nEmployee Details\n"
							+"\n_____________________________________\n"
					
							+ "\nEnter your Choice\n"
							+"\n 1. Add Employee Details"
							/*+"\n 2. Find Scheme"*/
							+"\n 2. Display Employee Details"
							+"\n 3. Search Employee By Scheme"
							+"\n 4. Sort Employee By Salary"
							+"\n 5. Delete Employee"
							+"\n 6. Exit"
					+"\n_____________________________________\n");
			
			option = sc.nextInt();
			
			switch (option) {
			case 1:addEmployeeDetails();
				break;
			case 2:/*findInsuranceScheme(employee, employee.getSalary());*/
				searchEmployee();
				break;
			case 3:searchListByScheme(employee.getInsuranceScheme());
				break;
			case 4:sort();
			break;
			case 5:removeEmployee();
			break;
			case 6:exit();
				break;
			
			default:
				System.out.println("Wrong option entered"
						+ "\n kindly enter choice (1-4) only");
				break;
			}
		}while(true);


	}
	private static void sort() throws EmployeeException {
		
		List<Employee> employeeList = employeeService.sort();
		for(Employee employee : employeeList){
			employee.print();
		}
		}
	
		
	
	private static void searchListByScheme(String insuranceScheme) throws EmployeeException {
		System.out.println("Enter Scheme to be Searched");
		Scanner scan = new Scanner(System.in);
		String scheme = scan.nextLine();
		int status = employeeService.searchListByScheme(scheme);
		if(status != 1){
			System.out.println("No employee under this scheme");
		}
		/*if(employee!=null)
		{
			employeeList.add(employee);
			
			for(int i=0;i<employeeList.size();i++){
				System.out.println(employeeList.get(i));
			}
		}else{
			System.out.println("employee Does Not exists under Scheme "+insuranceScheme);
		}*/
		}
		
	
	private static void removeEmployee() throws EmployeeException {
		System.out.println("Enter Employee Id to be removed");
		int employeeId=sc.nextInt();
		int status = employeeService.removeEmployee(employeeId);
		if(status != 0)
		{
			System.out.println("employee successfully deleted");
		}else{
			System.out.println("employee Does Not exists!!");
		}
	}
	private static Employee searchEmployee() throws EmployeeException {
		System.out.println("Enter Employee Id to be Searched");
		int employeeId=sc.nextInt();
		//search the trainee weather it exists or not
		employee=employeeService.searchEmployee(employeeId);
		//remove the trainee if it is not null
		if(employee!=null)
		{
			employee.print();
		}else{
			System.out.println("employee Does Not exists!!");
		}
		return employee;
		
	}
	private static void findInsuranceScheme(Employee employee,double salary) {
		if(salary > 5000 && salary < 20000)
		{
			employee.setDesignation("System Associate");
			employee.setInsuranceScheme("Scheme C");
		}
		else if(salary >=20000 && salary < 40000)
		{
			employee.setDesignation("Programmer");
			employee.setInsuranceScheme("Scheme B");
		}
		else if(salary >=40000)
		{
			employee.setDesignation("Manager");
			employee.setInsuranceScheme("Scheme A");
		}
		else if(salary <5000)
		{
			employee.setDesignation("Clerk");
			employee.setInsuranceScheme("No Scheme");
		}
	
		
		
	}
	private static void addEmployeeDetails() throws EmployeeException {
		Employee employee = new Employee();
		System.out.println("Enter employee name :");
		String name = sc.next();
		while (true) {
			if (employeeService.validateName(name)) {
				employee.setName(name);
				break;
			} else {
				System.err
						.println("**********Please Enter Trainee FirstName:"
								+ "(Must be 3-20 Characters only and 1st Letter UpperCase! ex:Smita**********");
				name = sc.next();
			}
		}
		employee.setName(name);
		System.out.println("Enter salary :");
		Double sal = sc.nextDouble();
		employee.setSalary(sal);
		findInsuranceScheme(employee,sal);
		int status=employeeService.addEmployeeDetails(employee);
		if(status==1)
		{
			System.out.println("employee Addedd  successfully");
			employee.print();
		}else{
			System.out.println("employee Does Not added!!");
		}
	}
	private static void exit() {
		System.out.println(
				"Thankyou for using Trainee App"
				+"    Do Visit Again!!!");
		sc.close();
		System.exit(0);
		
	}

	
	
	
		
}



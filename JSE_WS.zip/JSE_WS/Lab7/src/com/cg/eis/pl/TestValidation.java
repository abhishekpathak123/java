/**
 * 
 */
package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.IEmployeeService;
import com.cg.emloyee.exception.EmployeeException;

/**
 * @author shreya
 *
 */
public class TestValidation {
	
	static Scanner sc = new Scanner(System.in);
	static IEmployeeService employeeService = new EmployeeServiceImpl();
	public static void main(String[] args) {
		Employee employee = new Employee();
		String name = sc.next();
		try{
			while(true){
				if(employeeService.validateName(name)){
					employee.setName(name);
					break;
				}else{
					System.err.println("************Please Enter Trainee FirstName:"
							+"(Must be 3-20 Characters only "
							+"and 1st Letter UpperCase!) ex:Shreya***************");
					name = sc.next();
			}
		}
		}catch(EmployeeException e){
			System.out.println(e.getMessage());
		}

	}

}

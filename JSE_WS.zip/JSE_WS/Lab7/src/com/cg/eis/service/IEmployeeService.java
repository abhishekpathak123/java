package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.Employee;
import com.cg.emloyee.exception.EmployeeException;

/**
 * @author shreya
 *
 */
public interface IEmployeeService {
	public int addEmployeeDetails(Employee employee)throws EmployeeException;
	public void findInsuranceScheme(Employee employee,double sal)throws EmployeeException;
	public Employee searchEmployee(int id)throws EmployeeException;
	public int removeEmployee(int employeeId)throws EmployeeException;
	public int searchListByScheme(String scheme)throws EmployeeException;
	public List<Employee> sort()throws EmployeeException;
	public boolean validateName(String name)throws EmployeeException;
}

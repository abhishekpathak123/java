/**
 * 
 */
package com.cg.eis.service;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
















import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.eis.bean.Employee;
import com.cg.eis.pl.SortByEmpSal;
import com.cg.emloyee.exception.EmployeeException;

/**
 * @author shreya
 *
 */
public class EmployeeServiceImpl implements IEmployeeService{
	private static Employee employee;
	private static Map<Integer, Employee> employeeMap;
	/*private static List empList;*/
	/*private static int size=0;*/
	static{
		employee = new Employee();
		employeeMap = new HashMap<>();
		/*empList = new ArrayList();*/
	}
	@Override
	public int addEmployeeDetails(Employee employee) throws EmployeeException{
		
		employeeMap.put(employee.getId(),employee);
		
		return 1;
	}
	@Override
	public void findInsuranceScheme(Employee employee,double sal)throws EmployeeException {
		
	
		
		if(sal > 5000 && sal < 20000)
		{
			employee.setDesignation("System Associate");
			employee.setInsuranceScheme("Scheme C");
		}
		else if(sal >=20000 && sal < 40000)
		{
			employee.setDesignation("Programmer");
			employee.setInsuranceScheme("Scheme B");
		}
		else if(sal >=40000)
		{
			employee.setDesignation("Manager");
			employee.setInsuranceScheme("Scheme A");
		}
		else if(sal < 5000)
		{
			employee.setDesignation("Clerk");
			employee.setInsuranceScheme("No Scheme");
		}
		
	}
	@Override
	public Employee searchEmployee(int id)throws EmployeeException {
		
		Set set = employeeMap.entrySet();
		//obtain the iterator for the set
		Iterator iter = set.iterator();
		while(iter.hasNext()){
			//enter the map inside the set
			Map.Entry me = (Map.Entry) iter.next();
			Integer key = (Integer) me.getKey();
			/*int keyInt = Integer.valueOf(key);*/
			if(key==id){
				return (Employee)me.getValue();
				
			}
			/*System.out.println(me.getKey() + " : " +me.getValue());*/
		
		
		}
		return null;
		
		
	}
	@Override
	public int removeEmployee(int employeeId)throws EmployeeException {

		int status=0;
		/*int index=0;*/
		// write the code for updating arrayList
		Set set = employeeMap.entrySet();
		//obtain the iterator for the set
		Iterator iter = set.iterator();
		while(iter.hasNext()){
			//enter the map inside the set
			Map.Entry me = (Map.Entry) iter.next();
			Integer key = (Integer) me.getKey();
			/*int keyInt = Integer.valueOf(key);*/
			if(key==employeeId){
		
			
								
				
				employeeMap.remove(key);
				status=1;
				break;
			}
		}
		return status;
	
	}
	@Override
	public int searchListByScheme(String scheme)throws EmployeeException {
		int status = 0;
		Set set = employeeMap.entrySet();
		Iterator iter = set.iterator();
		
		while(iter.hasNext()){
			Map.Entry me = (Map.Entry) iter.next();
			employee = (Employee) me.getValue();
			String employeeScheme = employee.getInsuranceScheme();
			if(employeeScheme.equals(scheme)){
				employee.print();
				status = 1;
			}
		
		}
		return status;
		
	
	}
	@Override
	public List<Employee> sort()throws EmployeeException {
		List<Employee> employeeSortedList = new ArrayList<Employee>();
		
		SortByEmpSal e1 = new SortByEmpSal();
		Set set = employeeMap.entrySet();
		Iterator iter = set.iterator();
		Employee employee = null;
		
		while(iter.hasNext()){
			Map.Entry me = (Map.Entry) iter.next();
			employee = (Employee) me.getValue();
			employeeSortedList.add(employee);
		}
		Collections.sort(employeeSortedList,e1);
		return employeeSortedList;
		}
	@Override
	public boolean validateName(String name) throws EmployeeException {
		String patternStr = "^[A-Z][a-z]{2,20}$";
		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(name);
		
		return matcher.matches();
	}
		
	}


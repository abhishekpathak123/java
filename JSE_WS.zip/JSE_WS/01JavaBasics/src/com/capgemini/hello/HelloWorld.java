/**
 * 
 */
package com.capgemini.hello;

/**
 * @author shreya
 *
 */
public class HelloWorld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String name=args[0];//cmd line argument
			
			
			int age = Integer.parseInt(args[1]);
			System.out.println("Hello "+name+"\nYour age is : "+age);
	}

}

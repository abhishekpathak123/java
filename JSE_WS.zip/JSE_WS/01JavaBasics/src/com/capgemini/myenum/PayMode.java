/**
 * 
 */
package com.capgemini.myenum;

/**
 * @author shreya
 *
 */
public enum PayMode {
		CASH,CREDIT,DEBIT,WALLET
}

/**
 * 
 */
package com.capgemini.myenum;

import java.util.Scanner;

/**
 * @author shreya
 *
 */
public class PayModeMain {
	enum Seasons{
		SUMMER,WINTER,RAINY;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*System.out.println("Enter Payment Mode :");*/
		/*for(PayMode p : PayMode.values()){
			System.out.println(p);
		}*/
		PayMode [] pArr=PayMode.values();
		for(int i=0; i < PayMode.values().length;i++){
			System.out.println(pArr[i]);
		}
		/*Scanner sc = new Scanner(System.in);
		String payMode = sc.next().toUpperCase();
		//PayMode pm = PayMode.CASH;
		PayMode pm = PayMode.valueOf(payMode);
		//valueof func converting string to enum type
		System.out.println("You have selected :"+pm +" , as payment option");
		*/
	}

}

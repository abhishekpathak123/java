/**
 * 
 */
package com.capgemini.myenum;

/**
 * @author shreya
 *
 */
public enum Months {
		
		
		JAN(31),SEP(30),DEC(31);
		private int noOfDays;
		


		private Months(int noOfDays) {
			this.noOfDays = noOfDays;
		}

		public int getNoOfDays() {
			return noOfDays;
		}

		public void setNoOfDays(int noOfDays) {
			this.noOfDays = noOfDays;
		}
}

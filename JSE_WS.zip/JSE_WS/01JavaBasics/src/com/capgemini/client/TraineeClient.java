/**
 * 
 */
package com.capgemini.client;

import com.capgemini.date.MyDate;
import com.capgemini.trainee.Trainee;

/**
 * @author shreya
 *
 */
public class TraineeClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Trainee trainee3 = new Trainee();
		MyDate dob=new MyDate(13,9,1997);
		
		Trainee trainee2 = new Trainee("Shreya","Sinha",9589356345l,"abc@gmail.com",dob);
		System.out.println("Trainee2: \n" + trainee2);
	}

}

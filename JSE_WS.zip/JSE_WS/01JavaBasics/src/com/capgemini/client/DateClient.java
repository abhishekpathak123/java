/**
 * 
 */
package com.capgemini.client;

import com.capgemini.date.MyDate;

/**
 * @author shreya
 *
 */
public class DateClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyDate d1 = new MyDate(11,11,2017);
		MyDate d2 = new MyDate(11,11,2017);
		System.out.println("Is d1.equals(d2) : "+d1.equals(d2));
	}

}

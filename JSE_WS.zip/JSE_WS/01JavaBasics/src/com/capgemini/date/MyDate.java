/**
 * 
 */
package com.capgemini.date;

/**
 * @author shreya
 *
 */
public class MyDate {
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof MyDate){
			MyDate m1 = (MyDate)obj;
			if((this.day==m1.day)&&(this.month==m1.month)&&(this.year==m1.year))
			{
				return true;
			}
		}return false;
		
	}

	private int day;
	private int month;
	private int year;

	@Override
	protected void finalize() throws Throwable {
		System.out.println("Date obj destroyed");
	}

	public MyDate() {
		System.out.println("MyDate no-arg Constructor....");
	}

	public MyDate(int day, int month, int year) {

		this.day = day;
		this.month = month;
		this.year = year;
	}

	// step 7 : generate toString()
	@Override
	public String toString() {
		return "MyDate [day=" + day + ", month=" + month + ", year=" + year
				+ "]";
	}
	// step 8 : generate getters and setters

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

}

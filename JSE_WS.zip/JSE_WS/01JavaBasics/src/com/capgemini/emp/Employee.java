/**
 * 
 */
package com.capgemini.emp;

/**
 * @author shreya
 *
 */
public class Employee {
	String empName;//local var name and instance var name can be same
	public static void main(String[] args) {
		//local variable-declared within the method/block
		//must be initialized before used
		//cannot be declared as public or static
		byte b=1;//by default private to the method
		String empName="Shreyanshi";
		short age=22;
		float empSal=9999.99f;
		//by default all decimal are treated as double in Java
		//Thus all float literals(value) must be appended with 'f'/'F'
		long phone=9638458959l;
		//all long literals must be appended with 'l'/'L'
		double d=9.9;
		char ch=65;//ascii value
		char grade='A';//wrapped with single code
		char c1='\u0000';//default value of char
		//local value does not have any default value
		boolean status=true;//no double quotes only string literals must have double quotes
		System.out.println("\n______________________________________________"
							+"\n 			Employee Details"
							+"\n______________________________________________"
							+"\n	Employee Id 	:	"+b
							+"\n	Employee Name 	:	"+empName	
							+"\n	Employee Salary :	"+empSal	
							+"\n______________________________________________"
				+"");
		
	}
}

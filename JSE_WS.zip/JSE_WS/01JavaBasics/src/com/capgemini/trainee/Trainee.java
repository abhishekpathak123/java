//step 1 :one package declaration 
package com.capgemini.trainee;

import com.capgemini.date.MyDate;

//step 2 :none or many import statements
/**
 * @author shreya
 *
 */
//step 3 : public class
public class Trainee {
	//step 4 :private instance variables
	private int traineeId;
	private String firstName;
	private String lastName;
	private long phoneno;
	private String email;
	private MyDate dob;
	//step - 6:static member variables
	private static String coName;//single copy per class
	private static int numId;//for auto-generation
	//step - 7:static initializer block
	static{
		System.out.println("static block invoked");
		coName="Capgemini India Pvt Ltd";
		numId=1000+(int)(Math.random()*123.123);//auto generated id
	}
	//step - 8:init block initializing
	{
		traineeId = numId++;
		System.out.println("init block invoked");
	}
	//step - 9 : Default Constructor
	public Trainee() {
		
		System.out.println("No-args Constructor");
	}
	//step - 10 : Overloaded Constructor
	public Trainee(String firstName, String lastName, long phoneno,
			String email, MyDate dob) {
		System.out.println("Overloaded Constructor");
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneno = phoneno;
		this.email = email;
		this.dob = dob;
	}
	//step - 11 : toString method
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", phoneno=" + phoneno
				+ ", email=" + email + ", dob=" + dob + "]";
	}
	//step 12 :getters and setters in order to access private data outside the class
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public MyDate getDob() {
		return dob;
	}
	public void setDob(MyDate dob) {
		this.dob = dob;
	}
	
	
		
	
}

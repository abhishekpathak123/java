/**
 * 
 */
package com.capgemini.final_demo;

/**
 * @author shreya
 *
 */
public class FinalVar {
		
		static final float PI;
		static final float INTEREST_RATE;
		static{
			PI = 3.14F;
			INTEREST_RATE = 0.12F;
		}
		public static float getPi() {
			return PI;
		}
		public static float getInterestRate() {
			return INTEREST_RATE;
		}
	public static void main(String[] args) {
		calculateRadius(2.0F,3.2F);
		calculateRate(34.0F,1000F);
	}
	static void calculateRadius(float r,float PI){
			System.out.println("PI : "+PI*r*r);
	}
	static void calculateRate(float INTEREST_RATE,float amount){
		System.out.println("INTEREST_RATE : "+INTEREST_RATE*1000+amount);
}
}

/**
 * 
 */
package com.capgemini.gc;

import com.capgemini.date.MyDate;

/**
 * @author shreya
 *
 */
public class GarbageDemo {

	
	public static void main(String[] args) {
		MyDate dob = new MyDate();
		dob = null;
		System.gc();//requesting garbage collector
		//Runtime.getRuntime().gc;

	}

}

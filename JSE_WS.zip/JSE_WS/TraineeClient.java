/**
 * 
 */
package com.capgemini.client;
import java.util.Scanner;
import com.capgemini.date.MyDate;
import com.capgemini.trainee.Trainee;
/**
 * @author Smita
 *
 */
public class TraineeClient {	
	/**
	 * @param args
	 */

	static Trainee trainee1 = new Trainee();
	static Scanner scan = new Scanner(System.in);
	public static void main(String[] args) {
		/*Trainee trainee3 = 
				new Trainee();
		MyDate dob = new MyDate(13, 9, 1997);
		Trainee trainee2 = 
		new Trainee( "Zara",
				"Khan", 9876543212L
				, "zara@gmail.com", dob);
		System.out.println("Trainee 2 : \n"
				+trainee2);*/		
		do{			
		int option=0;
		System.out.println(
				"\n_____________________________________\n"
						+ "\nTrainee Apllication\n"
						+"\n_____________________________________\n"
				
						+ "\nEnter your Choice\n"
						+"\n 1. Add Trainee Details"
						+"\n 2. Display Trainee Details"
						+"\n 3. Exit"
				+"\n_____________________________________\n");
		option = scan.nextInt();
		switch (option) {
		case 1:addTrainee();
			break;
		case 2:displayTrainee();
		break;
		case 3:exitTrainee();
		break;
		default:
			System.out.println("Wrong option entered"
					+ "\n kindly enter choice (1-3) only");
			break;
		}
		}while(true);
		
	}
	private static void exitTrainee() {
		System.out.println("Thank You for using Trainee Application"
				+ "\n 				Do visit Again !!");
		System.exit(0);
		
	}

	private static void displayTrainee() {
		System.out.println(
				 "\n________________________________________"
				+"\n	Trainee Details					"
				+"\n________________________________________"
				+"\n	Trainee Id 	        : "+trainee1.getTraineeId()
				+"\n	Trainee FirstName	: "+trainee1.getFirstName()
				+"\n	Trainee lastName	: "+trainee1.getLastName()
				+"\n	Trainee DOB	        : "+trainee1.getDob()
				+"\n	Trainee Compay Name	: "+Trainee.getCoName()	
				+"\n________________________________________"
				);
	}

	private static void addTrainee() {
		System.out.println("Enter Trainee firstName");
		trainee1.setFirstName(scan.next());
		System.out.println("Enter Trainee lastName");
		trainee1.setLastName(scan.next());
		System.out.println("Enter Trainee Phone No");
		trainee1.setPhoneNo(scan.nextLong());
		System.out.println("Enter Trainee Email");
		trainee1.setEmail(scan.next());
		System.out.println("Enter Trainee DOB day month and year");
		int day = scan.nextInt();
		int month = scan.nextInt();
		int year = scan.nextInt();
		MyDate dob = new MyDate(day, month, year);
		trainee1.setDob(dob);
		
	}

}

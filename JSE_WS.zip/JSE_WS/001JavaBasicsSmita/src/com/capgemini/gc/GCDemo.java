/**
 * 
 */
package com.capgemini.gc;

/**
 * @author smita
 *
 */
public class GCDemo {
	public GCDemo() {
		System.out.println("Object created..........");
	}

	@Override
	protected void finalize(){
		System.out.println("*****************Object destroyed!!");
	}
	public static void main(String[] args) {
		/*for(int i=1;i<1000000;i++){
			GCDemo obj1 = new GCDemo();//created obj
			obj1=null;//obj is no more in reference
			System.out.print(i+" : ");
		}*/
		GCDemo obj1 = new GCDemo();//created obj
		obj1=null;//obj is no more in reference
		//we can request garbage collector
		System.gc();//requesting gc
		//Runtime.getRuntime().gc();//requesting gc
		//that is if an com.capgemini.ch5.object is referring to null
		//is eligible for garbage collection
		//implicitly the Garbage collector utility background thread 
		//comes into picture(lowest priority thread)
		//which invoked finalize() method to deallocate the com.capgemini.ch5.object memory 
		//which is no more longer in use
	}

}







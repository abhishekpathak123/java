package com.capgemini.hello;

public class Variables {

	public static void main(String[] args) {
		//local variable are the variable which are declared 
		//within the method or any block
		//or passed through an argument list or parameter list
		//local var must be initialized before use 
		//as they don't hav any default value
		long phone=9876543210L;	//8b	
		int i=300;//4b
		short s =89;//2b
		byte b=10;//1b
		
	//error	//float f =3.5;//all decimal are by default double
		float f =3.5F;//4b
		float weight =35f;
		float weight1 =3.5f;
		double d1=3.4f;
		System.out.println("Weight s :"+weight);
		double d=678.89;//8b
	
		char c='a';//2b
		char ch=97;//ascii value
		System.out.println("ch :"+ch);
		
		boolean bool =true;//default is false
		int age=90;
		System.out.println("age = "+age);
		
		String name="Smita";//String is a class in java
		//but can be used as primitive
/*
 * 	long phone=9876543210L;	//8b	
		int personId=300;//4b
		short ssn =89;//2b
		byte age=10;//1b
		
	//error	//float f =3.5;//all decimal are by default double
		float weight =3.5F;//4b
		double salary=3.4f;
		char grade=97;//ascii value
		
		boolean married =true;//default is false
		
		String personName="Smita";//String is a class in java
 */
	}

}

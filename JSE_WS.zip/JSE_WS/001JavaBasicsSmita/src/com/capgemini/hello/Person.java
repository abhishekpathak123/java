/**
 * 
 */
package com.capgemini.hello;

import java.util.Date;

/**
 * @author Smita
 *
 */
public class Person {
//instance variable - properties or attribute of an com.capgemini.ch5.object
	private int personId;
	private String personName;
	private char gender;
	private double salary;
	
	
	public static void main(String[] args) {
		Person p1= new Person();
		//creating an com.capgemini.ch5.object p1 of class Person
		System.out.println(""
				+ "\n================Person Deatils=====================\n"
				+ "\n                Id     : "+p1.personId
				+ "\n                Name   : "+p1.personName
				+ "\n                Gender : "+p1.gender
				+ "\n                Salary : "+p1.salary	
				+ "\n===================================================\n"
				);
		Date today = new Date();
		System.out.println("Today is  : "+today);

	}

}







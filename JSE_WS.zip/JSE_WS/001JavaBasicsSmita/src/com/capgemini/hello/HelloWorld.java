/** document comment
 * program to accept command line argument
 */
package com.capgemini.hello;
/*multi-line comment
 * 
 * 
 */
/**
 * @author Smita
 *
 */
//HelloWorld.java - single line comment
public class HelloWorld {
	//entry point to the java class
	public static void main(String[] args) {
		//accessing the command line argument
		//at the time of running a program 
		//what ever argument or parameter passed 
		//is known as command line argument
		//and these are stored in main methods String [] array
		String strName=args[0];
		int marks=Integer.parseInt(args[1]);
		System.out.println("Hello ,"+strName+"\n Marks is : "+marks);
	} 
}









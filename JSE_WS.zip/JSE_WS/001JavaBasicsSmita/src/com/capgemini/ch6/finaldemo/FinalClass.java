/**
1>final variables must be initialized and cannot be re-initialized.

2>final method cannot be overridden.

3>final class cannot be sub-classed or extended or inherited
 */
package com.capgemini.ch6.finaldemo;

/**
 * @author smita
 *
 */
public final class FinalClass {

}

/*class SubClass extends FinalClass{
//	/final class cannot be sub-classed or extended or inherited
}*/
class A{
	public final void finalMethod(){
		
	}
}
class B extends A{
	//final method cannot be overridden.
	/*@Override
	public void finalMethod(){
		
	}*/
}









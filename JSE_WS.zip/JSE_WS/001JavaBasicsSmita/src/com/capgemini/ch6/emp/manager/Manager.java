/**
 * 
 */
package com.capgemini.ch6.emp.manager;

import com.capgemini.date.MyDate;
import com.capgemini.emp.Employee;

/**
 * @author Smita
 *
 */
public class Manager extends Employee {

	// member variables
	private double incentives;

	// no-arg contr
	public Manager() {
		System.out.println("-----Manager No-Arg Contr-----");
	}

	// overlaoded contr
	public Manager(String empName, double empSal, MyDate joinDate,
			double incentives) {
		// super is used to invoke super class contr and methods
		// and in case contr call to super must be first line of code
		super(empName, empSal, joinDate);
		System.out.println("-----Manager Overlaoded Contr-----");
		this.incentives = incentives;
	}
	//toString

	@Override
	public String toString() {
		return "Manager [incentives=" + incentives + ","
				+ "toString()="
				+ super.toString() + "]";
		//super keyword is used for invoking super class method & contr
	}

	@Override
	public void print() {
		System.out.println(""
				+ "\n================Manager Details=====================\n"
				+ "\n                Id        : "+empId
				+ "\n                Name      : "+empName
				+ "\n                Salary    : "+calculateSal()
				+ "\n                joinDate  : "+joinDate
				+ "\n                coName    : "+getCoName()
				+ "\n                Incentives : "+incentives
				+ "\n====================================================\n"
				);
	}

	@Override
	public double calculateSal() {
		super.setEmpSal(super.calculateSal()+incentives);
		return super.getEmpSal();
	}

	public double getIncentives() {
		return incentives;
	}

	public void setIncentives(double incentives) {
		this.incentives = incentives;
	}
	
}








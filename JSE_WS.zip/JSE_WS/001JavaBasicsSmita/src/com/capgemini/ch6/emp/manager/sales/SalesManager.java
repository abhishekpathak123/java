/**
 * 
 */
package com.capgemini.ch6.emp.manager.sales;

import com.capgemini.ch6.emp.manager.Manager;
import com.capgemini.date.MyDate;

/**
 * @author shosakop
 *
 */
public class SalesManager extends Manager {
	//member var
	private double sales;
	private double comm;
	public SalesManager() {
		// TODO Auto-generated constructor stub
	}
	public SalesManager(String empName, double empSal, MyDate joinDate,
			double incentives,double sales,double comm) {
		super(empName, empSal, joinDate, incentives);
		this.sales=sales;
		this.comm=comm;		
	}
	@Override
	public void print() {
		System.out.println(""
				+ "\n================SalesManager Details=====================\n"
				+ "\n                Id         : "+empId
				+ "\n                Name       : "+empName
				+ "\n                Salary     : "+calculateSal()
				+ "\n                joinDate   : "+joinDate
				+ "\n                coName     : "+getCoName()
				+ "\n                Incentives : "+getIncentives()
				+ "\n                Sales      : "+sales
				+ "\n                Commission : "+comm
				+ "\n====================================================\n"
				);
	}
	@Override
	public double calculateSal() {
		// TODO Auto-generated method stub
		empSal=super.calculateSal()+(sales*comm);
		return empSal;
	}
	public double getSales() {
		return sales;
	}
	public void setSales(double sales) {
		this.sales = sales;
	}
	public double getComm() {
		return comm;
	}
	public void setComm(double comm) {
		this.comm = comm;
	}
	@Override
	public String toString() {
		return "SalesManager [sales=" + sales + ", comm=" + comm
				+ ", toString()=" + super.toString() + "]";
	}
	
}

/**
 * 
 */
package com.capgemini.ch6.client;

import com.capgemini.ch6.emp.manager.Manager;
import com.capgemini.ch6.emp.manager.sales.SalesManager;
import com.capgemini.date.MyDate;
import com.capgemini.emp.Employee;

/**
 * @author smita
 *
 */
public class EmployeeClient {
	public static void main(String[] args) {
		MyDate d1 = new MyDate(11,11,2012);
		Employee e1 = 
			new Employee("smita", 99999, new MyDate(11,11,2011));
		e1.print();
		Manager m1 = 
				new Manager("smita", 99999, new MyDate(11,11,2011),8900);
			m1.print();
			//dynamic polymorphism -at runtime
		Employee e2=new Manager("mona",8978,new MyDate(12, 12, 2016),8989);
		e2.print();
		
		SalesManager s1 = new SalesManager("sia", 7878, d1, 1234, 1000, .12);
		s1.print();
	}
}




/**
 * 
 */
package com.capgemini.ch6.overloading;

/**
 * @author shosakop
 *
 */
public class OverLoading {
	public int add(int n1, int n2){
		return n1+n2;
	}
	//number of parameters
	public int add(int n1, int n2, int n3){
		return n1+n2+n3;
	}
	//data type of parameters
	public double add(double n1, int n2, int n3){
		return n1+n2+n3;
	}
	//sequence of parameters
	public double add( int n2, int n3,double n1){
		return n1+n2+n3;
	}
	//VAR Arg -variable argument
	public double add(double... nArr){
		double sum=0;
		for (int i = 0; i < nArr.length; i++) {
			sum+=nArr[i];
		}
		return sum;
	}
	//VAR Arg -variable argument must be the last parameter
	public double add(String name,double... nArr){
		System.out.println("hello , "+name);
		System.out.println("Total bill AMount: ");
		double billAmt=0;
		for (int i = 0; i < nArr.length; i++) {
			billAmt+=nArr[i];
		}
		return billAmt;
	}
	public static void main(String[] args) {
		OverLoading o1= new OverLoading();
		System.out.println("Adding 3 int "+o1.add(12, 12,12));

		System.out.println("Adding 2 int and 1 double "
					+o1.add(12, 12,76.0));
		System.out.println("Adding 1 double and 2 int "
				+o1.add(12.0, 12,76));
		System.out.println("Adding number "
				+o1.add(12.0, 12,76,89,89,78,67,65));
		System.out.println("Calculating Bill Amount for \n"
				+o1.add("Smita",12.0, 12,76,89,89,78,67,65));
	}

}









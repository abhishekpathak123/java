package com.capgemini.cust;
import com.capgemini.date.MyDate;

/**
 * @author smita
 *
 */
public class Customer {
	//member variables
	private int custId;
	private String custName;
	private MyDate dob;//containment-(HAS-A relation)
	private String email;
	private long contactNo;
	private static int numId;
	//static initializer block
	static{
		numId=(int) (1000+Math.random());//auto-generating number
	}
	//initializer block
	{
		custId=numId++;
	}
	//no-arg contr
	public Customer() {
		System.out.println("----Customer no-arg contr------");
	}
	//overLoaded contr
	public Customer(String custName, MyDate dob, String email, long contactNo) {
		super();
		System.out.println("----Customer overLoaded contr------");
		this.custName = custName;
		this.dob = dob;
		this.email = email;
		this.contactNo = contactNo;
	}
	//toString
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName
				+ ", dob=" + dob + ", email=" + email + ", contactNo="
				+ contactNo + "]";
	}
	//equals and hashCode
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return custId;
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return this.hashCode()==obj.hashCode();
	}
	//business method
	public void print(){
		System.out.println(""
				+ "\n================Customer Details=====================\n"
				+ "\n                Id        : "+custId
				+ "\n                Name      : "+custName
				+ "\n                email     : "+email
				+ "\n                DOB       : "+dob
				+ "\n                contactNo : "+contactNo
				+ "\n====================================================\n"
				);
	}
	//getters and setters
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public MyDate getDob() {
		return dob;
	}
	public void setDob(MyDate dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}
	
}

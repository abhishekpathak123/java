//step 1: package declaration
package com.capgemini.date;
//step 2 : import statement
/**
 * @author smita
 *
 */
//step 3: public class
public class MyDate {
//step 4:member variables
	private int day;
	private int month;
	private int year;
//step 5: no-arg contr
		public MyDate() {
			System.out.println("*****MyDate default contr*******");
		}
//step 6: overloaded contr
		public MyDate(int day, int month, int year) {
			super();
			System.out.println("*****MyDate overloaded contr*******");
			this.day = day;
			this.month = month;
			this.year = year;
		}
//step 7 : business method
		public void print(){
			System.out.println(day+"-"+month+"-"+year);
		}
//step 7 : toString() method
		@Override
		public String toString() {
			return "MyDate [day=" + day + ", month=" + month + ", year=" + year
					+ "]";
		}
//step 8: override equals
		public boolean equals(Object obj){
			//checking weather obj is instance of MyDate or not
			if(obj instanceof MyDate){
				//type cast Object to MyDate
				MyDate ref = (MyDate)obj;
				//d1.equals(d2)
				if((ref.day==this.day)
					&&(ref.month==this.month)
					&&(ref.year==this.year)
				  ){
					return true;
				}//end of inner if
				
			}//end of outer if
			return false;
		}
}//end of class














/**
 * 
 */
package com.capgemini.client;

import com.capgemini.date.MyDate;


/**
 * @author smita
 *
 */

public class DateClient {
	public static void main(String[] args) {
		int amount=10_000;
		MyDate today = new MyDate(9, 12, 2016);
		System.out.println("=========Seting Today s Date========");
		//today.setDate(9, 12, 2016);
		System.out.println("=========Displaying Today s Date========");
		today.print();
		MyDate joinDate = new MyDate();
		System.out.println("=========Seting joinDate s Date========");
		//today.setDate(14, 11, 2016);
		System.out.println("=========Displaying joinDate s Date========");
		today.print();
		MyDate bday = new MyDate();
		System.out.println("=========Seting bday s Date========");
	//	today.setDate(29, 6, 1994);
		System.out.println("=========Displaying bday s Date========");
		today.print();
	}

}

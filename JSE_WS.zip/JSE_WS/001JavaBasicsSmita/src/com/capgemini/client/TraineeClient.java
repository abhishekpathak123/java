/**
 * 
 */
package com.capgemini.client;

import com.capgemini.trainee.Trainee;
import static java.lang.System.out;

/**
 * @author smita
 *
 */
public class TraineeClient {
	int id;
	public static void print(){
		//non-static var can't be refer directly within static method
		//non-static var can be used using com.capgemini.ch5.object refernce
		TraineeClient obj1 = new TraineeClient();
		System.out.println("print() is a static method : "+obj1.id);
		//this cannot be used within static context
	}
	public void display(){
		out.println("display() is a non-static method "+this.id);
		//this means current com.capgemini.ch5.object
	}
	public static void main(String[] args) {
		//className.methodName()
		TraineeClient.print();
		TraineeClient tc1 = new TraineeClient();
		tc1.id=101;
		tc1.display();
		TraineeClient tc2 = new TraineeClient();
		tc2.id=102;
		tc2.display();
		TraineeClient tc3= new TraineeClient();
		tc3.id=102;
		tc3.display();
		//creating com.capgemini.ch5.object t1 of Trainee class
		Trainee t1 = new Trainee();
		out.println("T1 : "+t1);
		//wehever we try to print an com.capgemini.ch5.object, callback is given to
		//toString() method of Object class from java.lang package
		
		//invoking overloaded contr
		Trainee t2 = new Trainee("Nitesh", "nit@g.com", "9876543212",true);
		out.println("Printing T2 ........");
		t2.print();//calling print() method of Trainee class
		
		/*
		 * in certain scenario when we have to provide access to 
		 * private variable thats why we need to provide 
		 * getter and setter method for each private variables
		 */
		//t2.email="nit@gmail.com";
		out.println("Editing email of trainee t2.....");
		t2.setEmail("nit@gmail.com");
		out.println("Email edited of trainee t2 : "
							+t2.getEmail());
		
	}//eom

}//eoc











package com.capgemini.ch4.enumdemo;

import java.util.Scanner;

public class ClassEnumTest {
	enum season{
		SUMMER,WINTER,RAINY;
	}
	public static void main(String[] args) {
		System.out.println("Enter you fav season");
		Scanner sc = new Scanner(System.in);
		System.out.println("You have selected : "+season.valueOf(sc.next().toUpperCase()));
	}
}

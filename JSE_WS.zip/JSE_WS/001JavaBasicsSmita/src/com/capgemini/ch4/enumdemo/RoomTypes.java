/**
 * 
 */
package com.capgemini.ch4.enumdemo;

/**
 * @author smita
 *
 */
public enum RoomTypes {
	AC(1500),NON_AC(1000),DELUX(5000);
	private double rates;

	private RoomTypes(double rates) {
		this.rates = rates;
	}

	public double getRates() {
		return rates;
	}

	public void setRates(double rates) {
		this.rates = rates;
	}
	
}

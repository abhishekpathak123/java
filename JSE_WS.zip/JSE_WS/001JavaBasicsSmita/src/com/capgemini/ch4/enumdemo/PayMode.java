/**
 * 
 */
package com.capgemini.ch4.enumdemo;

/**
 * @author smita
 *
 */
public enum PayMode {	
	CASH(1),CREDIT(2),DEBIT(3),NETBANKING(4);
	private int mode;
	private PayMode(int mode){
		this.mode=mode;
	}
	public int getMode() {
		return mode;
	}
	public void setMode(int mode) {
		this.mode = mode;
	}
}

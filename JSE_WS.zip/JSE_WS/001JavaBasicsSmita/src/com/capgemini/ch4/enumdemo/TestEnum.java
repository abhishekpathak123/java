/**
 * 
 */
package com.capgemini.ch4.enumdemo;

import java.util.Scanner;

/**
 * @author smita
 *
 */
public class TestEnum {
	public static void main(String[] args) {
		System.out.println("ROOM		RATES\n");
		for (RoomTypes types : RoomTypes.values()) {
			System.out.println(types + " : " + types.getRates());
		}
		System.out.println("________________________________________\n");
		System.out.println("Enter the Room Types");
		Scanner sc = new Scanner(System.in);
		RoomTypes  rt1=RoomTypes.valueOf(sc.next().toUpperCase());
		System.out.println("Rates for Ac rooms : "
					+rt1.getRates());

	}

}

package com.capgemini.ch5.wrapper;
//Wrapper class in java provides the mechanism to 
//convert primitive into com.capgemini.ch5.object and com.capgemini.ch5.object into primitive.
public class IntegerDemo {
	public static void main(String[] arg)
	{	
		//Converting int value into Integer  Object
		int a=20;  
		Integer iObj=Integer.valueOf(a);//converting int into Integer  
		Integer jObj=a;//autoboxing, now compiler will write Integer.valueOf(a) internally  
		  
		System.out.println(a+" "+iObj+" "+jObj);  
		
		//Converting Integer to int    
		Integer obj=new Integer(3);  
		//unboxing
		int i=obj.intValue();//converting Integer to int  
		int j=obj;//unboxing, now compiler will write a.intValue() internally    
		    
		System.out.println(obj+" "+i+" "+j);    
		
		//String
		String s1 = "35684";   // declare a string variable

		Integer intObj = Integer.parseInt(s1); // the parseInt method converts a String com.capgemini.ch5.object to an Integer com.capgemini.ch5.object

		int intValue = intObj.intValue(); //the Integer com.capgemini.ch5.object y is converted to an int variable x using the intValue method of the Integer class
		System.out.println("intValue :"+intValue);
		String str = Integer.toString(intValue);//converting int to String
		System.out.println("str :"+str);
	}
}

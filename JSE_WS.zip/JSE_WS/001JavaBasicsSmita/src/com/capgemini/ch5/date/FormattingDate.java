package com.capgemini.ch5.date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Scanner;
/**
 * This program demonstrates on how to format com.capgemini.ch5.date and time
 *
 */
public class FormattingDate {
	public static void main(String[] args) {
		/*	DateTimeFormatter is used to configure the com.capgemini.ch5.date time format
			DateTimeFormatter can also be obtained by using ofPattern() 
			which you can use for custom com.capgemini.ch5.date and time format
		 */
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = 
				DateTimeFormatter.ofLocalizedDate(
						FormatStyle.FULL);
		//SHORT mm/dd/yy
		//MEDIUM MON DD, YYYY
		//LONG MONTH DD, YYYY
		//FULL Friday, October 28, 2016		
		
		//Almost every class in java.time package provides format() method to format the com.capgemini.ch5.date or time
		System.out.println(currentDate.format(formatter));
//parsing Date		
		formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter com.capgemini.ch5.date in dd/MM/yyyy format:");
		String input  = scanner.nextLine();
		
		//Almost every class in java.time package provides parse() method to parse the com.capgemini.ch5.date or time
		LocalDate enteredDate = LocalDate.parse(input,formatter);

		System.out.println("Entered Date:"+ enteredDate);
		scanner.close();
		
	}
}

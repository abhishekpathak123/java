package com.capgemini.ch5.date;

import java.util.Date;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class DateDemo {

	public static void main(String[] args) {
		Date today = new Date();
		System.out.println("Today : "+today);
		
		Instant currentTime=Instant.now();
		System.out.println("Current Time : "+currentTime);
		
		LocalDate localDate = LocalDate.now();
		System.out.println("LocalDate : "+localDate);
		
		System.out.println("Diwali is on "+localDate.withDayOfMonth(30));
		
		ZonedDateTime zoneNow = ZonedDateTime.now();
		System.out.println("Zoned Date Time India: "+zoneNow);
		
		ZonedDateTime zoneParis = ZonedDateTime.now(
								ZoneId.of("Europe/Paris"));
		System.out.println("Zoned Date Time Paris: "+zoneParis);
	}

}

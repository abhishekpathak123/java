/**
 * 
 */
package com.capgemini.ch5.date;

import java.time.Instant;
import java.time.LocalDate;

/**
 * @author smita
 *
 */
public class InstanceDemo {
	public static void main(String[] args) {
		Instant currentTime = Instant.now();
		System.out.println("Instance : "+currentTime);
		
		LocalDate date= LocalDate.now();
		System.out.println("LocalDate : "+date);
	}

}

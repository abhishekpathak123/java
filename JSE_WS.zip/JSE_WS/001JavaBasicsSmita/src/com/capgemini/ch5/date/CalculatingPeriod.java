/**
 * 
 */
package com.capgemini.ch5.date;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

/**
 * @author smita
 *
 */
public class CalculatingPeriod {

	public static void main(String[] args) {

		LocalDate today = LocalDate.now();
		System.out.println("Today is : "+today);//yyyy-MM-dd
		LocalDate independece = LocalDate.of(1947,Month.AUGUST,15);


		Period period = independece.until(today);
		System.out.println("---Period since independence---");
		System.out.println(period.getYears()+"- Years" );		
		System.out.println(period.getMonths()+"- Months");
		System.out.println(period.getDays()+"- Days");

	}
}
package com.capgemini.ch5.date;

import java.time.ZoneId;
import java.time.ZonedDateTime;

public class ZonedDateTimeDemo {

	public static void main(String[] args) {
		
		ZonedDateTime currentTime = ZonedDateTime.now();
		System.out.println("India:"+ currentTime);
		
		ZonedDateTime currentTimeInParis = 
				ZonedDateTime.now(ZoneId.of("Europe/Paris"));
		
		System.out.println("Paris:"+ currentTimeInParis);
		ZonedDateTime currentTimeInNewYork = 
				currentTime.withZoneSameInstant(ZoneId.of("America/New_York"));
		
		System.out.println("New York:"+ currentTimeInNewYork);
		
		
	}
}

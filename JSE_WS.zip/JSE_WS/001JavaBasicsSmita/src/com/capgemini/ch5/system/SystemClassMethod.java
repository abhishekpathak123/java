/**
 * 
 */
package com.capgemini.ch5.system;

import java.util.Date;

/**
 * @author shosakop
 *
 */
public class SystemClassMethod {

	public static void main(String[] args) {
		System.out.println("System properties are: ");		
		System.out.println(System.getProperties());//fetch all the system properties
		
		long startTime =System.currentTimeMillis();
		System.out.println("Started using net cafe.....");
		int count=0;
		for(int i=1;i<=100000;i++){
			count++;
		}
		System.out.println("Loggin out from net cafe.....");
		long endTime =System.currentTimeMillis();
		long totalTime= endTime-startTime;
		System.out.println("Time Consumed "+totalTime +" milisec");
		
		System.out.println("Current time in ms: " + System.currentTimeMillis());
		Date d=new Date(System.currentTimeMillis());
		System.out.println(d);
		
		System.exit(0);//exit the program
		System.gc();//request garbage collector
	}

}

/**
 * 
 */
package com.capgemini.ch5.string;

import java.util.Scanner;

/**
 * @author smita
 *
 */
public class StringMethod {
	public static void main(String[] args) {
		String s1 = new String("cg");
		System.out.println(" s1 : "+s1.hashCode());
		String s2=s1.toUpperCase();
		System.out.println(" s1.toUpperCase() : "+s1.toUpperCase());
		System.out.println(" s2 : "+s2);
		System.out.println(" s1.toUpperCase() : "+s1.toLowerCase());
		s1=s1.replace('c', 'C');
		System.out.println("s1.Replace(oldChar c ,newChar C) : "+s1);
		System.out.println(" s1 : "+s1.hashCode());
		s2=s2.concat("-India");//CG-India
		//String index starts with 0 CG
		System.out.println("charAt() : "+s2.charAt(5));
		
		//begin from 2nd index including 2nd index
		System.out.println("substring(2) : "+s2.substring(2));
		System.out.println("Length of String s2 : "+s2.length());
		//begin from 2nd index including 2nd index, excluding 5th index
		System.out.println("substring(2,5) : "+s2.substring(2,5));
		
		//how to convert integer to String
		int phone=9876;
		String strPh=String.valueOf(phone);
		/*System.out.println("Enter you choice : \n1. CASH\n2. CREDIT");
		Scanner sc = new Scanner(System.in);
		String choice = sc.next();
		//if(choice=="CASH"){
		if(choice.equalsIgnoreCase("Cash")){
			System.out.println("You have selected CASH");
		}
		else if(choice.equalsIgnoreCase("Credit")){
			System.out.println("You have selected CREDIT");
		}
		else{
			System.out.println("You have selected wrong choice");
		}*/
//string are immutable class in java
		//cannot be changed
		//any changes made to a String obj , a new obj will be creates
	}
	

}

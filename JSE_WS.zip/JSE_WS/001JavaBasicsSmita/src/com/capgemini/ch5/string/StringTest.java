package com.capgemini.ch5.string;

public class StringTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc";
		System.out.println("s1 hashCode Before:"+s1.hashCode());
		s1="abcxyz";
		System.out.println("s1 hashCode After:"+s1.hashCode());
		String s2 = "abcxyz";
		System.out.println("s2 hashCode :"+s2.hashCode());
		String s3 = "abcxyz";
		System.out.println("s3 hashCode :"+s3.hashCode());
		
		String str1 = new String("cg");
		String str2 = new String("cg");
		//== compares hashCode
		System.out.println("str1 == str2" +str1==str2);
		//equals() method of String class compares values
	  System.out.println("str1.equals(str2) :"+str1.equals(str2));
		
	}

}

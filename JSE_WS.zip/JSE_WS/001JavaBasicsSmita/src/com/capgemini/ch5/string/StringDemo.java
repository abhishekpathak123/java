/**
 * 
 */
package com.capgemini.ch5.string;

/**
 * @author smita
 *
 */
public class StringDemo {
	public static void main(String[] args) {
		Object o1 = new Object();
		Object o2 = new Object();
		String s1 = new String("cg");
		String s2 = new String("cg");
		//equals of String class compares values
		System.out.println("s1.equals(s2) --- "+s1.equals(s2));
		//== compares references/hashCode of String 
		System.out.print("\ns1==s2 --- ");
		System.out.println(s1==s2);
		
/*String pooling*/	
		//when we declare String obj as primitive (not using new operator)
		//and values are same then string pool will be created
		//and both the string obj will share the same reference
		String str1="india";
		String str2="india";
		//equals of String class compares values
System.out.println("str1.equals(str2) --- "+str1.equals(str2));
//== compares references/hashCode of String 
		System.out.print("\nstr1==str2 --- ");
		System.out.println(str1==str2);		
		System.out.println("hashCode str1 : "+str1.hashCode());
		System.out.println("hashCode str2 : "+str2.hashCode());
		
		
		
		
		
		//equals of Object class compares references/hashCode
		//System.out.println("o1.equals(o2) --- "+o1.equals(o2));

	}

}

/**
 * 
 */
package com.capgemini.ch5.object;
import com.capgemini.date.MyDate;
import com.capgemini.emp.Employee;

/**
 * @author smita
 *
 */
public class ObjectMethod {
	public static void main(String[] args) {
		MyDate d1 = new MyDate(11,11,2011);
		MyDate d2 = new MyDate(11,11,2011);
		
		System.out.println("Are two com.capgemini.ch5.date com.capgemini.ch5.object equals : "
						+d1.equals(d2));
		System.out.println("d1 hasCode : "+d1.hashCode());
		System.out.println("d2 hasCode : "+d2.hashCode());
		
		Employee e1 = new Employee("smita", 9999, d1);
		Employee e2 = new Employee("smita", 9999, new MyDate(11,11,2011));
		System.out.println("e1 hasCode : "+e1.hashCode());
		System.out.println("e2 hasCode : "+e2.hashCode());
	}
}





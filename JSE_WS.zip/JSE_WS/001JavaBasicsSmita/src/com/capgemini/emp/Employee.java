/**
 * 
 */
package com.capgemini.emp;

import com.capgemini.date.MyDate;

/**
 * @author smita
 *
 */
public class Employee {
//member variables
	//protected will be accessible within the package and
	//to the subclass outside the package
	protected int empId;
	protected String empName;
	protected double empSal;
	protected MyDate joinDate;
//containment(HAS-A)-com.capgemini.ch5.object of another class as member of our class
	private static int numId;
	private static String coName;
	private static int empCount;
	//static initializer block
	static{//to initialize only static var
		numId=(int) (1000+Math.random());
		//auto-generating number
		coName="Capgemini India Pvt. Ltd.";
		empCount=1;//
	}
	//initializer block
	{
		empCount++;
		empId=numId++;
	}
	//no-arg contr
	public Employee() {
		System.out.println("-----Empolyee No-Arg Contr-----");
		/*empCount++;
		empId=numId;*/
	}
	//overloaded contr
	public Employee(String empName, double empSal, MyDate joinDate) {
		super();
		System.out.println("-----Empolyee Overloaded Contr-----");
		this.empName = empName;
		this.empSal = empSal;
		this.joinDate = joinDate;
		/*empCount++;
		empId=numId;*/
	}
	//business method -calculateSal() and print()
	public void print(){
		System.out.println(""
				+ "\n================Empolyee Details=====================\n"
				+ "\n                Id        : "+empId
				+ "\n                Name      : "+empName
				+ "\n                Salary    : "+calculateSal()
				+ "\n                joinDate  : "+joinDate
				+ "\n                coName    : "+coName
				+ "\n====================================================\n"
				);
	}
	public double calculateSal(){
		System.out.println("-------Employee calculateSal() invoked-----");
		return empSal;
	}
	//toString method
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + calculateSal() + ", joinDate=" + joinDate + "]";
	}
	//override equals() and hashCode()
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return empId;//return unique hashCode i.e empId is unique
	}
	@Override
	public boolean equals(Object obj) {
		return obj.hashCode()==this.hashCode();
	}
	//getters and setters
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}
	public MyDate getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(MyDate joinDate) {
		this.joinDate = joinDate;
	}
	public static String getCoName() {
		return coName;
	}
	public static void setCoName(String coName) {
		Employee.coName = coName;
	}
	public static int getEmpCount() {
		return empCount;
	}
	public static void setEmpCount(int empCount) {
		Employee.empCount = empCount;
	}	
}//end of class













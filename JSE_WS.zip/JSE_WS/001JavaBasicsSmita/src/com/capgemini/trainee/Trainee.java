/**
 * class to create Trainee com.capgemini.ch5.object 
 */
//step 1: package declaration
package com.capgemini.trainee;
//step 2: imports(we can import only public class
/**
 * @author smita
 *
 */
//step 3: public class
public class Trainee {
//step 4: private member variables
	private int traineeId;
	private String traineeName;
	private String email;
	private String phoneNo;
	private boolean status;
	private static String coName;
	private static int numId;
	private static int traineeCount;
//step 5: static block-used to initialize only static variables
	static{
		coName="Capgemini India Pvt. Ltd.";
		//static method are invoked by className.methodName()
		numId=(int) (1000+Math.random()*111.111);
		//auto-generating id
		traineeCount=0;
	}
//step 6: 	//to initialize any value we have a init block
	{
		traineeId=numId++;
		traineeCount++;//incrementing the traineeCount
	}
//step 7: No-Argument constructor
	public Trainee() {
		System.out.println("Trainee no-arg contr invoked....");
	}
//step 8: Overloaded constructor	
	
//local variable name and the instance var name can be same
//in such case instance var will be referred using 'this' keyword
//'this' means current com.capgemini.ch5.object

	public Trainee(String traineeName, String email, String phoneNo, boolean status) {
		super();
		this.traineeName = traineeName;
		this.email = email;
		this.phoneNo = phoneNo;
		this.status = status;
	}
//step 9: override toString() method
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", email=" + email + ", phoneNo=" + phoneNo
				+ ", status=" + status + "]";
	}
	
//step 10: business method
	public void print(){
		System.out.println(""
				+ "\n================Trainee Details=====================\n"
				+ "\n                Id     : "+traineeId
				+ "\n                Name   : "+traineeName
				+ "\n                Email  : "+email
				+ "\n                Status : "+status
				+ "\n                coName : "+coName
				+ "\n====================================================\n"
				);
	}


	// step 11: provide getters and setters for each private var
	/*
	 * Rules for getter and setter methods
	 * 
	 * all getters and setters methods must be public
	 
	 */
	/* getter method prefic is get followed by var name
	 * eg: getXxxx() 
	 * return same data type of var and no paramter list
	 */

	//in case of boolean var the getter method can be prefix by 
	//'is' instead of 'get'
		public boolean isStatus() {
			return status;
		}
	public String getEmail(){
		return email;		
	}
	/* setter method prefix is set followed by var name
	 * eg: setXxxx() 
	 * return void and parameter same data type of var
	 */
	//in case of static var the getter and setter must be also static
	public static String getCoName() {
		return coName;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public void setEmail(String email){
		this.email=email;
	}
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	public static void setCoName(String coName) {
		Trainee.coName = coName;
	}
	public static int getTraineeCount() {
		return traineeCount;
	}
	public static void setTraineeCount(int traineeCount) {
		Trainee.traineeCount = traineeCount;
	}
}












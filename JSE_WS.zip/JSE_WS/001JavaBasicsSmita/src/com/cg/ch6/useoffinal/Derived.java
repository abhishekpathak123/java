package com.cg.ch6.useoffinal;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/*
 * Below code will not work 
 * as class Base is declared as final
 */
/*public class Derived extends Base {

 }
 */
//What will be output of this stream API java 8 program ? 
class StreamDemo {
	public static void main(String[] args) {
		List<Integer> intList = Arrays.asList(5,7,3,9);
		Optional<Integer> result = intList.stream().reduce((a,b)->a+b);
		if(result.isPresent()) {
			System.out.println("Result:"+result.get());
		}
	
	}
}
/*
/*List<String> words = Arrays.asList("CAPGEMINI", "GLOBAL", "SOLUTIONS");
words.stream().map(str -> str.length()).forEach(System.out::println);
*/
//What will be output of this stream API java 8 program ? 

package com.cg.finaldemo;

public class Circle{
	//all uppercase seperated by '_' underscore
	//final variable must be initialize and cannot be reinitialized
	private static final float PI;
	private static final String CIRCLE_COLOR="RED";
	static{
		PI=3.14f;
	}
	public float getRadius() {
		return radius;
	}
	public void setRadius(float radius) {
		this.radius = radius;
	}
	public static float getPi() {
		return PI;
	}
	
	public static String getCircleColor() {
		return CIRCLE_COLOR;
	}
	
	private float radius;
	
	public Circle (float r) {
    			radius = r;
  	}
  	public float area ( ) {
    			return PI * radius * radius;
  	}
  	public float periphery ( ) {
    			return 2 * PI * radius;
  	}
}
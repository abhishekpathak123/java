/**
 * 
 */
package com.capgemini.ch10.set;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.capgemini.ch10.list.Account;

/**
 * @author shreya
 *
 */
public class SetDemo {
	public static void main(String[] args) {
		
		Set<String> hs = new HashSet<String>();
		hs.add("A");
		hs.add("B");
		hs.add("C");
		hs.add("D");
		hs.add("E");
		hs.add("E");
		hs.add("F");
		System.out.println(hs);
		
		Account a1 = new Account("Dia",555);
		Account a2 = new Account("Esha",444);
		Account a3 = new Account("Bina",111);
		Account a4 = new Account("Chitra",333);
		Account a5 = new Account("Aish",222);
		Set<Account> accSet = new TreeSet<>();
		//add elements to the hash set
		accSet.add(a1);
		accSet.add(a2);
		accSet.add(a3);
		accSet.add(a3);
		accSet.add(a4);
		accSet.add(a5);
		//System.out.println(accSet);
		Iterator<Account> iter = accSet.iterator();
		while(iter.hasNext()){
			System.out.println(iter.next());
		}
		System.out.println("*****Employees******");
		Employee e1 = new Employee(222, "Eeena", 333.33);
		Employee e2 = new Employee(111, "Beena", 222.22);
		Employee e3 = new Employee(555, "Cia", 444.44);
		Employee e4 = new Employee(333, "Dia", 555.55);
		Employee e5 = new Employee(444, "Aashu", 111.11);
		Employee e6 = new Employee(222, "Eeena", 333.33);
		// create a Tree set
		Set<Employee> empSet = new TreeSet<>();
		// add elements to the hash set
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e3);
		empSet.add(e4);
		empSet.add(e5);
		empSet.add(e6);
		Iterator<Employee> it = empSet.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}
}

package com.capgemini.ch10.list;

import java.util.Comparator;

/**
 * @author shreya
 *
 */
public class SortAccByName implements Comparator<Account>{

	@Override
	public int compare(Account o1, Account o2) {
		
		return o1.getAccHolderName().compareTo(o2.getAccHolderName());
		
	}
		
}

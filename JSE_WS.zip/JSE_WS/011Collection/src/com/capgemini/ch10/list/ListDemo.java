package com.capgemini.ch10.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * @author shreya
 *
 */
public class ListDemo {
	public static void main(String[] args) {
		//Generics to achieve type safety in Java
		/*List<Account> acclist = new ArrayList<>();*/
		/*list.add(1234);
		 * list.add('z');*/
		/*list.add("D");
		list.add("B");
		list.add("A");
		list.add("C");
		list.add(2, "E");*/
		/*System.out.println(list);*/
		Account a1 = new Account("Dia",555);
		Account a2 = new Account("Esha",444);
		Account a3 = new Account("Bina",111);
		Account a4 = new Account("Chitra",333);
		Account a5 = new Account("Aish",222);
		List<Account> accList = new ArrayList<>();
		accList.add(a1);
		accList.add(a2);
		accList.add(a3);
		accList.add(a4);
		accList.add(a5);
		Iterator<Account> iter = accList.iterator();
		while(iter.hasNext()){
			System.out.println(iter.next());
		}
		Collections.sort(accList);
		System.out.println("accList sort by Acc Id");
		iter = accList.iterator();
		while(iter.hasNext()){
			System.out.println(iter.next());
		}
		//sorting by accHolderName
		SortAccByName c = new SortAccByName();
		Collections.sort(accList, c);
		System.out.println("accList sort by Acc Holder Name");
		iter = accList.iterator();
		while(iter.hasNext()){
			System.out.println(iter.next());
		}
		//sorting by Acc Balance
		SortByAccBal c1 = new SortByAccBal();
		Collections.sort(accList, c1);
		System.out.println("accList sort by Acc Balance");
		iter = accList.iterator();
		while(iter.hasNext()){
			System.out.println(iter.next());
		}
	}

}

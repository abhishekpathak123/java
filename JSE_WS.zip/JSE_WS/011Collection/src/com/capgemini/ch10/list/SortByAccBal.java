/**
 * 
 */
package com.capgemini.ch10.list;

import java.util.Comparator;

/**
 * @author shreya
 *
 */
public class SortByAccBal implements Comparator<Account> {

	@Override
	public int compare(Account o1, Account o2) {
		
		return o1.getBalance()-o2.getBalance();
	}

}

package com.capgemini.ch10.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * @author shreya
 *
 */
public class MapDemo {
	public static void main(String[] args) {
		Map<String, String> map = new HashMap<>();
		map.put("333","Cia");
		map.put("222","Aish");
		map.put("111","Bina");
		//map doesnt support iterator
		Set set = map.entrySet();
		//obtain the iteator for the set
		Iterator iter = set.iterator();
		while(iter.hasNext()){
			//enter the map inside the set
			Map.Entry me = (Map.Entry) iter.next();
			//and then getKey and getValue of map
			System.out.println(me.getKey() + " : " +me.getValue());
		}
	}
}

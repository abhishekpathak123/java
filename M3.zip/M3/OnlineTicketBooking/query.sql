CREATE TABLE ShowDetails(ShowId VARCHAR2(5) PRIMARY KEY,
ShowName VARCHAR2(30) UNIQUE,
Location VARCHAR2(20),
ShowDate DATE,
AvSeats NUMBER(3),
PriceTicket NUMBER(5,2));


INSERT INTO ShowDetails VALUES('S101','Golmaal','Cinepollis','02-Nov-17',30,200);
INSERT  INTO ShowDetails VALUES('S102','ITEFAQ','BigCinmas','03-Nov-17',25,250);
INSERT INTO ShowDetails VALUES('S103','Thor Ragnarok','PVR','11-Nov-17',35,350);
INSERT INTO ShowDetails VALUES('S104','GeoStorm','Victory Hall','05-Nov-17',40,375);
INSERT INTO ShowDetails VALUES('S105','Padmavati','Chestnut Drive','04-Nov-17',50,475);
COMMIT;

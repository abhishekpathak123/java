package com.capgemini.otb.util;

import java.sql.Connection;

import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class DBUtil {

	public static Connection getConnection() 
			throws NamingException, SQLException, ClassNotFoundException
	{
		Connection con= null;
		InitialContext ctx = new InitialContext();
		
		DataSource dataSource =(DataSource)ctx.lookup("java:/jdbc/TestDs");
		
		con = dataSource.getConnection();
		return con;
		
	}
}

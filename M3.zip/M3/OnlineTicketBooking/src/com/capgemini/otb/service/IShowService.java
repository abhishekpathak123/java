package com.capgemini.otb.service;

import java.util.List;

import com.capgemini.otb.dto.ShowDetails;
import com.capgemini.otb.exception.ShowException;

public interface IShowService {
	List<ShowDetails> getShowDetails() throws ShowException ;
	public ShowDetails getShowDetail(String showid) throws ShowException ;
	public void updateShowDetails(int seats , String showname) throws ShowException ;
}

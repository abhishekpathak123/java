package com.capgemini.otb.service;

import java.util.List;

import com.capgemini.otb.dto.ShowDetails;
import com.capgemini.otb.exception.ShowException;
import com.capgemini.otb.dao.IShowDAO;
import com.capgemini.otb.dao.ShowDAOImpl;

public class ShowServiceImpl implements IShowService {
	IShowDAO showDAO ;

	public ShowServiceImpl() {
		showDAO = new ShowDAOImpl();
	}

	@Override
	public List<ShowDetails> getShowDetails() throws ShowException {
		
		return showDAO.getShowDetails();
	}

	@Override
	public ShowDetails getShowDetail(String showid) throws ShowException {
		
		return showDAO.getShowDetail(showid);
	}

	@Override
	public void updateShowDetails(int seats, String showname)
			throws ShowException {
		 showDAO.updateShowDetails(seats , showname);

	}

}

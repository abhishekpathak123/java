package com.capgemini.otb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.capgemini.otb.dto.ShowDetails;
import com.capgemini.otb.exception.ShowException;
import com.capgemini.otb.util.DBUtil;

public class ShowDAOImpl implements IShowDAO {

	@Override
	public List<ShowDetails> getShowDetails() throws ShowException {
		List<ShowDetails> showDetailsList = new ArrayList<ShowDetails>();
		
		try ( Connection con = DBUtil.getConnection())
		{
			Statement stm=con.createStatement();
					ResultSet res=
							stm.executeQuery("select ShowId,ShowName, Location,ShowDate,AvSeats,PriceTicket from ShowDetails");
			
					while (res.next()) {
						ShowDetails show = new ShowDetails();
						show.setShowId(res.getString(1));
						show.setShowName(res.getString(2));
						show.setLocation(res.getString(3));
						show.setShowDate(res.getDate(4));
						show.setAvailableSeats(res.getInt(5));
						show.setPrice(res.getDouble(6));
						showDetailsList.add(show);
					}
		} catch (Exception e) {
			throw new ShowException(e.getMessage() );
		}
		return showDetailsList;
	}

	@Override
	public ShowDetails getShowDetail(String showid) throws ShowException {
		ShowDetails show = null;
		
		try( Connection con = DBUtil.getConnection()) {
			
			PreparedStatement pstm = con.prepareStatement("select * from showdetails where showid=?");
			pstm.setString(1, showid);
			 pstm.executeQuery();
			 ResultSet res= pstm.executeQuery();
			if(res.next()){
			show = new ShowDetails();
			show.setShowId(res.getString(1));
			show.setShowName(res.getString(2));
			show.setLocation(res.getString(3));
			show.setShowDate(res.getDate(4));
			show.setAvailableSeats(res.getInt(5));
			show.setPrice(res.getDouble(6));
			}
		} catch (SQLException e) {
			// e.printStackTrace();
			throw new ShowException("Problem while fetching show details");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NamingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return show ;
	}
	@Override
	public void updateShowDetails(int seats, String showname)
			throws ShowException {
		
		try ( Connection con = DBUtil.getConnection()){
			PreparedStatement pstm = con.prepareStatement("update showdetails set avseats = ? where showname = ?");
			pstm.setInt(1, seats);
			pstm.setString(2, showname);
			pstm.executeUpdate();
		} catch (SQLException e) {
			// e.printStackTrace();
			throw new ShowException("Problem while updating the table");
		} catch (ClassNotFoundException e1) {
		
			e1.printStackTrace();
		} catch (NamingException e1) {	// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		

	}

}

package com.capgemini.otb.exception;

public class ShowException extends Exception {

	public ShowException() {
		
	}

	public ShowException(String message) {
		super(message);
		
	}

	public ShowException(Throwable cause) {
		super(cause);
		
	}

	public ShowException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public ShowException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

}

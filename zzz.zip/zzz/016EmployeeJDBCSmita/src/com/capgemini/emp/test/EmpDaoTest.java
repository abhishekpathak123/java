/**
 * 
 */
package com.capgemini.emp.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.emp.bean.Employee;
import com.capgemini.emp.dao.EmployeeDaoImpl;
import com.capgemini.emp.exception.EmployeeException;

/**
 * @author Smita
 *
 */
public class EmpDaoTest {
	 EmployeeDaoImpl employeeDao;	
	@Before
	public  void testEmpDaoImpl(){
		employeeDao= new EmployeeDaoImpl();
	}
	@Test
	public void testAddEmployee1() throws EmployeeException {
		int empId=employeeDao
				.addEmployee(
						new Employee(999, "Raj", 999));
		System.out.println("Unique Id : "+empId);
		assertNotEquals(0, empId);
		
	}
	
	@Test
	public void testAddEmployee2() throws EmployeeException {
		int empId=employeeDao.addEmployee(new Employee(999, "Raj", 999));
		System.out.println("Unique Id : "+empId);
		assertTrue(empId>0);		
	}
	@Test
	public void testListEmployee1() throws EmployeeException {
		List<Employee> empList=employeeDao.listAllEmployee();
		assertNotNull("Employee List Not Found",
				empList);
		for(Employee emp:empList)
			System.out.println(emp);
		
	}
	@Test
	public void testListEmployee2() throws EmployeeException {
		List<Employee> empList=employeeDao.listAllEmployee();
		assertTrue("Employee List Not Found",
				empList!=null);
		for(Employee emp:empList)
			System.out.println(emp);
		
	}
	@Ignore
	@Test
	public void testDeleteEmployee1() throws EmployeeException {
		int result=employeeDao.deleteEmployee(101);
		System.out.println("No of Employee deleted : "+result);
		assertTrue(result>0);		
	}
	@Ignore
	@Test
	public void testDeleteEmployee2() throws EmployeeException {
		int result=employeeDao.deleteEmployee(444);
		System.out.println("No of Employee deleted : "+result);
		assertTrue(result>0);		
	}
	@Test
	public void testUpdateEmployee1() throws EmployeeException {
		int result=employeeDao.updateEmployee(new Employee(140, "Raj Kate", 11111));
		System.out.println(result+"...Employee Updated : ");
		assertTrue(result>0);		
	}
	@Test
	public void testUpdateEmployee2() throws EmployeeException {
		int result=employeeDao.updateEmployee(new Employee(140, "Raj Kate", 11111));
		System.out.println(result+"...Employee Updated : ");
		assertEquals(1,result);		
	}
	@Test
	public void testSearchEmployee1() throws EmployeeException {
		Employee emp=employeeDao.searchEmployee(140);
		assertNotNull("Employee  Not Found",
				emp);		
		System.out.println("Employee Record....."+emp);		
	}
	@Test
	public void testSearchEmployee2() throws EmployeeException {
		Employee emp=employeeDao.searchEmployee(140);
		assertTrue("Employee  Not Found",
				emp!=null);		
		System.out.println("Employee Record....."+emp);		
	}
}

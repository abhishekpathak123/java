/**
 * 
 */
package com.capgemini.emp.exception;

/**
 * @author Smita
 *
 */
public class EmployeeException extends Exception{

	private static final long serialVersionUID = -8734561231312057951L;

	/**
	 * 
	 */
	public EmployeeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public EmployeeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}

/**
 * 
 */
package com.capgemini.trainee.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.trainee.Trainee;
import com.capgemini.trainee.exception.TraineeException;

/**
 * @author Smita
 *
 */
public interface ITraineeService {
	public int addTrainee(Trainee trainee)throws TraineeException;//C
	public Trainee searchTrainee(int traineeId) throws TraineeException;
	//Retrieve return Object	
	public List<Trainee> listAllTrainee()throws TraineeException;
	//Retrieve -all returns arrays	
	public int updateTrainee(Trainee trainee)throws TraineeException;//U
	public int removeTrainee(int traineeId)throws TraineeException;//U
/*Validation services for following inputs
 ---validation service method return boolean value to clientCode
 ---then clientCode decides and provide output to the user
 */	public boolean validateId(int id)throws TraineeException;
	public boolean validateName(String input)throws TraineeException;
	public boolean validatePhoneNo(long phoneNo)throws TraineeException;
	public boolean validateEmail(String input)throws TraineeException;
	public boolean validateDate(String dob)throws TraineeException;
	public boolean validateFname(String input)throws TraineeException;
}







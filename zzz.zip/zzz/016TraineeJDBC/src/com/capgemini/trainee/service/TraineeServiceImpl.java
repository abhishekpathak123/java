/**
 * 
 */
package com.capgemini.trainee.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.trainee.Trainee;
import com.capgemini.trainee.dao.ITraineeDao;
import com.capgemini.trainee.dao.TraineeDaoImpl;
import com.capgemini.trainee.exception.TraineeException;

/**
 * @author Smita
 *
 */
public class TraineeServiceImpl implements ITraineeService {
	private static ITraineeDao traineeDao;
	static {
		traineeDao = new TraineeDaoImpl();
	}

	@Override
	public int addTrainee(Trainee trainee) throws TraineeException {
		return traineeDao.addTrainee(trainee);
	}

	@Override
	public Trainee searchTrainee(int traineeId) throws TraineeException {
		return traineeDao.searchTrainee(traineeId);
	}

	@Override
	public List<Trainee> listAllTrainee() throws TraineeException {
		return traineeDao.listAllTrainee();
	}

	@Override
	public int updateTrainee(Trainee trainee) throws TraineeException {
		return traineeDao.updateTrainee(trainee);
	}

	@Override
	public int removeTrainee(int traineeId) throws TraineeException {
		int status = traineeDao.removeTrainee(traineeId);
		return status;
	}

	// Validation Services Implementations
	// /which validates input and
	// /returns boolean value to the clientCode
	@Override
	public boolean validateId(int id) throws TraineeException {
		// converting int to String inorder to perform regex validation
		String input = String.valueOf(id);

		// creating regex pattern String
		String patternStr = "^[0-9]{4}$";// only 4 digits
		// Now create Pattern object.

		Pattern pattern = Pattern.compile(patternStr);
		// Now create matcher object.
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
		//return input.matches(patternStr);
		// or
		//return Pattern.matches(patternStr, input);
	}

	@Override
	public boolean validateName(String input) throws TraineeException {
		// creating regex pattern String
		String patternStr = "^[A-Z][a-z]{2,20}$";
		// 3-20 char, first letter must be in caps
		
		// Now create Pattern object.
		Pattern pattern = Pattern.compile(patternStr);
		// Now create matcher object.
		Matcher matcher = pattern.matcher(input);
		//now matcher matches
		return matcher.matches();
	}

	@Override
	public boolean validatePhoneNo(long phoneNo) throws TraineeException {
		// converting long to String inorder to perform regex validation
		String input = String.valueOf(phoneNo);
		// creating regex pattern String
		String patternStr = "^[789][0-9]{9}$";
		// 10 digits phone number
		// 1st number must start with 7 or 8 or 9
		// followed by 9 digits
		// Now create matcher object.

		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}

	@Override
	public boolean validateEmail(String input) throws TraineeException {
		// creating regex pattern String
		String patternStr = 
				"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		// must be in proper email format
		// Now create matcher object.

		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}

	/*
	 * ^ #start of the line [_A-Za-z0-9-\\+]+ # must start with string in the
	 * bracket [ ], must contains one or more (+) ( # start of group #1
	 * \\.[_A-Za-z0-9-]+ # follow by a dot "." and string in the bracket [ ],
	 * must contains one or more (+) )* # end of group #1, this group is
	 * optional (*)
	 * 
	 * @ # must contains a "@" symbol [A-Za-z0-9-]+ # follow by string in the
	 * bracket [ ], must contains one or more (+) ( # start of group #2 - first
	 * level TLD checking \\.[A-Za-z0-9]+ # follow by a dot "." and string in
	 * the bracket [ ], must contains one or more (+) )* # end of group #2, this
	 * group is optional (*) ( # start of group #3 - second level TLD checking
	 * \\.[A-Za-z]{2,} # follow by a dot "." and string in the bracket [ ], with
	 * minimum length of 2 ) # end of group #3 $ #end of the line
	 */

	@Override
	public boolean validateDate(String dob) {
		// System.out.println("validateDob() service invoked....");
		// to validate enter Date in (DD/MM/YYYY), with a year between 1900 and
		// 2099:
		String dobRegex = "(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)";
		// formatting String dob to LocalDate
		DateTimeFormatter formatter = 
				DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate enteredDate = LocalDate.parse(dob, formatter);
		// student should be min 21 years
		LocalDate today = LocalDate.now();
		LocalDate expectedDate = today.minusYears(20);
		Pattern dobPatter = Pattern.compile(dobRegex);
		Matcher dobMatcher = dobPatter.matcher(dob);
		if (dobMatcher.matches()) {
			if (enteredDate.isBefore(expectedDate)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	@Override
	public boolean validateFname(String input) throws TraineeException {
		// creating regex pattern String
				String patternStr = "^[A-Z][a-z]{2,20}$";
				// 3-20 char, first letter must be in caps
				
				// Now create Pattern object.
				Pattern pattern = Pattern.compile(patternStr);
				// Now create matcher object.
				Matcher matcher = pattern.matcher(input);
				//now matcher matches
				return matcher.matches();
		
	}

}

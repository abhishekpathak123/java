/**
 * 
 */
package com.capgemini.trainee.exception;

/**
 * @author Smita
 *
 */
public class TraineeException extends Exception {
	private static final long serialVersionUID = 1500769338737047135L;

	/**
	 * 
	 */
	public TraineeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public TraineeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

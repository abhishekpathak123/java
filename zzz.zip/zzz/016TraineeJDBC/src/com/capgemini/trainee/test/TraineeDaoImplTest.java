/**
 * 
 */
package com.capgemini.trainee.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.trainee.Trainee;
import com.capgemini.trainee.dao.TraineeDaoImpl;
import com.capgemini.trainee.exception.TraineeException;

/**
 * @author Smita
 *
 */
public class TraineeDaoImplTest {
	 TraineeDaoImpl traineeDao;	
	@Before
	public  void testEmpDaoImpl(){
		traineeDao= new TraineeDaoImpl();
	}
	@Test
	public void testAddTrainee1() throws TraineeException {
		int empId=traineeDao
				.addTrainee(
						new Trainee(11,"Smita", "B Kumar", 
								9876543212L, "smi@cg.com", 
								LocalDate.of(1996, 11, 11), 
								LocalDate.now()));
		System.out.println("Unique Id : "+empId);
		assertNotEquals(0, empId);
		
	}
	
	@Test
	public void testAddTrainee2() throws TraineeException {
		int empId=traineeDao.addTrainee(new Trainee(112,"Sia", "Kate", 
				9855543222L, "sia@cg.com", 
				LocalDate.of(1995, 12, 11), 
				LocalDate.now()));
		System.out.println("Unique Id : "+empId);
		assertTrue(empId>0);		
	}
	@Test
	public void testListTrainee1() throws TraineeException {
		List<Trainee> empList=traineeDao.listAllTrainee();
		assertNotNull("Trainee List Not Found",
				empList);
		for(Trainee emp:empList)
			System.out.println(emp);
		
	}
	@Test
	public void testListTrainee2() throws TraineeException {
		List<Trainee> empList=traineeDao.listAllTrainee();
		assertTrue("Trainee List Not Found",
				empList!=null);
		for(Trainee emp:empList)
			System.out.println(emp);
		
	}
	@Ignore
	@Test
	public void testDeleteTrainee1() throws TraineeException {
		int result=traineeDao.removeTrainee(111);
		System.out.println("No of Trainee deleted : "+result);
		assertTrue(result>0);		
	}
	@Ignore
	@Test
	public void testDeleteTrainee2() throws TraineeException {
		int result=traineeDao.removeTrainee(111);
		System.out.println("No of Trainee deleted : "+result);
		assertTrue(result>0);		
	}
	@Test
	public void testUpdateTrainee1() throws TraineeException {
		int result=traineeDao.updateTrainee(new Trainee(1001,"Smita", "Kumar", 
				9876543212L, "smita@cg.com", 
				LocalDate.of(1996, 11, 11), 
				LocalDate.now()));
		System.out.println(result+"...Trainee Updated : ");
		assertTrue(result>0);		
	}
	@Test
	public void testUpdateTrainee2() throws TraineeException {
		int result=traineeDao.updateTrainee(new Trainee(1001,"Raj", "Kumar", 
				9876543212L, "raj@cg.com", 
				LocalDate.of(1996, 11, 11), 
				LocalDate.now()));
		System.out.println(result+"...Trainee Updated : ");
		assertEquals(1,result);		
	}
	@Test
	public void testSearchTrainee1() throws TraineeException {
		Trainee emp=traineeDao.searchTrainee(1000);
		assertNotNull("Trainee  Not Found",
				emp);		
		System.out.println("Trainee Record Found....."+emp);		
	}
	@Test
	public void testSearchTrainee2() throws TraineeException {
		Trainee emp=traineeDao.searchTrainee(1001);
		assertTrue("Trainee  Not Found",
				emp!=null);		
		System.out.println("Trainee Record Found....."+emp);		
	}
}

//step 1 :one package declaration
package com.capgemini.trainee;

import java.time.LocalDate;
/*
  CREATE SEQUENCE trainee_seq;
  CREATE TABLE trainee
  (trainee_id NUMBER,
  first_name VARCHAR2(30),
  last_name VARCHAR2(30),
  phone_no NUMBER(10),
  email VARCHAR2(100),
  dob DATE,
  doj DATE,
  CONSTRAINT pk_t_id PRIMARY KEY(trainee_id));
 */
//step 2 :none or many import statements
/**
 * @author Smita
 *
 */
// step 3 :public class
public class Trainee{
	// step 4 :private instance variables
	private int traineeId;
	private String firstName;
	private String lastName;
	private long phoneNo;
	private String email;
	private LocalDate dob; // has -a relationShip/containment
	// object of other class as memeber of our class
	private LocalDate doj;
	
	// step 9 :No_args Constructor
	public Trainee() {
	
	}

	// step 10 :Overloaded Constructor
	/**
	 * @param firstName
	 * @param lastName
	 * @param phoneNo
	 * @param email
	 * @param dob
	 */
	public Trainee(int traineeId,String firstName, String lastName, long phoneNo,
			String email, LocalDate dob, LocalDate doj) {

		this.traineeId=traineeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNo = phoneNo;
		this.email = email;
		this.dob = dob;
		this.doj = doj;
	}

	// step 11 :generate toSTring

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", phoneNo=" + phoneNo
				+ ", email=" + email + ", dob=" + dob + ", doj=" + doj + "]";
	}

	// step 12 :getters & setters
	// in order to access private data outsidethe class
	/**
	 * @return the traineeId
	 */
	public int getTraineeId() {
		return traineeId;
	}

	/**
	 * @param traineeId
	 *            the traineeId to set
	 */
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the phoneNo
	 */
	public long getPhoneNo() {
		return phoneNo;
	}

	/**
	 * @param phoneNo
	 *            the phoneNo to set
	 */
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the dob
	 */
	public LocalDate getDob() {
		return dob;
	}

	/**
	 * @param dob
	 *            the dob to set
	 */
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	
	/**
	 * @return the doj
	 */
	public LocalDate getDoj() {
		return doj;
	}

	/**
	 * @param doj the doj to set
	 */
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}
	public void print() {
		System.out.println("\n________________________________________"
				+ "\n	Trainee Details					"
				+ "\n________________________________________"
				+ "\n	Trainee Id 	        : " + traineeId
				+ "\n	Trainee FirstName	: " + firstName
				+ "\n	Trainee lastName	: " + lastName
				+ "\n	Trainee DOB	        : " + dob
				+ "\n	Trainee DOJ	        : " + doj
				+ "\n________________________________________");
	}

}

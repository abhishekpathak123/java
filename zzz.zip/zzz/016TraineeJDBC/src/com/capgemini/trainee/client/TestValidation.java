package com.capgemini.trainee.client;

import java.util.Scanner;

import com.capgemini.trainee.Trainee;
import com.capgemini.trainee.exception.TraineeException;
import com.capgemini.trainee.service.ITraineeService;
import com.capgemini.trainee.service.TraineeServiceImpl;

public class TestValidation {
	// 1
	static Scanner sc = new Scanner(System.in);
	// 2
	static ITraineeService traineeService = new TraineeServiceImpl();

	public static void main(String[] args) {
		// 3
		Trainee trainee = new Trainee();
		String firstName = sc.next();
		try {
			while (true) {
				if (traineeService.validateName(firstName)) {
					trainee.setFirstName(firstName);
					break;
		} else {
			System.err.println(
					"******Please Enter Trainee FirstName:"
					+ "(Must be 3-20 Characters only "
					+ "and 1st Letter UpperCase! ex:Smita**********");
			firstName = sc.next();
		}
			}// end of while
		} catch (TraineeException e) {
			System.out.println(e.getMessage());
		}

	}

}

package com.capgemini.trainee.client;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.trainee.Trainee;
import com.capgemini.trainee.dao.TraineeDaoImpl;
import com.capgemini.trainee.exception.TraineeException;
import com.capgemini.trainee.service.ITraineeService;
import com.capgemini.trainee.service.TraineeServiceImpl;

/**
 * @author Smita
 *
 */
public class TraineeClient {
	private static ITraineeService traineeService;
	private static Scanner sc;
	private static Trainee trainee = new Trainee();
	private static Logger myLogger = null;
	// step 2 :static blog for logger code
	static {
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(TraineeClient.class.getName());
		sc = new Scanner(System.in);
		traineeService = new TraineeServiceImpl();
	}

	public static void main(String[] args) {
		int option = 0;
		try {
			// crud
			do {
				option = showMenu(option);
				switch (option) {
				case 1:
					acceptTraineeDetails();
					break;
				case 2:
					listAllTrainee();
					break;
				case 3:
					searchTrainee();
					break;
				case 4:
					updateTrainee();
					break;
				case 5:
					removeTrainee();
					break;
				case 6:
					exitTrainee();
					break;
				default:
					System.out.println("Wrong option entered"
							+ "\n kindly enter choice (1-6) only");
					break;
				}
			} while (true);
		} catch (TraineeException e) {
			myLogger.error("Something went wrong at client code..."
					+ e.getMessage());
			System.out.println("Something went wrong at client code..."
					+ e.getMessage());
		} catch (InputMismatchException e) {
			myLogger.error("Input should be only Numbers ");
			System.out.println("Input should be only Numbers ");
		}
	}// end of main
		// -showing main menu to opt choice from the user

	private static int showMenu(int option) throws TraineeException {
		System.out.println("\n_____________________________________\n"
				+ "\nTrainee Apllication\n"
				+ "\n_____________________________________\n"

				+ "\nEnter your Choice (1-6)\n" 
				+ "\n 1. Add Trainee Details"
				+ "\n 2. Display All Trainee Details"
				+ "\n 3. Search Trainee Details"
				+ "\n 4. Update Trainee Details"
				+ "\n 5. Remove Trainee Details" + "\n 6. Exit"
				+ "\n_____________________________________\n");
		option = sc.nextInt();

		return option;
	}

	// - exit from the application
	private static void exitTrainee() {
		myLogger.info("Ending Application at "+LocalDateTime.now());
		System.out.println("Thankyou for using Trainee App"
				+ "    Do Visit Again!!!");
		sc.close();
		System.exit(0);
	}

	private static void removeTrainee() {
		int traineeId = 0;
		try {
			// accept trainee id to be deleted
			System.out.println("Enter Trainee Id to be deleted");
			traineeId = sc.nextInt();
			while (true) {
				if (traineeService.validateId(traineeId)) {
					// trainee.setTraineeId(traineeId);
					break;
				} else {
					System.err
							.println("**********Please Enter Correct Trainee Id:"
									+ "(Must be 4 digits only)**********");
					traineeId = sc.nextInt();
				}
			}// end of while
			int status = traineeService.removeTrainee(traineeId);
			if (status == 1) {
				myLogger.info("Trainee Removed!!");
				System.out.println("Trainee Removed!!");
			} else {
				myLogger.error("Trainee NOT Removed!!");
				System.err.println("Trainee NOT Removed!!");
			}

		} catch (TraineeException e) {
			myLogger.error("Something went wrong..."
					+ "while Removing Record..." + e.getMessage());
			System.out.println("Something went wrong..."
					+ "while Removing Record..." + e.getMessage());
		}

	}

	private static void updateTrainee() {
		int traineeId = 0;
		try {
			// accept trainee id to be Updated
			System.out.println("Enter Trainee Id to be Updated");
			traineeId = sc.nextInt();
			while (true) {
				if (traineeService.validateId(traineeId)) {
					// trainee.setTraineeId(traineeId);
					break;
				} else {
					System.err
							.println("**********Please Enter  Correct  Trainee Id:"
									+ "(Must be 4 digits only)**********");
					traineeId = sc.nextInt();
				}
			}// end of while
				// search the trainee weather it exists or not
			trainee = traineeService.searchTrainee(traineeId);
			// remove the trainee if it is not null
			if (trainee != null) {
				// accept all the trainee details to be updated
				trainee.setLastName("Raje");
				trainee.setEmail("Raje@gmail.com");
				int status = traineeService.updateTrainee(trainee);
				if (status == 1) {
					myLogger.info("Trainee Updated!!");
					System.out.println("Trainee Updated successfully!!");
				} else {
					myLogger.error("Trainee NOT Updated!!");
					System.err.println("Trainee NOT Updated!!");
				}
			} else {
				System.out.println("Trainee Does Not exists!!");
			}
		} catch (TraineeException e) {
			myLogger.error("Something went wrong..."
					+ "while Updating Record..." + e.getMessage());
			
			System.out.println("Something went wrong..."
					+ "while Updating Record..." + e.getMessage());
		}
	}

	// - accepting input for Searching The Trainee
	private static void searchTrainee() {
		int traineeId = 0;
		try {
			// accept trainee id to be Searched
			System.out.println("Enter Trainee Id to be Searched");
			traineeId = sc.nextInt();
			while (true) {
				if (traineeService.validateId(traineeId)) {
					// trainee.setTraineeId(traineeId);
					break;
				} else {
					System.err
							.println("**********Please Enter  Correct Trainee Id:"
									+ "(Must be 4 digits only)**********");
					traineeId = sc.nextInt();
				}
			}// end of while
				// search the trainee weather it exists or not
			trainee = traineeService.searchTrainee(traineeId);
			// remove the trainee if it is not null
			if (trainee != null) {
				trainee.print();
			} else {
				myLogger.error("Trainee Not Exists!!");
				System.err.println("Trainee Does Not exists!!");
			}
		} catch (TraineeException e) {
			myLogger.error("Something went wrong..."
					+ "while Searching Record..." + e.getMessage());
			
			
			System.out.println("Something went wrong..."
					+ "while Searching Record..." + e.getMessage());
		}
	}

	private static void listAllTrainee() {
		List<Trainee> traineeList = null;
		try {
			traineeList = traineeService.listAllTrainee();
			if (traineeList != null) {
				for (Trainee trainee : traineeList)
					System.out.println(trainee);
			} else {
				myLogger.error("Record Not found !!");
				System.out.println("Something went wrong..."
						+ "while Fetching all Record...");

				/*
				 * throw new TraineeException("Something went wrong..." +
				 * "while Fetching all Record...");
				 */
			}
		} catch (TraineeException e) {
			myLogger.info("Something went wrong..."
					+ "while Fetching all Record..." + e.getMessage());
			System.out.println("Something went wrong..."
					+ "while Fetching all Record..." + e.getMessage());
		}
	}

	private static void acceptTraineeDetails() throws TraineeException {
		System.out
				.println("Enter Trainee FirstName :"
						+ "(Must be 3-20 Characters only and 1st Letter UpperCase! ex:Smita");
		String firstName = sc.next();
		while (true) {
			if (traineeService.validateName(firstName)) {
				trainee.setFirstName(firstName);
				break;
			} else {
				System.err
						.println("**********Please Enter Trainee FirstName:"
								+ "(Must be 3-20 Characters only and 1st Letter UpperCase! ex:Smita**********");
				firstName = sc.next();
			}
		}// end of while

		System.out
				.println("Enter Trainee LastName :"
						+ "(Must be 3-20 Characters only and 1st Letter UpperCase! ex:Smita");
		String lastName = sc.next();
		while (true) {
			if (traineeService.validateName(lastName)) {
				trainee.setLastName(lastName);
				break;
			} else {
				System.err
						.println("**********Please Enter Correct Trainee LastName:"
								+ "(Must be 3-20 Characters only and 1st Letter UpperCase! ex:Smita**********");
				lastName = sc.next();
			}
		}// end of while
		System.out.println("Enter Trainee Email :"
				+ "Enter the correct email format");
		String email = sc.next();
		while (true) {
			if (traineeService.validateEmail(email)) {
				trainee.setEmail(email);
				break;
			} else {
				System.err
						.println("**********Please Enter Correct Email: ex:Smita@gmail.com**********");
				email = sc.next();
			}
		}// end of while
		System.out.println("Enter Trainee Phone :" + "Only 10 digits "
				+ "First digit can be 7 or 8 or 9");
		long phoneNo = sc.nextLong();
		while (true) {
			if (traineeService.validatePhoneNo(phoneNo)) {
				trainee.setPhoneNo(phoneNo);
				break;
			} else {
				System.err
						.println("**********Please Enter Correct Phone Number"
								+ "Only 10 digits "
								+ "First digit can be 7 or 8 or 9"
								+ ": ex:9876543212**********");
				phoneNo = sc.nextLong();
			}
		}// end of while
	// accept Student DOB
		System.out.println("Enter Date of Birth(dd/MM/yyyy) :"
				+ "(Trainee should be minium 21 years old)");
		String dob = sc.next();
		while (true) {
			if (traineeService.validateDate(dob)) {
				// converting String dob to localDate dob
				DateTimeFormatter formatter = DateTimeFormatter
						.ofPattern("dd/MM/yyyy");
				// Almost every class in java.time package provides parse()
				// method to parse the com.capgemini.ch5.date or time
				LocalDate localDob = LocalDate.parse(dob, formatter);
				// setting dob of the student object
				trainee.setDob(localDob);
				System.out.println("DOB : at client :"+localDob);
				break;
			} else {
				System.err
						.println("**********Please Enter Correct Date of Birth:"
								+ " Date of Birth Must be in (dd/MM/yyyy) format "
								+ " and (Trainee should be minium 21 years old) **********");
				dob = sc.next();
			}			
		}// end of while // doB

		LocalDate doj = LocalDate.now(); // setting the value of dob
		trainee.setDoj(doj); // LocalDate dob = LocalDate.of(1999, 11, 11);
	
		/*
		 * trainee = new Trainee("Rahul", "Kher", 981234560l, "z@gh.com",
		 * LocalDate.of(1999, 11, 11), LocalDate.now());
		 */
		int id = traineeService.addTrainee(trainee);
		// Status is 1 then trainee added
		if (id > 0) {
			myLogger.info("trainee Addedd  successfully"
					+ "\n ******Unique Trainee Id : " + id + " *********");
		
			System.out.println("trainee Addedd  successfully"
					+ "\n ******Unique Trainee Id : " + id + " *********");
		} else {
			myLogger.error("Trainee Does Not added!!");
			System.err.println("Trainee Does Not added!!");
		}
	}
}

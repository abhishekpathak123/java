/**
 * 
 */
package com.capgemini.trainee.dao;

import java.util.List;

import com.capgemini.trainee.Trainee;
import com.capgemini.trainee.exception.TraineeException;

/**
 * @author Smita
 *
 */
public interface ITraineeDao {
	/*
	 * C- Create (add/insert) R- Retrieve (search or List i.e. get ,getAll) U-
	 * Update (modify/edit) D- Delete (remove)
	 */
	public int addTrainee(Trainee trainee) throws TraineeException;// C

	public Trainee searchTrainee(int traineeId) throws TraineeException;

	// Retrieve return Object

	public List<Trainee> listAllTrainee() throws TraineeException;

	// Retrieve -all returns arrays

	public int updateTrainee(Trainee trainee) throws TraineeException;// U

	public int removeTrainee(int traineeId) throws TraineeException;// U
	//dao	//fetch the generated traineeId from the sequence
		public int getUniqueTraineeId()
				throws TraineeException;
}

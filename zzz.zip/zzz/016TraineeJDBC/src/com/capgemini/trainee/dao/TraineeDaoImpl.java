/**
 * 
 */
package com.capgemini.trainee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.trainee.Trainee;
import com.capgemini.trainee.exception.TraineeException;
import com.capgemini.trainee.util.DBUtil;

/**
 * @author Smita
 *
 */
public class TraineeDaoImpl implements ITraineeDao {
	// step 1 :declare Connection and Logger variables
	private Connection connection;
	private static Logger myLogger = null;
	// step 2 :static blog for logger code
	static {
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(TraineeDaoImpl.class.getName());
	}

	// step 3 : obtain connection in the constructor
	public TraineeDaoImpl() {
		try {
			connection = new DBUtil().obtainConnection();
			myLogger.info("Connection Obtained ... at DAO");
		} catch (TraineeException e) {
			myLogger.error("ERROR : " + e);
			System.err.println(e.getMessage());
		}
	}

	// step 4 : override methods

	@Override
	public int addTrainee(Trainee trainee) throws TraineeException {
		myLogger.info("addTrainee() invoked in TraineeDaoImpl!!");
		System.out.println("Adding Trainee record.... Kindly have patience!!");
		String sql = "insert into trainee values(trainee_seq.NEXTVAL,?,?,?,?,?,SYSDATE)";
		PreparedStatement pst = null;
		int result = 0;
		int traineeId = 0;
		try {// obtain ps
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);// transaction starts

			// set the values for place hodlers
			pst.setString(1, trainee.getFirstName());
			pst.setString(2, trainee.getLastName());
			pst.setLong(3, trainee.getPhoneNo());
			pst.setString(4, trainee.getEmail());
			// convert LocalDate to Sql Date
			pst.setDate(5, java.sql.Date.valueOf(trainee.getDob()));
			
			// execute DML query
			result = pst.executeUpdate();
			traineeId = getUniqueTraineeId();
			// set the traineeId of the current trainee object
			trainee.setTraineeId(traineeId);
			myLogger.info("Trainee details getting inserted "
					+ "....unique traineeId : " + traineeId);

			connection.commit();// if insert successful the commit the
								// transaction
		} catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Inserting Trainee failed  "
					+ e.getMessage());
			throw new TraineeException("ERRROR :  Inserting Trainee failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Inserting Trainee failed "
						+ e.getMessage());
				throw new TraineeException(
						"ERRROR : Inserting Trainee failed " + e.getMessage());
			}
		}
		return traineeId;
	}

	@Override
	public Trainee searchTrainee(int traineeId) throws TraineeException {
		myLogger.info("searchTrainee() in TraineeDaoImpl invoked!!");
		String sql = "SELECT * FROM trainee WHERE trainee_id=?";
		Trainee trainee = null;
		PreparedStatement pst = null;
		try {
			// obtaining pst
			pst = connection.prepareStatement(sql);
			pst.setInt(1, traineeId);// setting the traineeId
			ResultSet rs = pst.executeQuery();// executing the sql
			if (rs.next()) {
				myLogger.info("Stduent record found ");
				// create the object of trainee
				trainee = new Trainee();
				// mapping the value from db to trainee object
				trainee.setTraineeId(rs.getInt(1));
				trainee.setFirstName(rs.getString(2));
				trainee.setLastName(rs.getString(3));
				trainee.setPhoneNo(rs.getLong(4));
				trainee.setEmail(rs.getString(5));				
				java.sql.Date sqlDate= rs.getDate(6);
				trainee.setDob(sqlDate.toLocalDate());
				sqlDate= rs.getDate(7);
				trainee.setDoj(sqlDate.toLocalDate());
				// convert sql date to LocalDate
				// java.sql.Date sqlDate= rs.getDate(4);//getting sql
				// date
				// LocalDate dob=sqlDate.toLocalDate();//convert sql date to
				// LocalDate

			} else {
				myLogger.error("ERRROR " + "TraineeId does Not Exits");
				throw new TraineeException("TraineeId does Not Exits , ");
			}
		} catch (SQLException e) {
			myLogger.error("ERRROR " + "Searching Trainee details failed "
					+ e.getMessage());
			throw new TraineeException("Searching Trainee details failed "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ERRROR " + "Searching Trainee details failed "
						+ e.getMessage());
				throw new TraineeException(
						"Searching Trainee details failed " + e.getMessage());
			}
		}
		return trainee;// returning trainee
	}

	@Override
	public List<Trainee> listAllTrainee() throws TraineeException {
		ArrayList<Trainee> traineeList = null;
		Statement st = null;
		ResultSet rs = null;
		Trainee trainee = null;
		String sql = "select * from trainee";
		try {
			// obtain st
			st = connection.createStatement();
			rs = st.executeQuery(sql);
			traineeList = new ArrayList<>();
			while (rs.next()) {
				trainee = new Trainee();
				// fetch the column data
				// and set to the trainee object
				trainee.setTraineeId(rs.getInt(1));
				trainee.setFirstName(rs.getString(2));
				trainee.setLastName(rs.getString(3));
				trainee.setPhoneNo(rs.getLong(4));
				trainee.setEmail(rs.getString(5));
				java.sql.Date sqlDate= rs.getDate(6);
				trainee.setDoj(sqlDate.toLocalDate());
				sqlDate= rs.getDate(7);
				trainee.setDob(sqlDate.toLocalDate());
				// add the trainee object to the list
				traineeList.add(trainee);
			}
		} catch (SQLException e) {
			myLogger.error("TraineeList not found , error occured : "
					+ e.getMessage());
			throw new TraineeException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("TraineeList not found , error occured :"
						+ e.getMessage());
				throw new TraineeException(e.getMessage());
			}
		}
		return traineeList;
	}

	@Override
	public int updateTrainee(Trainee trainee) throws TraineeException {
		myLogger.info("updateTrainee() invoked in TraineeDaoImpl!!");

		System.out
				.println("Updating Trainee record.... Kindly have patience!!");
		String sql = "update trainee set first_name=?,last_name=?,"
				+ "phone_no=?,email=?,dob=?" + "where trainee_id=?";
		PreparedStatement pst = null;
		int result = 0;
		try {// obtain ps
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);// transaction starts
			// getting the auto_generated id from the getNextCustId()
			int traineeId = trainee.getTraineeId();
			// set the values for place hodlers

			pst.setString(1, trainee.getFirstName());
			pst.setString(2, trainee.getLastName());
			pst.setLong(3, trainee.getPhoneNo());
			pst.setString(4, trainee.getEmail());
			// convert sql date to LocalDate
			/*
			 * java.sql.Date sqlDate= rs.getDate(5);//getting sql date LocalDate
			 * dob=sqlDate.toLocalDate();//convert sql date to LocalDate
			 */// convert LocalDate to Sql Date
			java.sql.Date sqlDate = java.sql.Date.valueOf(trainee.getDoj());
			pst.setDate(5, sqlDate);

			pst.setInt(6, traineeId);
			myLogger.info("Trainee details getting Updated ....");
			// execute DML query
			result = pst.executeUpdate();
			// now updating into Trainee table only if the first
			// insert is successful
			// getting the auto_generated id from the getNextTraineeId()
			myLogger.info("Trainee Id : " + traineeId + " ,updated");

			connection.commit();// if insert successful the commit the
								// transaction
		} catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Updating Trainee failed  "
					+ e.getMessage());

			throw new TraineeException("ERRROR :  Updating Trainee failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Updating Trainee failed "
						+ e.getMessage());
				throw new TraineeException("ERRROR : Updating Trainee failed "
						+ e.getMessage());
			}
		}
		return result;
	}

	@Override
	public int removeTrainee(int traineeId) throws TraineeException {
		myLogger.info("------------------Deleting Traineeloyee Records----------------");
		PreparedStatement ps = null;
		String sql = "delete from trainee where trainee_id=?";// '?'
		int noOfRec = 0; // placeholder
		try {
			// start the transaction boundary
			connection.setAutoCommit(false);
			// obatain ps object
			ps = connection.prepareStatement(sql);
			// prepare the pre-compiled statement
			// now we will set the dynamic(runtime) values of ps
			// placeholder-1
			ps.setInt(1, traineeId);
			// execute the insert query(DML)-executeUpdate()
			noOfRec = ps.executeUpdate();
			connection.commit();// transaction ends
		} catch (SQLException e) {
			throw new TraineeException("Issue in Deleting emp : " + e);
		} finally {
			if (ps != null)
				try {
					ps.close();
					connection.rollback();// if something wrong then rollback
				} catch (SQLException e) {
					throw new TraineeException(
							"Issue while closing resource, which are null");
				}
		}
		return noOfRec;
	}

	@Override
	public int getUniqueTraineeId() throws TraineeException {
		myLogger.info("Generating unique TraineeId");
		String sql = "SELECT trainee_seq.CURRVAL FROM dual";
		int traineeId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				traineeId = rs.getInt(1);
				myLogger.info("auto-generated TraineeId by sequence : "
						+ traineeId);
			} else {
				myLogger.error("TraineeId not auto generated , error occured ");
			}
		} catch (SQLException e) {
			myLogger.error("TraineeId not auto generated , error occured : "
					+ e.getMessage());
			throw new TraineeException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("TraineeId not auto generated , error occured :"
						+ e.getMessage());
				throw new TraineeException(e.getMessage());
			}
		}
		return traineeId;
	}

}

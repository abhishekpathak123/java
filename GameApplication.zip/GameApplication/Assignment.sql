Create table game
(
  game_Id number(2) primary key,
  name varchar(50),
  price number(5)
);

Create table users(
  user_Id number(5)primary key,
  name varchar2(25),
  balance number(5)
);
insert into users values(100,'Joy',300);

insert into users values(101,'Nitin',700);

insert into users values(102,'Bhavik',400);



Insert into game values(1,'Cricket',100);


Insert into game values(2,'WWE',200);


Insert into game values(3,'FootBall',500);
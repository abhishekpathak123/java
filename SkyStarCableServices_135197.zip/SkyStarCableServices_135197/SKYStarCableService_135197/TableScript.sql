
/*Creating Table SKYCustomers*/
Create table SKYCustomers (custNum varchar2(15) primary key, basePack varchar2(20), 
							optionalPack varchar2(20));
							
/* Inserting Records into the Table */
							
insert into SKYCustomers values('c001','Dhamal Hindi',null);

insert into SKYCustomers values('c002','South Magic',null);

insert into SKYCustomers values('c003','Dhamal Hindi','Kids');

insert into SKYCustomers values('c004','Dhamal Hindi','Music');

insert into SKYCustomers values('c005','Western Best','Music');

insert into SKYCustomers values('c006','Dhamal Hindi',null);

insert into SKYCustomers values('c007','Dhamal Hindi','Kids');
							
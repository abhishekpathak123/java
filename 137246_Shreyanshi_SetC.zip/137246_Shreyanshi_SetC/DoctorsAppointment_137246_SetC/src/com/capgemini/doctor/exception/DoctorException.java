/**
 * 
 */
package com.capgemini.doctor.exception;

/**
 * @author shreya
 *
 */
public class DoctorException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2387623461217490009L;

	public DoctorException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DoctorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

package com.capgemini.doctors.service;

import java.time.LocalDate;
import java.util.Date;

import com.capgemini.doctor.exception.DoctorException;
import com.capgemini.doctors.bean.DoctorAppointment;

public interface IDoctorAppointmentService {
	public int addDoctorAppointmentDetails(DoctorAppointment doctorappointment)
			throws DoctorException;
	public DoctorAppointment getAppointmentDetails (int appointmentId) 
			throws DoctorException;
	
	
	//validation service
	public boolean validateName(String name) throws DoctorException;
	public boolean validatePhoneNo(String input)throws DoctorException;
	public boolean validateEmail(String input)throws DoctorException;
	public boolean validateAge(int input)throws DoctorException;
	public boolean validateGender(String input) throws DoctorException;
	public boolean validateAppointmentDate(LocalDate date) throws DoctorException;
}

package com.capgemini.doctors.service;

import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.doctor.exception.DoctorException;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;

public class DoctorAppointmentService implements IDoctorAppointmentService {
	IDoctorAppointmentDao doctorDao = new DoctorAppointmentDao();
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorappointment)
			throws DoctorException {
		return doctorDao.addDoctorAppointmentDetails(doctorappointment);
		
	}

	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentId)
			throws DoctorException {
		
		return doctorDao.getAppointmentDetails(appointmentId);
	}

	@Override
	public boolean validateName(String name) throws DoctorException {
		Pattern namePattern = Pattern.compile("^[A-Z][A-Za-z]{3,20}$");
		Matcher nameMatcher = namePattern.matcher(name);
		if (!(nameMatcher.matches())) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public boolean validatePhoneNo(String input) throws DoctorException {
		String patternStr = "^[789][0-9]{9}$";
		// 10 digits phone number
		// 1st number must start with 7 or 8 or 9
		// followed by 9 digits
		// Now create matcher object.

		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}

	@Override
	public boolean validateEmail(String input) throws DoctorException {
		// creating regex pattern String
				String patternStr = 
						"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
				// must be in proper email format
				// Now create matcher object.

				Pattern pattern = Pattern.compile(patternStr);
				Matcher matcher = pattern.matcher(input);
				return matcher.matches();
	}

	@Override
	public boolean validateAge(int input) throws DoctorException {
		String str = String.valueOf(input);
		String patternStr = "^[0-9]{2}$";
		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(str);
		return matcher.matches();
	}

	@Override
	public boolean validateGender(String input) throws DoctorException {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,20}$");
		Matcher nameMatcher = namePattern.matcher(input);
		if (!(nameMatcher.matches())) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public boolean validateAppointmentDate(LocalDate date)
			throws DoctorException {
	
		if(date == LocalDate.now()){
			System.out.println("Appointment can be done only from tommorow");
		}
		
		return true;
	}

}

/**
 * 
 */
package com.capgemini.doctors.ui;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.doctor.exception.DoctorException;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;



/**
 * @author shreya
 *
 */
public class Client {
	private static IDoctorAppointmentService doctorService;
	private static Scanner sc;
	private static Logger myLogger = null;
	
	static{
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(Client.class.getName());
		sc = new Scanner(System.in);
		doctorService = new DoctorAppointmentService();
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int option = 0;
		try {
			// crud
			do {
				option = showMenu(option);
				switch (option) {
				case 1:addDoctorAppointment();
				break;
				case 2:getDoctorAppointmentDetails();
				break;
				case 3:exitApp();
				break;
				default:
					System.out.println("Wrong option entered"
							+ "\n kindly enter choice (1-3) only");
					break;
				}
			} while (true);
		}catch (DoctorException e) {
			myLogger.error("Something went wrong at client code..."
					+ e.getMessage());
			System.out.println("Something went wrong at client code..."
					+ e.getMessage());
		} catch (InputMismatchException e) {
			myLogger.error("Input should be only Numbers ");
			System.out.println("Input should be only Numbers ");
		}

	}
	private static int showMenu(int option) throws DoctorException{
		System.out.println(
				  "\n_________________________________________________________________________________\n"
				+ "\n	   Doctor Appointment Application\n"
				+ "\n_________________________________________________________________________________\n"

				+ "\n   Enter your Choice (1-3)\n" 
				+ "\n      1. Book Doctor Appointment"
				+ "\n      2. View Doctor Appointment"
				+ "\n      3. Exit" 
				+ "\n_________________________________________________________________________________\n");
		option = sc.nextInt();

		return option;
	}
	private static void addDoctorAppointment() throws DoctorException{
		int appointmentId = 0;
		DoctorAppointment doctorAppointment = new DoctorAppointment();
		System.out.print("Enter Name of the patient    :");
		String name = sc.next();
		while (true) {
			if (doctorService.validateName(name)) {
				break;
			} else {
				System.err
						.println("Name must be characters only with first letter Capital, Try Again");
				name = sc.next();
			}
		}
		System.out.print("Enter Phone No               :");
		String phone = sc.next();
		while (true) {
			if (doctorService.validatePhoneNo(phone)) {
				break;
			} else {
				System.err
						.println("Phone No must be only digits starting from 9 or 8 or 7 followed by 9 digitsn");
				phone = sc.next();
			}
		}
		System.out.print("Enter Email                  :");
		String email = sc.next();
		while (true) {
			if (doctorService.validateEmail(email)) {
				break;
			} else {
				System.err
						.println("Email should start with Capital for ex - Shreya@gmail.com");
				email = sc.next();
			}
		}
		System.out.print("Enter Age                    :");
		int age = sc.nextInt();
		while (true) {
			if (doctorService.validateAge(age)) {
				break;
			} else {
				System.err
						.println("Age should be of max 2 digits only");
				age = sc.nextInt();
			}
		}
		System.out.print("Enter Gender                 :");
		String gender = sc.next();
		while (true) {
			if (doctorService.validateGender(gender)) {
				break;
			} else {
				System.err
						.println("only characters allowed");
				gender = sc.next();
			}
		}
		System.out.print("Enter Problem Name           :");
		String probName = sc.next();
		
		try{
		doctorAppointment.setPatientName(name);
		doctorAppointment.setPhoneNum(phone);
		doctorAppointment.setAppointmentDate(LocalDate.of(2017, 10, 28));
		doctorAppointment.setEmail(email);
		doctorAppointment.setAge(age);
		doctorAppointment.setGender(gender);
		doctorAppointment.setProbName(probName);
		
		if(probName.equalsIgnoreCase("Heart")){
			doctorAppointment.setDocName("Dr. Brijesh Kumar");
			doctorAppointment.setStatus("Approved");
		}
		else if(probName.equalsIgnoreCase("Gynecology")){
			doctorAppointment.setDocName("Dr. Sharda Singh");
			doctorAppointment.setStatus("Approved");
		}
		else if(probName.equalsIgnoreCase("Diabetes")){
			doctorAppointment.setDocName("Dr. Heena Khan");
			doctorAppointment.setStatus("Approved");
		}
		else if(probName.equalsIgnoreCase("ENT")){
			doctorAppointment.setDocName("Dr. Paras mal");
			doctorAppointment.setStatus("Approved");
		}
		else if(probName.equalsIgnoreCase("Bone")){
			doctorAppointment.setDocName("Dr Renuka Kher");
			doctorAppointment.setStatus("Approved");
		}
		else if(probName.equalsIgnoreCase("Dermatology")){
			doctorAppointment.setDocName("Dr. Kanika Kapoor");
			doctorAppointment.setStatus("Approved");
		}
		
		appointmentId = doctorService.addDoctorAppointmentDetails(doctorAppointment);
		doctorAppointment.setAppointmentId(appointmentId);
		System.out.println("In client "+doctorAppointment);
		if(appointmentId > 0){
			System.out.println("Your Doctor Appointment has been successfully registered, your appointment ID is : "+appointmentId);
	}
		else 
		{
			System.err
			.println("\n=================================================================="
					+ "\n		Sorry !! Patient Detailes Not Added!!"
					+ "\n==================================================================");

		}
		
		}catch (DoctorException e) {
			
			System.out.println("Error");
		}
		
		
	}
	private static void getDoctorAppointmentDetails(){
		System.out.println("Enter Appointment Id to display order details");
		int id = sc.nextInt();
		try{
			DoctorAppointment doctorAppointment = doctorService.getAppointmentDetails(id);

			if (doctorAppointment != null) {
				doctorAppointment.print();
			} else {
				System.err
						.println("\n=================================================================="
								+ "\n		Sorry !! Customer Deatailes Not Added!!"
								+ "\n==================================================================");
			}
		}catch(DoctorException e){
			e.printStackTrace();
		}
		}
		
	
	private static void exitApp(){
		System.out
		.println(
				  "\n=================================================================="
				+ "\n		Thankyou for using Doctor Booking App"
				+ "\n             Do Visit Again!!!"
				+ "\n==================================================================");

		sc.close();
		System.exit(0);
	}
		
	}



package com.capgemini.doctors.test;
import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.doctor.exception.DoctorException;

/**
 * @author Smita
 *
 */
public class DBUtilTest {
	 static com.capgemini.doctors.util.DBUtil dbUtil ;
	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void testDBUtil() throws DoctorException{
		dbUtil= new com.capgemini.doctors.util.DBUtil();
		assertNotNull("DBUtil Object Not created..."
				,dbUtil);
	}
	@Test
	public void testConnection() throws DoctorException {
		Connection conn = dbUtil.obtainConnection();
		assertNotNull("Connection NOT obtained!",conn);
		if(conn!=null)System.out.println("connection Obtained ...."+conn);
	}

}

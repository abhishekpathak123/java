package com.capgemini.doctors.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.doctor.exception.DoctorException;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;

public class DoctorDaoTest {
	private static DoctorAppointmentDao doctorDao;
	DoctorAppointment doctorAppointment = new DoctorAppointment();
	@BeforeClass
	public static void createDaoObject() throws DoctorException {
		doctorDao = new DoctorAppointmentDao();
		assertNotNull(doctorDao);
	}
	@Test
	public void testAddDoctorAppointmentDetails1() throws DoctorException{
		try {
			DoctorAppointment doctorAppointment = new DoctorAppointment(1111, "Shreya", "9876543212",LocalDate.now(),"shreya@gmaiol.com",44,"female","Bone","Dr.Renuka Kher","Approved");
			
			int appointmentId = doctorDao.addDoctorAppointmentDetails(doctorAppointment);
			assertFalse("Appointment disapproved", appointmentId==0);
			if(appointmentId>0)System.out.println("Appointment Id is : "+appointmentId);
		} catch (Exception e) {
			throw new DoctorException(e.getMessage());
		}
	}
	@Test
	public void testAddDoctorAppointmentDetails2() throws DoctorException{
		try {
			DoctorAppointment doctorAppointment = new DoctorAppointment(1111, "Shreya", "9876543212",LocalDate.now(),"shreya@gmaiol.com",44,"female","Bone","Dr.Renuka Kher","Approved");
			
			int appointmentId = doctorDao.addDoctorAppointmentDetails(doctorAppointment);
			assertNotNull(appointmentId);
			if(appointmentId>0)System.out.println("Appointment Id is : "+appointmentId);
		} catch (Exception e) {
			throw new DoctorException(e.getMessage());
		}
	}

	@Test
	public void testGetAppointmentDetails1() {
	
			
			try {
				doctorDao.getAppointmentDetails(1111);
			} catch (DoctorException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			assertTrue("Appointment Found",
					doctorAppointment!= null);
		
			
		
	}
	@Test
	public void testGetAppointmentDetails2() {
	
			
			try {
				doctorDao.getAppointmentDetails(1111);
			} catch (DoctorException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			assertNotNull("Appointment NOT Found",
					doctorAppointment== null);
		
			
		
	}

}

/**
 * 
 */
package com.capgemini.doctors.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.doctor.exception.DoctorException;
import com.capgemini.doctors.bean.DoctorAppointment;

/**
 * @author shreya
 *
 */
public class DoctorAppointmentDao implements IDoctorAppointmentDao {
	private Connection connection;
	private static Logger myLogger = null;
	static{
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(DoctorAppointmentDao.class.getName());
	}
	public DoctorAppointmentDao() {
		try {
			connection = new com.capgemini.doctors.util.DBUtil().obtainConnection();
			myLogger.info("Connection Obtained ... at DAO");
		} catch (DoctorException e) {
			myLogger.error("ERROR : " + e);
			System.err.println(e.getMessage());
		}
	}
	/* (non-Javadoc)
	 * @see com.capgemini.doctors.dao.IDoctorAppointmentDao#addDoctorAppointmentDetails(com.capgemini.doctors.bean.DoctorAppointment)
	 */
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorappointment)
			throws DoctorException {
		String sql = "insert into doctor_appointment values(seq_appointment_id.NEXTVAL,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pst = null;
		
		int insertRec=0;
		int appointmentId = 0;
		try {
			
			/*connection.setAutoCommit(false);*/
			pst = connection.prepareStatement(sql);
			pst.setString(1, doctorappointment.getPatientName());
			pst.setString(2, doctorappointment.getPhoneNum());
			
			java.sql.Date sqldate = java.sql.Date.valueOf(doctorappointment.getAppointmentDate());
			pst.setDate(3, sqldate);
			pst.setString(4, doctorappointment.getEmail());
			pst.setInt(5, doctorappointment.getAge());
			pst.setString(6, doctorappointment.getGender());
			pst.setString(7, doctorappointment.getProbName());
			pst.setString(8, doctorappointment.getDocName());
			pst.setString(9, doctorappointment.getStatus());
			System.out.println(doctorappointment);
			insertRec = pst.executeUpdate();
			appointmentId = getUniqueAppointmentId();
			
			/*connection.commit();*/
		}catch(SQLException e){
			myLogger.error("ERRROR :  "
					+ "Inserting Patient Details failed  "
					+ e.getMessage());
			//e.printStackTrace();
			throw new DoctorException(
					"ERRROR :  Inserting  Patient Details failed  "
							+ e.getMessage());
		}finally {
			try {
				if (pst != null)
					pst.close();
				
				
			} catch (SQLException e) {
				myLogger.error("ERRROR :  "
						+ "Inserting  CustomerDetails failed "
						+ e.getMessage());
				throw new DoctorException(
						"ERRROR : Inserting  CustomerDetails failed "
								+ e.getMessage());
			}
		}
		return appointmentId;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.doctors.dao.IDoctorAppointmentDao#getAppointmentDetails(int)
	 */
	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentId)
			throws DoctorException {
		DoctorAppointment doctorAppointment = null;
		myLogger.info("------------------Displaying Appointment Details----------------");
		PreparedStatement ps = null;
		String sql = "select patient_name,appointment_status,doctor_name,date_of_appointment from doctor_appointment where appointment_id=?";
		ResultSet rs=null;
		try{
			ps = connection.prepareStatement(sql);
			ps.setInt(1, appointmentId);
			
			
			rs = ps.executeQuery();
			while(rs.next())
			{
				doctorAppointment = new DoctorAppointment();
				doctorAppointment.setPatientName(rs.getString("patient_name"));
				doctorAppointment.setStatus(rs.getString("appointment_status"));
				doctorAppointment.setDocName(rs.getString("doctor_name"));
				java.sql.Date sqlDate = rs.getDate("date_of_appointment");
				LocalDate appDate = sqlDate.toLocalDate();
				doctorAppointment.setAppointmentDate(appDate);
				

			}
		}
		catch (SQLException e) {
			throw new DoctorException("Issue in Deleting mobile : " + e);
		} finally {
			if (ps != null)
				try {
					ps.close();
					/*connection.rollback();*/// if something wrong then rollback
				} catch (SQLException e) {
					throw new DoctorException(
							"Issue while closing resource, which are null");
				}
		}
		return doctorAppointment;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.doctors.dao.IDoctorAppointmentDao#getUniqueAppointmentId()
	 */
	@Override
	public int getUniqueAppointmentId() throws DoctorException {
		myLogger.info("Generating unique AppointmentId");
		String sql = "SELECT seq_appointment_id.CURRVAL FROM dual";
		int appointmentId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				appointmentId = rs.getInt(1);
				myLogger.info("auto-generated Patient AppointmentId by sequence : "+ appointmentId);
			} else {
				myLogger.error("Patient AppointmentId not auto generated , error occured ");
			}
		} catch (SQLException e) {
			myLogger.error("Patient AppointmentId not auto generated , error occured : "
					+ e.getMessage());
			throw new DoctorException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("Patient AppointmentId not auto generated , error occured :"
						+ e.getMessage());
				throw new DoctorException(e.getMessage());
			}
		}
		return appointmentId;
	}

}

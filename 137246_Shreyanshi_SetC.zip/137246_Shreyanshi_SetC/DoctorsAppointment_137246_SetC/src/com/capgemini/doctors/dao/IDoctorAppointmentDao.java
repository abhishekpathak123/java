package com.capgemini.doctors.dao;

import com.capgemini.doctor.exception.DoctorException;
import com.capgemini.doctors.bean.DoctorAppointment;



public interface IDoctorAppointmentDao {
	public int addDoctorAppointmentDetails(DoctorAppointment doctorappointment)
			throws DoctorException;
	public DoctorAppointment getAppointmentDetails (int appointmentId) 
			throws DoctorException;
	
	
	
	//dao methods
	public int getUniqueAppointmentId()throws DoctorException;
}

/**
 * 
 */
package com.capgemini.doctors.bean;

import java.time.LocalDate;

/**
 * @author shreya
 *
 */
public class DoctorAppointment {
	private int appointmentId;
	private String patientName;
	private String phoneNum;
	private LocalDate appointmentDate;
	private String email;
	private int age;
	private String gender;
	private String probName;
	private String docName;
	private String status;
	
	public DoctorAppointment() {
		// TODO Auto-generated constructor stub
	}

	

	public int getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public LocalDate getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(LocalDate appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getProbName() {
		return probName;
	}

	public void setProbName(String probName) {
		this.probName = probName;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}



	@Override
	public String toString() {
		return "DoctorAppointment [appointmentId=" + appointmentId
				+ ", patientName=" + patientName + ", phoneNum=" + phoneNum
				+ ", appointmentDate=" + appointmentDate + ", email=" + email
				+ ", age=" + age + ", gender=" + gender + ", probName="
				+ probName + ", docName=" + docName + ", status=" + status
				+ "]";
	}



	public DoctorAppointment(int appointmentId, String patientName,
			String phoneNum, LocalDate appointmentDate, String email, int age,
			String gender, String probName, String docName, String status) {
		super();
		this.appointmentId = appointmentId;
		this.patientName = patientName;
		this.phoneNum = phoneNum;
		this.appointmentDate = appointmentDate;
		this.email = email;
		this.age = age;
		this.gender = gender;
		this.probName = probName;
		this.docName = docName;
		this.status = status;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public void print() {
		System.out.println("\n________________________________________"
				+ "\n	Appointment Details					"
				+ "\n________________________________________"
				+ "\n	Patient Name          : " + patientName
				+ "\n	Appointment Status    : " + status
				+ "\n	Doctor Name           : " + docName
				+ "\n	Appointment Date      : " + appointmentDate
				+ "\n________________________________________");
	}
}

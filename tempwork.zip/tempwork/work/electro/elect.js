  function valCheck(){
	  
              var chk=document.getElementById("M").value;
			  //alert("xxx");
			  x=parseInt(chk);
			  var y= x*500;
			  alert("The electricity bill is "+ y);
  }
  
package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.BillDetails;
import com.cg.bean.Consumers;
import com.cg.bean.Login;
import com.cg.service.BillService;
import com.cg.service.BillServiceImpl;

/**
 * Servlet implementation class BillController
 */
@WebServlet("/BillController")
public class BillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       BillService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BillController() {
        super();
       service = new BillServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		
		
			
			
			
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		HttpSession session = request.getSession(true);
		
		PrintWriter out = response.getWriter();
		if("Userinfo".equals(action))
		{
			session.setAttribute("conno", request.getParameter("conno"));
			session.setAttribute("lread", request.getParameter("lread"));
			session.setAttribute("curread", request.getParameter("curread"));
			
			    BillDetails bill = new BillDetails();
			    Consumers consumers = new Consumers();
				String no = (String)session.getAttribute("conno");
				int conno = Integer.parseInt(no);
				String lread = (String)session.getAttribute("lread");
				Double lastRead = Double.parseDouble(lread);
				String cread = (String)session.getAttribute("curread");
				Double curRead = Double.parseDouble(cread);
				
				
				bill = service.calculate(conno,lastRead,curRead);
				bill.setCurReading(curRead);
				bill.setConsumerNum(conno);
				boolean flag = service.insertBillDetails(bill);
				if(flag)
				{
					String name = service.getConsumerName(conno);
					consumers.setName(name);
					out.println("<html>");
					out.println("<body>");
					out.println("<h3>Welcome "+consumers.getName()+"</h3>");
					out.println("<h1>Electricity Bill for Consumer Number -"+conno+" is</h1>");
					out.println("<h3>Units Consumed ::"+bill.getUnitConsumed()+"</h3>");
					out.println("<h3>Net Amount ::"+bill.getAmount()+"</h3>");
					out.println("</body>");
					out.println("</html>");
				}
				else
				{
					out.println("Invalid Consumer No");
				
			}
				
		}
		if("login".equals(action)){
		Login bean = new Login();
		String user = request.getParameter("username");
		String passwd = request.getParameter("passwd");
		bean.setUsername(user);
		bean.setPassword(passwd);
		
		boolean flag = service.validate(bean);
		if(flag){
			response.sendRedirect("UserInfo.html");
			
		}
		else{
			out.println("fail to login");
		}
}}
}
package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bean.Employee;
import com.cg.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	Connection con;
	
	public EmployeeDaoImpl() {
		con = DBUtil.getConnect();
	}
	@Override
	public ArrayList<Employee> getEmployeeList() {
		ArrayList<Employee> list = new ArrayList<>();
		String sql ="SELECT * FROM employee";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				Employee obj = new Employee();
				obj.setEmpId(rs.getInt(1));
				obj.setEmpName(rs.getString(2));
				obj.setbDate(rs.getDate(3).toLocalDate());
				obj.setSalary(rs.getInt(4));
				list.add(obj);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public boolean updateSalary(int id, int salary) {
	
		String sql ="update employee set empSal=? where empId=?";
		boolean flag = false;
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, salary);
			pstmt.setInt(2, id);
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

}

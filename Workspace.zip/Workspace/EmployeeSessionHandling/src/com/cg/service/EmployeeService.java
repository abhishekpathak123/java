package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Employee;

public interface EmployeeService {

	public ArrayList<Employee> getEmployeeList();
	public boolean updateSalary(int id, int salary);
}

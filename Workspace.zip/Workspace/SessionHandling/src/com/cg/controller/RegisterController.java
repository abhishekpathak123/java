package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.Login;
import com.cg.service.RegisterService;
import com.cg.service.RegisterServiceImpl;

/**
 * Servlet implementation class RegisterController
 */
@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       RegisterService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterController() {
        super();
       service = new RegisterServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		HttpSession session = request.getSession(true);
		
		if("register".equals(action))
		{
			RequestDispatcher dispatch = request.getRequestDispatcher("Register.html");
			dispatch.forward(request, response);
		}
		PrintWriter out = response.getWriter();
		if("login".equals(action))
		{
			String contact = request.getParameter("contact");
				Login bean = (Login)session.getAttribute("success");
				if(bean.getContact().equals(contact))
				{
					out.println("welcome");
				}
		}
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		HttpSession session = request.getSession(false);
		Login bean = new Login();
		Login successBean = null;
		if("insertUser".equals(action))
		{
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String contact = request.getParameter("contact");
			bean.setUsername(username);
			bean.setPassword(password);
			bean.setContact(contact);
			successBean = service.registerUser(bean);
			session.setAttribute("success", successBean);
			PrintWriter out = response.getWriter();
			if(successBean != null){
			out.println("<html>");
			out.println("<body>");
			out.println("Welcome"+successBean.getUsername());
			out.println("<a href='RegisterController?action=login&contact="+successBean.getContact()+"'>"+"Login"+"</a>");
			out.println("</body></html>");
		}}
	}

}

package com.cg.service;

import com.cg.bean.Login;
import com.cg.dao.RegisterDao;
import com.cg.dao.RegisterDaoImpl;

public class RegisterServiceImpl implements RegisterService {
	RegisterDao dao;
	public RegisterServiceImpl() {
		dao = new RegisterDaoImpl();
	}
	@Override
	public boolean validate(Login bean) {
		
		return false;
	}

	@Override
	public Login registerUser(Login bean) {
		
		return null;
	}

}

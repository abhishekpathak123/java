package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.bean.Login;
import com.cg.util.DBUtil;

public class RegisterDaoImpl implements RegisterDao {
	Connection con;
	
	public RegisterDaoImpl() {
		con = DBUtil.getConnect();
	}
	
	@Override
	public boolean validate(Login bean) {
		boolean flag = false;
		String sql = "SELECT * FROM LoginDetails where contact=?";
		try{
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, bean.getContact());
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				flag=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public Login registerUser(Login bean) {
		String sql = "INSERT into LoginDetails values(?,?,?)";
		try{
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getUsername());
			pstmt.setString(2, bean.getPassword());
			pstmt.setString(3, bean.getContact());
			int row = pstmt.executeUpdate();
			if(row > 0){
				return bean;
			}
			else{
				bean = null;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return bean;
	}

}

package com.cg.dao;

import com.cg.bean.Login;

public interface RegisterDao {
	
	public boolean validate(Login bean);
	public Login registerUser(Login bean);
	
}

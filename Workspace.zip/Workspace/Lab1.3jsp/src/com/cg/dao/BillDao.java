package com.cg.dao;

import com.cg.bean.BillDetails;
import com.cg.bean.Login;

public interface BillDao {

	public boolean validate(Login bean);

	

	public boolean insertBillDetails(BillDetails bill);



	public String getConsumerName(int conno);
}

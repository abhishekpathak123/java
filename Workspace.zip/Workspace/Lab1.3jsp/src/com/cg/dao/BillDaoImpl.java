package com.cg.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import com.cg.bean.BillDetails;
import com.cg.bean.Login;
import com.cg.util.DBUtil;

public class BillDaoImpl implements BillDao {

	Connection con;
	public BillDaoImpl() {
		con = DBUtil.getConnect();
	}
	
	@Override
	public boolean validate(Login bean) {
		boolean flag = false;
		if("cg".equals(bean.getUsername())
				&&"cg".equals(bean.getPassword())){
			flag = true;
		}
		return flag;
	}

	@Override
	public boolean insertBillDetails(BillDetails bill) {
		String sql ="insert into billdetails values(seq_bill_num.nextval,?,?,?,?,?)";
		boolean flag = false;
		
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bill.getConsumerNum());
			pstmt.setDouble(2, bill.getCurReading());
			pstmt.setDouble(3, bill.getUnitConsumed());
			pstmt.setDouble(4, bill.getAmount());
			pstmt.setDate(5, Date.valueOf(LocalDate.now()));
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				flag = true;
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public String getConsumerName(int conno) {
		String sql = "select consumer_name from consumers where consumer_num=?";
		String name = null;
		
		ResultSet rs = null;
		try {
			
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, conno);
			 rs = pstmt.executeQuery();
			 System.out.println(rs);
			 if(rs.next()){
				 name = rs.getString("consumer_name");
				
			 }
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
	}

}

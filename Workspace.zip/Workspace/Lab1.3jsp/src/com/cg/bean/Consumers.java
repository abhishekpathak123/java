package com.cg.bean;

public class Consumers {

	int consumerNo;
	String Name;
	String address;
	public int getConsumerNo() {
		return consumerNo;
	}
	public void setConsumerNo(int consumerNo) {
		this.consumerNo = consumerNo;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Consumers [consumerNo=" + consumerNo + ", Name=" + Name
				+ ", address=" + address + "]";
	}
	
	
}

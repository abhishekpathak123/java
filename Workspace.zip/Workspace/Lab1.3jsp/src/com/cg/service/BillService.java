package com.cg.service;

import com.cg.bean.BillDetails;
import com.cg.bean.Login;

public interface BillService {

	public boolean validate(Login bean);

	public boolean insertBillDetails(BillDetails bill);

	public BillDetails calculate(int conno, Double lastRead, Double curRead);

	public String getConsumerName(int conno);

	

}

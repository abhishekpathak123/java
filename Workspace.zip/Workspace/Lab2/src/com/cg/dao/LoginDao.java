package com.cg.dao;

import com.cg.bean.LoginBean;

public interface LoginDao {

	public boolean validate(LoginBean bean);
}

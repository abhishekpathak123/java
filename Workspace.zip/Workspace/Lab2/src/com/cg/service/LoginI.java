package com.cg.service;

import com.cg.bean.LoginBean;

public interface LoginI {

	public boolean validate(LoginBean bean);
}

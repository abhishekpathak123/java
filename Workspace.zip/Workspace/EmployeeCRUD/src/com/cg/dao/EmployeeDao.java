package com.cg.dao;

import com.cg.bean.Employee;

public interface EmployeeDao {

	public boolean insertEmployee(Employee bean);
	public Employee getEmployeeById(int id);
	public boolean updateEmployee(Employee bean);
}

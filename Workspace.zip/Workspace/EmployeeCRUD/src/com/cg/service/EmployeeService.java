package com.cg.service;

import com.cg.bean.Employee;

public interface EmployeeService {
	public boolean insertEmployee(Employee bean);
	public Employee getEmployeeById(int id);
	
}

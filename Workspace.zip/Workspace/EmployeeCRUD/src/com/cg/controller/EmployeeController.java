package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Employee;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       EmployeeService service;
       
      
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeController() {
        super();
        service = new EmployeeServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		if("insertEmp".equals(action)){
			RequestDispatcher dispatch = request.getRequestDispatcher("acceptEmployee.html");
			dispatch.forward(request, response);
		}
		else if("SearchEmployee".equals(action))
		{
			RequestDispatcher dispatch = request.getRequestDispatcher("search.html");
			dispatch.forward(request, response);
		}
		else if("UpdateEmployee".equals(action))
		{
			RequestDispatcher dispatch = request.getRequestDispatcher("update.html");
			dispatch.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		if("insert".equals(action))
		{
			String empName = request.getParameter("empName");
			String salary = request.getParameter("empSal");
			String date = request.getParameter("bDate");
			Employee bean = new Employee();
			bean.setEmpName(empName);
			bean.setSalary(Integer.parseInt(salary));
			DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate bDate = LocalDate.parse(date, format);
			bean.setbDate(bDate);
			boolean flag = service.insertEmployee(bean);
			PrintWriter out = response.getWriter();
			if(flag){
				out.println("Inserted Successfully");
			}
			else
			{
				out.println("Insertion failed");
			}
		}
		else if("Search".equals(action))
		{
			String id = request.getParameter("empId");
			int empId = Integer.parseInt(id);
			Employee bean = new Employee();
			bean = service.getEmployeeById(empId);
			PrintWriter out = response.getWriter();
			if(bean != null){
				out.println(bean);
			}
			else{
				out.println("No such EmpId exists");
			}
		}
	}

}

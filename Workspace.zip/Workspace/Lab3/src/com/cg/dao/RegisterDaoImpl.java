package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.bean.RegisterBean;
import com.cg.util.DBUtil;

public class RegisterDaoImpl implements IRegistration {

	Connection con;
	public RegisterDaoImpl() {
		con = DBUtil.getConnect();
	}
	@Override
	public RegisterBean registerUser(RegisterBean bean) {
		boolean flag = false;
		String sql = "insert into RegisteredUsers values(?,?,?,?,?,?)";
		try{
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getFirstName());
			pstmt.setString(2, bean.getLastName());
			pstmt.setString(3, bean.getPassword());
			pstmt.setString(4, bean.getGender());
			pstmt.setString(5, bean.getSkillSet());
			pstmt.setString(6, bean.getCity());
			int row = pstmt.executeUpdate();
			if(row > 0){
				return bean;
			}
			else{
				bean = null;
			}
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}

}

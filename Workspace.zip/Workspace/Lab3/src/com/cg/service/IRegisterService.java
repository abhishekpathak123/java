package com.cg.service;

import com.cg.bean.RegisterBean;

public interface IRegisterService {

	public RegisterBean registerUser(RegisterBean bean);
}

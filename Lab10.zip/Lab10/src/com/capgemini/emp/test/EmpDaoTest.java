package com.capgemini.emp.test;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.Employee.Employee;
import com.capgemini.Employee.dao.EmployeeDaoImpl;
import com.capgemini.exception.EmployeeException;

public class EmpDaoTest {
	static EmployeeDaoImpl employeeDao;
	
	@BeforeClass
	public static void testEmplDaoImpl(){
		employeeDao=new EmployeeDaoImpl();
	}
	
	
	@Test
	public void testAddEmployee1()throws EmployeeException {
		int empId=employeeDao
				.addEmployee(
						new Employee()); 
								
		System.out.println("Unique Id : "+empId);
		assertNotEquals(0, empId);
	}
	@Test
	public void testAddEmployee2()throws EmployeeException {
		int empId=employeeDao.addEmployee(new Employee());
		System.out.println("Unique Id "+empId);
		assertTrue(empId>0);
	}
	public void testListEmployee3()throws EmployeeException {
		List<Employee> empList =employeeDao.listAllEmployee();
		assertNotNull("Employee List Not Found",empList);
		for(Employee emp:empList)
			System.out.println(emp);
	}

	
}

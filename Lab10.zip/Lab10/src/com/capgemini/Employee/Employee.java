//step 1 :one package declaration
package com.capgemini.Employee;

public class Employee {
	private String name;
	private double salary;
	private String designation;
	private String insuranceScheme;
	private int empId;
	public Employee() {
		
	}
	
	public Employee(String name, String designation, double salary,
			String insuranceScheme) {
		
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	public int getId() {
		return empId;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary(){
		return salary;
	}
	public void setSalary(double salary){
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	
}

package com.capgemini.Employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.Employee.Employee;
import com.capgemini.Employee.util.DBUtil;
import com.capgemini.exception.EmployeeException;



public class EmployeeDaoImpl implements IEmployeeDao {
	
	private static Connection connection = null;

	private static Logger myLogger = null;
	static {
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(DBUtil.class.getName());
	}
	
	public EmployeeDaoImpl() {
		try {
			connection = new DBUtil().obtainConnection();
			myLogger.info("Connection obtained ...at DAO");
		} catch (EmployeeException e) {
			myLogger.error("Error : " + e);
			System.err.println(e.getMessage());
		}
	}

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		employee=findInsuranceScheme(employee);
		myLogger.info("addEmployee() invoked in EmployeeDaoImpl!!");
		System.out.println("Adding Employee record.... Kindly have patience!!");
		String sql = "insert into emplab values(myEmp_seq.NEXTVAL,?,?,?,?)";
		PreparedStatement pst = null;
		int result = 0;
		int empId = 0;
		try {// obtain ps
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);// transaction starts

			// set the values for place hodlers
			pst.setString(1, employee.getName());
			pst.setDouble(2, employee.getSalary());
			pst.setString(3, employee.getDesignation());
			pst.setString(4, employee.getInsuranceScheme());

			// execute DML query
			result = pst.executeUpdate();
			empId = getEmployeeId();
			// set the empId of the current employee object
			employee.setEmpId(empId);
			myLogger.info("Employee details getting inserted "
					+ "....unique EmpID : " + empId);

			connection.commit();// if insert successful the commit the
								// transaction
		} catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Inserting Employee failed  "
					+ e.getMessage());
			throw new EmployeeException("ERRROR :  Inserting Employee failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Inserting Employee failed "
						+ e.getMessage());
				throw new EmployeeException(
						"ERRROR : Inserting Employee failed " + e.getMessage());
			}
		}
		return empId;
	}

	@Override
	public int updateEmployee(Employee employee) throws EmployeeException {
		myLogger.info("updateEmployee() invoked in EmployeeDaoImpl!!");

		System.out
				.println("Updating Employee record.... Kindly have patience!!");
		String sql = "update Employee set emp_name=?,"
				+ "salary=?,designation=?,insurance_scheme=? where emp_id=?";
		PreparedStatement pst = null;
		int result = 0;
		try {// obtain ps
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);// transaction starts
			// getting the auto_generated id from the getNextCustId()
			int EmployeeId = employee.getId();
			// set the values for place hodlers

			pst.setInt(5, employee.getId());
			pst.setString(1, employee.getName());
			pst.setDouble(2, employee.getSalary());
			pst.setString(3, employee.getDesignation());
			pst.setString(4, employee.getInsuranceScheme());
			
			myLogger.info("Employee details getting Updated ....");
			// execute DML query
			result = pst.executeUpdate();
			// now updating into Trainee table only if the first
			// insert is successful
			// getting the auto_generated id from the getNextTraineeId()
			myLogger.info("Employee Id : " + EmployeeId + " ,updated");

			connection.commit();// if insert successful the commit the
								// transaction
		} catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Updating Trainee failed  "
					+ e.getMessage());

			throw new EmployeeException("ERRROR :  Updating employee failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Updating Employee failed "
						+ e.getMessage());
				throw new EmployeeException("ERRROR : Updating Employee failed "
						+ e.getMessage());
			}
		}
		return result;
	}

	@Override
	public Employee searchEmployee(int empid) throws EmployeeException {
		myLogger.info("searchEmployee() in EmployeeDaoImpl invoked!!");
		String sql = "SELECT * FROM emplab WHERE emp_id=?";
		Employee employee = null;
		PreparedStatement pst = null;
		try {
			// obtaining pst
			pst = connection.prepareStatement(sql);
			pst.setInt(1, empid);// setting the traineeId
			ResultSet rs = pst.executeQuery();// executing the sql
			if (rs.next()) {
				myLogger.info("Stduent record found ");
				// create the object of trainee
				employee = new Employee();
				// mapping the value from db to trainee object
				employee.setEmpId(rs.getInt(1));
				employee.setName(rs.getString(2));
				employee.setSalary(rs.getDouble(3));	
				employee.setDesignation(rs.getString(4));
				employee.setInsuranceScheme(rs.getString(5));
				// convert sql date to LocalDate
				// java.sql.Date sqlDate= rs.getDate(4);//getting sql
				// date
				// LocalDate dob=sqlDate.toLocalDate();//convert sql date to
				// LocalDate

			} else {
				myLogger.error("ERRROR " + "TraineeId does Not Exits");
				throw new EmployeeException("TraineeId does Not Exits , ");
			}
		} catch (SQLException e) {
			myLogger.error("ERRROR " + "Searching Trainee details failed "
					+ e.getMessage());
			throw new EmployeeException("Searching Trainee details failed "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ERRROR " + "Searching Trainee details failed "
						+ e.getMessage());
				throw new EmployeeException(
						"Searching Trainee details failed " + e.getMessage());
			}
		}
		return employee;// returning trainee
	}

	@Override
	public List<Employee> listAllEmployee() throws EmployeeException {
		ArrayList<Employee> empList = null;
		Statement st = null;
		ResultSet rs = null;
		Employee employee = null;
		String sql = "select * from emplab";
		try {
			// obtain st
			st = connection.createStatement();
			rs = st.executeQuery(sql);
			empList = new ArrayList<>();
			while (rs.next()) {
				employee = new Employee();
				// fetch the column data
				// and set to the trainee object
				employee.setEmpId(rs.getInt(1));
				employee.setName(rs.getString(2));
				employee.setSalary(rs.getDouble(3));	
				employee.setDesignation(rs.getString(4));
				employee.setInsuranceScheme(rs.getString(5));
				empList.add(employee);
			}
		} catch (SQLException e) {
			myLogger.error("TraineeList not found , error occured : "
					+ e.getMessage());
			throw new EmployeeException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("TraineeList not found , error occured :"
						+ e.getMessage());
				throw new EmployeeException(e.getMessage());
			}
		}
		return empList;
	}

	@Override
	public int deleteEmployee(int id) throws EmployeeException {
		myLogger.info("------------------Deleting Traineeloyee Records----------------");
		PreparedStatement ps = null;
		String sql = "delete from emplab where emp_id=?";// '?'
		int noOfRec = 0; // placeholder
		try {
			// start the transaction boundary
			connection.setAutoCommit(false);
			// obatain ps object
			ps = connection.prepareStatement(sql);
			// prepare the pre-compiled statement
			// now we will set the dynamic(runtime) values of ps
			// placeholder-1
			ps.setInt(1, id);
			// execute the insert query(DML)-executeUpdate()
			noOfRec = ps.executeUpdate();
			connection.commit();// transaction ends
		} catch (SQLException e) {
			throw new EmployeeException("Issue in Deleting emp : " + e);
		} finally {
			if (ps != null)
				try {
					ps.close();
					connection.rollback();// if something wrong then rollback
				} catch (SQLException e) {
					throw new EmployeeException(
							"Issue while closing resource, which are null");
				}
		}
		return noOfRec;
	}

	@Override
	public int getEmployeeId() throws EmployeeException {
		myLogger.info("Generating unique TraineeId");
		String sql = "SELECT myEmp_seq.CURRVAL FROM dual";
		int traineeId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				traineeId = rs.getInt(1);
				myLogger.info("auto-generated TraineeId by sequence : "
						+ traineeId);
			} else {
				myLogger.error("TraineeId not auto generated , error occured ");
			}
		} catch (SQLException e) {
			myLogger.error("TraineeId not auto generated , error occured : "
					+ e.getMessage());
			throw new EmployeeException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("TraineeId not auto generated , error occured :"
						+ e.getMessage());
				throw new EmployeeException(e.getMessage());
			}
		}
		return traineeId;
	}
	

	@Override
	public Employee findInsuranceScheme(Employee employee){
	double sal = employee.getSalary();
	if (sal < 5000) {
		employee.setDesignation("Clerk");
		employee.setInsuranceScheme("No Scheme");
	} else if (sal >= 5000 && sal < 20000) {
		employee.setDesignation("System Associate");
		employee.setInsuranceScheme("Scheme C");
	} else if (sal >= 20000 && sal < 40000) {
		employee.setDesignation("Programmer");
		employee.setInsuranceScheme("Scheme B");
	} else {
		employee.setDesignation("Clerk");
		employee.setInsuranceScheme("Scheme A");
	}
	return employee;
	}

	@Override
	public List<Employee> sortBySalary() throws EmployeeException {
		myLogger.info(" sortting method invoked...");
		System.out.println("Listing employee record....");
		String sql="select * from emplab order by salary";
		PreparedStatement pst = null;
		int count=0;
		List<Employee> emplist = new ArrayList();
		ResultSet rs = null;
		Employee employee = null;
		try{
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);
			while(rs.next()){
				employee= new Employee();
				employee.setEmpId(rs.getInt(1));
				employee.setName(rs.getString(2));
				employee.setDesignation(rs.getString(3));
				employee.setSalary(rs.getDouble(4));
				employee.setInsuranceScheme(rs.getString(5));
				emplist.add(employee);
			}
		} catch (SQLException e) {
			throw new EmployeeException("Issue in Deleting emp : " + e);
		} finally {
			if (rs != null)
				try {
					rs.close();
					connection.rollback();// if something wrong then rollback
				} catch (SQLException e) {
					throw new EmployeeException(
							"Issue while closing resource, which are null");
				}
		}
		return emplist;
	}

	@Override
	public List<Employee> findByInsuranceScheme(String scheme)
			throws EmployeeException {
		ArrayList<Employee> emplist = null;
		String sql="select * from emplab where insurance_scheme=?";
		PreparedStatement pst = null;
		int count=0;
		ResultSet rs = null;
		Employee employee = null;
		try{
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);
			while(rs.next()){
				employee= new Employee();
				employee.setEmpId(rs.getInt(1));
				employee.setName(rs.getString(2));
				employee.setDesignation(rs.getString(3));
				employee.setSalary(rs.getDouble(4));
				employee.setInsuranceScheme(rs.getString(5));
				emplist.add(employee);
			}
		} catch (SQLException e) {
			throw new EmployeeException("Issue in Deleting emp : " + e);
		} finally {
			if (rs != null)
				try {
					rs.close();
					connection.rollback();// if something wrong then rollback
				} catch (SQLException e) {
					throw new EmployeeException(
							"Issue while closing resource, which are null");
				}
		}
		return emplist;
			}
	
}


package com.capgemini.Employee.dao;

import java.util.List;

import com.capgemini.Employee.Employee;
import com.capgemini.exception.EmployeeException;

public interface IEmployeeDao {
	public int addEmployee(Employee employee) throws EmployeeException;

	public int updateEmployee(Employee employee) throws EmployeeException;

	public Employee searchEmployee(int empid) throws EmployeeException;

	public Employee findInsuranceScheme(Employee employee)
			throws EmployeeException;

	public List<Employee> listAllEmployee() throws EmployeeException;

	public int deleteEmployee(int id) throws EmployeeException;

	public int getEmployeeId() throws EmployeeException;

	public List<Employee> sortBySalary()throws EmployeeException;
	public List<Employee> findByInsuranceScheme(String scheme)throws EmployeeException;

}

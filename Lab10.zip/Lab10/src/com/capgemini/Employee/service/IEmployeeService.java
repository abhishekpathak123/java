package com.capgemini.Employee.service;

import java.util.List;

import com.capgemini.Employee.Employee;
import com.capgemini.exception.EmployeeException;

public interface IEmployeeService {
	public int addEmployeeDetails(Employee employee)throws EmployeeException;

	public Employee findInsuranceScheme(Employee employee)throws EmployeeException;
	public Employee searchEmployee(int id)throws EmployeeException;
	public int deleteEmployee(int id)throws EmployeeException;
	public int updateEmployee(Employee employee)throws EmployeeException;
	public List<Employee> findByScheme(String scheme)throws EmployeeException;
	public List<Employee> sortBySalary()throws EmployeeException;
		
	public boolean validateId(int id)throws EmployeeException;
	public boolean validateName(String input)throws EmployeeException;
	public boolean validateSalary(double sal)throws EmployeeException;
	public boolean validateInsurScheme(String input)throws EmployeeException;

}

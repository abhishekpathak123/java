package com.capgemini.Employee.service;

import java.util.List;

import com.capgemini.Employee.Employee;
import com.capgemini.Employee.dao.EmployeeDaoImpl;
import com.capgemini.Employee.dao.IEmployeeDao;
import com.capgemini.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
	private static IEmployeeDao employeeDao;
	static {
		employeeDao = new EmployeeDaoImpl();
	}

	@Override
	public int addEmployeeDetails(Employee employee) throws EmployeeException {
		return employeeDao.addEmployee(employee);
	}

	@Override
	public Employee findInsuranceScheme(Employee employee)
			throws EmployeeException {

		return employeeDao.findInsuranceScheme(employee);
	}

	@Override
	public Employee searchEmployee(int id) throws EmployeeException {
		return employeeDao.searchEmployee(id);
	}

	@Override
	public int deleteEmployee(int id) throws EmployeeException {
		int status = employeeDao.deleteEmployee(id);
		return status;
	}

	@Override
	public int updateEmployee(Employee employee) throws EmployeeException {
		return employeeDao.updateEmployee(employee);
	}

	@Override
	public List<Employee> findByScheme(String scheme) throws EmployeeException {
		return employeeDao.findByInsuranceScheme(scheme);
	}

	@Override
	public boolean validateId(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateName(String input) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateSalary(double sal) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateInsurScheme(String input) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}

	public List<Employee> sortBySalary() throws EmployeeException {
		return employeeDao.sortBySalary();
	}

}

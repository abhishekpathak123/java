package com.capgemini.Employee.pl;

import java.util.List;
import java.util.Scanner;

import com.capgemini.Employee.Employee;
import com.capgemini.Employee.service.EmployeeServiceImpl;
import com.capgemini.exception.EmployeeException;



public class EmployeeClient {
	private static EmployeeServiceImpl employeeService= new EmployeeServiceImpl();
	private static Scanner scan =new Scanner(System.in);
	public static void main(String[] args) {
		do{
			int option=0;
			System.out.println(
					    "\n______________________________________\n"
						+ "\n Employee Designation Apllication   \n"
						+"\n_____________________________________\n"
						+"\nEnter your Choice\n"
						+"\n 1. Add Employee Details"
						+"\n 2. Find Eployee Details"
						+"\n 3. Delete Employee Details"
						+"\n 4. Sort Employee According to Salary"
						+"\n 5. Find By Insurance Scheme"
						+"\n 6. Exit"
					    +"\n_____________________________________\n");
			option = scan.nextInt();
			scan.nextLine();
			switch (option) {
			case 1:  try {
					acceptEmployeeDetails();
				} catch (EmployeeException e) {
					e.printStackTrace();
				}
				break;
			case 2:findInsuranceScheme();
				break;
			case 3:try {
					deleteEmployee();
				} catch (EmployeeException e) {
					e.printStackTrace();
				}
				break;
			case 4:try {
					sortemployee();
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 5:try {
					findByScheme();
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 6:exit();
				break;
			default:
				System.out.println("Wrong option entered"
						+ "\n kindly enter choice (1-3) only");
				break;
			}
		}while(true);
	}
	private static void sortemployee() throws EmployeeException {
		List<Employee> emp = null;
		emp = employeeService.sortBySalary();
		if(emp != null){
			for(Employee employee: emp){
				if(employee==null)
					break;
				displayDetails(employee);
			}
		}
		else
			System.out.println("No Records found...");
		
	}
	private static void findByScheme() throws EmployeeException {
		System.out.println("Enter Employee Insurance Scheme ");
		String scheme =scan.nextLine();
		List<Employee> emp = null;
		emp = employeeService.findByScheme(scheme);
		if(emp != null){
			for(Employee employee: emp){
				if(employee==null)
					break;
				displayDetails(employee);
			}
		}
		else
			System.out.println("No Records found with this scheme...");
		
	}
	private static void deleteEmployee() throws EmployeeException {
		System.out.println("Enter the Id of the employee to be deleted : ");
		int id=scan.nextInt();
		scan.nextLine();
		int status = employeeService.deleteEmployee(id);
		if(status==1)
			System.out.println("Employee deleted Successfully...");
		else
			System.out.println("No Employee found with id="+id);
		
	}
	private static void findInsuranceScheme() {
		System.out.println("Enter the Id to be searched : ");
		int id=scan.nextInt();
		scan.nextLine();
		Employee emp = null;
		try {
			emp = employeeService.searchEmployee(id);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(emp!=null)
			displayDetails(emp);
		else
			System.out.println("Employee not found");
	}
	private static void displayDetails(Employee emp) {
		System.out.println(
				         "\n________________________________________________________\n"
						+"\n               Employee Apllication\n"
						+"\n________________________________________________________\n"
				
						+ "\n Employee Id            : "+emp.getId()
						+ "\n Employee Name          : "+emp.getName()
						+ "\n Employee Salary        : "+emp.getSalary()
						+ "\n Employee Designation   : "+emp.getDesignation()
						+ "\n Insurance Scheme       : "+emp.getInsuranceScheme()
						+ "\n________________________________________________________\n");
		
	}
	private static void exit() {
		System.out.println(
				"Thankyou for using Employee App"
				+"    Do Visit Again!!!");
		scan.close();
		System.exit(0);
		
	}
	private static void acceptEmployeeDetails() throws EmployeeException{
		System.out.println("Enter Employee Name ");
		String nm =scan.nextLine();
		System.out.println("Enter Employee salary ");
		double Sal=scan.nextDouble();
		Employee emp=new Employee(nm,null, Sal, null);
		int status=employeeService.addEmployeeDetails(emp);
		if(status==0)
			System.out.println("Failed......");
		else
			System.out.println("Employee has been successfully added with id= "+emp.getId());

		}
	

}

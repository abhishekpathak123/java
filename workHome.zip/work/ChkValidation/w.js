  function valCheck(){
              var x=getElementById("phd");
              var y=getElementById("mphill");
			  if(!phd.checked && !mphill.checked)
			  alert("Please choose atleast one")
			  else
			      alert("You did it");
			  
				  
			  }

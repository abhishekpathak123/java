  function valCheck(){
              var chk=document.getElementsByClassName('check')
			  var flg=false;
			  for(var i=0;i<chk.length;i++){
			  if(chk[i].checked)
			  flg=true;
			  }
			  if(flg)
			      return true;
			  else{
			  alert(" Check atleast one course!");
			      return false;
				  
			  }
  }
  function Calculate(){
	  var x=document.getElementById("M").value;
	  document.getElementById("T").value =x;
	  
	  var date=new Date(document.getElementById("D").value);
	  var date1=new Date(document.getElementById("D1").value);
	  document.getElementById("I").value =(date-date1)/(1000*60*60*24);
  }
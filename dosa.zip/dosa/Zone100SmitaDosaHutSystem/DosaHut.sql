/*Smita B Kumar*/
create sequence customerSeq
start with 1000;

create sequence dosaSeq
start with 1000;
/*customer_details table*/
CREATE TABLE customer_details (
custId NUMBER(6) PRIMARY KEY, 
custName VARCHAR2(20),
custAddress VARCHAR2(30), 
custPhone NUMBER(10));

/*dosa_entry table*/
CREATE TABLE dosa_entry (
orderId NUMBER(6) PRIMARY KEY, 
custId NUMBER(6) CONSTRAINT Cust_DosaFK references Customer_details(custId), 
totalPrice NUMBER(7,2),
orderDate date);

/**insert customer_details*/
insert into customer_details values
(customerSeq.nextval,'mona','pune',9876543212);
SELECT * FROM customer_details;
/**insert dosa_entry*/
insert into dosa_entry values
(dosaSeq.nextval,customerSeq.currval,416.00,'20-OCT-2016');

SELECT * FROM dosa_entry;
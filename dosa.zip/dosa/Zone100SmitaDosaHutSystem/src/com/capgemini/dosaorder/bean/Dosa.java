/*CREATE TABLE pizza_entry (
orderId NUMBER(6) PRIMARY KEY, 
custId NUMBER(6) CONSTRAINT Cust_PizzaFK references Customer_details(custId), 
totalPrice NUMBER(7,2),
orderDate date);*/
package com.capgemini.dosaorder.bean;

import java.time.LocalDate;



/**
 * @author Smita
 *
 */
public class Dosa {
	// instance variables
	private int orderId;
	private int custId;
	private double totalPrice;
	private LocalDate orderDate;

	// No-Arg Constructor
	public Dosa() {
		// TODO Auto-generated constructor stub
	}

	// Overloaded Constructor
	public Dosa(int orderId, int custId, double totalPrice, LocalDate orderDate) {
		super();
		this.orderId = orderId;
		this.custId = custId;
		this.totalPrice = totalPrice;
		this.orderDate = orderDate;
	}

	// getters and setters
	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	// toString method
	@Override
	public String toString() {
		return "Dosa [orderId=" + orderId + ", custId=" + custId
				+ ", totalPrice=" + totalPrice + ", orderDate=" + orderDate
				+ "]";
	}
}

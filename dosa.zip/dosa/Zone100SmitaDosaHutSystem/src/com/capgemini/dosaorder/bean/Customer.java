/*CREATE TABLE customer_details (
custId NUMBER(6) PRIMARY KEY, 
custName VARCHAR2(20),
custAddress VARCHAR2(30), 
custPhone NUMBER(10));*/
package com.capgemini.dosaorder.bean;

/**
 * @author Smita
 *
 */
public class Customer {
	// instance variable
	private int custId;
	private String custName;
	private String custAddress;
	private long custPhone;

	// default constructor
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	// OverLoaded Constructor
	public Customer(int custId, String custName, String custAddress,
			long custPhone) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custAddress = custAddress;
		this.custPhone = custPhone;
	}

	// getter and setters
	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	public long getCustPhone() {
		return custPhone;
	}

	public void setCustPhone(long custPhone) {
		this.custPhone = custPhone;
	}

	// toString method
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName
				+ ", custAddress=" + custAddress + ", custPhone=" + custPhone
				+ "]";
	}
}

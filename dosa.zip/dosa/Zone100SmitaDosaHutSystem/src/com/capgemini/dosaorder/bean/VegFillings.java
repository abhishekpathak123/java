/**
 * 
 */
package com.capgemini.dosaorder.bean;

/**
 * @author Smita
 *
 */

public enum VegFillings {
	POTATO(30), MIXVEG(50), SEZWAAN(70), PANEER(85);
	private int price;

	// contr are always private in enum
	private VegFillings(int price) {
		this.price = price;
	}

	// getters and setters
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
}
package com.capgemini.dosaorder.service;
/**
 * Interface to interact with client
 */
import com.capgemini.dosaorder.bean.Customer;
import com.capgemini.dosaorder.bean.Dosa;
import com.capgemini.dosaorder.exception.DosaException;

/**
 * @author Smita
 *
 */
public interface IDosaOrderService {
	public int placeDosa(Customer customer, Dosa dosa) throws DosaException;
	public Dosa displayOrder(int orderId) throws DosaException;
	//validation Service
	public boolean validatePhoneNo(long phoneNo)
			throws DosaException;
	public boolean validateName(String name) throws DosaException;
	public boolean validateFilling(String filling)throws DosaException;
	public boolean validateOrderId(int orderId)throws DosaException;
}
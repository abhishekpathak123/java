package com.capgemini.dosaorder.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.dosaorder.bean.Customer;
import com.capgemini.dosaorder.bean.Dosa;
import com.capgemini.dosaorder.bean.VegFillings;
import com.capgemini.dosaorder.dao.IDosaOrderDAO;
import com.capgemini.dosaorder.dao.DosaOrderDAO;
import com.capgemini.dosaorder.exception.DosaException;
/**
 * 
 * @author Smita
 *
 */
public class DosaOrderService implements IDosaOrderService {
	private IDosaOrderDAO dosaOrderDAO;
	public DosaOrderService() throws DosaException {
		dosaOrderDAO = new DosaOrderDAO();
	}
	@Override
	public int placeDosa(Customer customer, Dosa dosa) throws DosaException {
		return dosaOrderDAO.placeDosa(customer, dosa);
	}
	@Override
	public Dosa displayOrder(int orderId) throws DosaException {
		return dosaOrderDAO.displayOrder(orderId);
	}
	
	public IDosaOrderDAO getMobilePurchaseDao() {
		return dosaOrderDAO;
	}

	public void setMobilePurchaseDao(IDosaOrderDAO mobilePurchaseDao) {
		this.dosaOrderDAO = mobilePurchaseDao;
	}
	public boolean validatePhoneNo(long phoneNo)
			throws DosaException {
		String strPh=String.valueOf(phoneNo);
		Pattern namePattern = Pattern.compile("[789]{1}[0-9]{9}");
		Matcher nameMatcher = namePattern.matcher(strPh);
		if (!(nameMatcher.matches())) {
			return false;
		} else {
			return true;
		}
	}
	@Override
	public boolean validateFilling(String filling)throws DosaException {

	    for (VegFillings fillingType : VegFillings.values()) {
	        if (fillingType.name().equals(filling)) {
	        	System.out.println("You Seleted : "+filling +" As Filling!");
	            return true;
	        }
	    }
	    return false;
	}
	@Override
	public boolean validateName(String name) throws DosaException {
		Pattern namePattern = Pattern.compile("^[A-Z][A-Za-z]{3,20}$");
		Matcher nameMatcher = namePattern.matcher(name);
		if (!(nameMatcher.matches())) {
			return false;
		} else {
			return true;
		}
	}
	public boolean validateOrderId(int orderId) {
		String strId = String.valueOf(orderId);
		Pattern idPattern = Pattern.compile("[0-9]{4}");
		Matcher idMatcher = idPattern.matcher(strId);
		if (idMatcher.matches())
			return true;
		else
			return false;
	}
	
	public boolean validateQuantity(int quantity)
			throws DosaException {
		if (quantity < 0) {
			return false;
		} else {
			return true;
		}
	}
	public boolean validatePrice(int price)
			throws DosaException {
		if (price < 0) {
			return false;
		} else {
			return true;
		}
	}
	public boolean validateEmailId(String mailId)
			throws DosaException {
		Pattern namePattern = Pattern.compile("^[\\w-_\\.+]*[\\w-_\\.]\\"
				+ "@([\\w]+\\.)+[\\w]+[\\w]$");
		Matcher nameMatcher = namePattern.matcher(mailId);
		if (!(nameMatcher.matches())) {
			return false;
		} else {
			return true;
		}
	}
	public boolean validatePositiveNumber(double number)
			throws DosaException {
		if(number<0)
			return false;
		else
			return true;
	}
	public boolean checkDate(String orderDate) {
		String dateRegex = "([0-9]{4})/([0-9]{2})/([0-9]{2})";
		if (orderDate.matches(dateRegex))
			return false;
		else
			return true;
	}
}

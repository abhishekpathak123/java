package com.capgemini.dosaorder.client;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.dosaorder.bean.Customer;
import com.capgemini.dosaorder.bean.Dosa;
import com.capgemini.dosaorder.bean.VegFillings;
import com.capgemini.dosaorder.exception.DosaException;
import com.capgemini.dosaorder.service.IDosaOrderService;
import com.capgemini.dosaorder.service.DosaOrderService;
import com.capgemini.dosaorder.util.DBUtil;

/**
 * 
 * @author smita
 *
 */
public class DosaOrderClient {
	static Logger myLogger;
	
	static IDosaOrderService dosaOrderService;
	static{
		myLogger = Logger.getLogger(DosaOrderClient.class.getName());
		try {
			dosaOrderService = new DosaOrderService();
		} catch (DosaException e) {
			myLogger.error("Error while obtaining Service Object.."+e);
			System.out.println("Error while obtaining Service Object.."+e);
		}
	}
	@SuppressWarnings("resource")
	public static void main(String[] args) throws DosaException {
		PropertyConfigurator.configure("resources/log4j.properties");
		int option = 0;
		Scanner sc = new Scanner(System.in);
		while (true) {
			// show menu
			showMenu();
			// accept option
			try {
				option = sc.nextInt();
				switch (option) {
				case 1:
					placeOrder();
					break;
				case 2:
					displayOrder();
					break;
				case 3:
					exitApp();
					break;
				default:
					System.out.println("Enter a valid option[1-3]");
				}// end of switch

			} catch (InputMismatchException e) {
				myLogger.error("Please enter a numeric value, Try Again" + e);
				sc.nextLine();
				System.err.println("Please enter a numeric value, Try Again");
			} catch (DosaException e) {
				myLogger.error("ERRROR " + e);
				System.err.println(e.getMessage());
			}
		}// end of while
	}// end of method

	private static void exitApp() {
		System.out.println("Exit Dosa Order System");
		System.out
				.println("=============Thank You=================");
		System.exit(0);
	}

	private static void displayOrder(){
		Scanner sc = new Scanner(System.in);
		System.out.println("=====Display Order======");
		System.out.println("Enter your order Id:");
		int orderId = 0;
		try{
		orderId = sc.nextInt();
		
		// validating userId
		while (true) {
			if (dosaOrderService.validateOrderId(orderId)) {
				break;
			} else {
				System.err.println("OrderId must 4 digit only!,Enter Again");
				orderId = sc.nextInt();
			}
		}
		Dosa dosa = dosaOrderService.displayOrder(orderId);
		// System.out.println("Client dosa::"+dosa);
		if (dosa != null) {
			System.out.println("\n=======Your Order Deatils=======");
			System.out.println("Order ID 	: " + dosa.getOrderId());
			System.out.println("TOTAL PRICE	: " + dosa.getTotalPrice());
			System.out.println("Order DATE	: " + dosa.getOrderDate());

		} else
			System.out.println("No Order placed with this Id : " + orderId
					+ "\n ,Kindly place an Order First!!");
		}catch (InputMismatchException e) {
			myLogger.error("Please enter a numeric value, Try Again" + e);
			sc.nextLine();
			System.err.println("Please enter a numeric value, Try Again");
		}catch (DosaException e) {
			myLogger.error("ERROR while display Order at Client" + e);
			sc.nextLine();
			System.err.println("ERROR while display Order at Client, Try Again");
		}
	}

	private static void placeOrder() throws DosaException {
		// invoking acceptCustomerDetails() to accept and
		// validate input
		Customer customer = acceptCustomerDetails();
		Dosa dosa = acceptDosaDetails();
		int id=0;
		// invoking placeDosaOrder service
		try{
			id = dosaOrderService.placeDosa(customer, dosa);
		if (id> 0) {
			System.out
					.println("\n=======Dosa Order Placed Successfuly========\n"
							+ "\n____________________________________________"

							+ "\nThank you for placing order with us !!\n"
							+ "   You Order ID is : "+id
							+ "\n____________________________________________");
		} else
			System.out
					.println("====Sorry Sir! Order Cancelled ! please Try Again===");
		}catch (DosaException e) {
			myLogger.error("ERROR while Placing the Order at Client" + e);
			System.err.println("ERROR while Placing the Order at Client, Try Again");
		}
	}

	private static void showMenu() {
		System.out
				.println("\n_____________________________________________________________________________________________\n"
						+ "\n      Dosa Order System "
						+ "\n_____________________________________________________________________________________________\n"
						+ "\n      1.Place Order"
						+ "\n      2.Display Order"
						+ "\n      3.Exit"
						+ "\n______________________________________________________________________________________________"
						+ "\nSelect an option:");
	}

	// method for accepting dosa details from the user
	@SuppressWarnings("resource")
	private static Dosa acceptDosaDetails() throws DosaException {
		String fillings = String.valueOf(VegFillings.POTATO);// default filling
															// is CAPSICUM
		Dosa dosa = null;
		Scanner sc = new Scanner(System.in);
		System.out.println("____________ Dosa Fillings ______________\n");
		System.out.println("TOPPINGS		PRICE\n");
		for (VegFillings filling : VegFillings.values()) {
			System.out.println(filling + " : " 
		+ filling.getPrice());
		}
		System.out.println("________________________________________\n");
		System.out.println("\nKindly Enter the preferred Dosa Fillings \n "
				+ "Default Filling is 'POTATO : 30 Rs' ");

		try {
			fillings = sc.next().toUpperCase();// converting the value entered
												// into uppercase
			while (true) {
				if (dosaOrderService.validateFilling(fillings)) {
					break;
				} else {
					System.err
							.println("Kindly Enter the preferred Dosa Fillings\n Default Filling is 'CAPSICUM : 30 Rs'\n, Try Again");
					fillings = sc.next().toUpperCase();// converting the value
						// entered into uppercase
				}
			}// end of while
			double fillingPrice = VegFillings.valueOf(fillings).getPrice();
			double totalPrice = 100 + fillingPrice;
			/* adding base price to filling */
			totalPrice += ((fillingPrice) * 0.04);
			/* adding 4% VAT of TotalPrice to the totalPrice */
			System.out
					.println("Dosa Total Price (Base Rs.100+filling+4%VAT) : "
							+ totalPrice);
			// current date will be orderDate
			LocalDate orderDate = LocalDate.now();
			// System.out.println("Order Date  : " + orderDate);

			// after accepting values now creating Dosa
			dosa = new Dosa();
			dosa.setOrderDate(orderDate);
			dosa.setTotalPrice(totalPrice);
		} catch (IllegalArgumentException e) {
			myLogger.error("Please enter the above Filling only, Try Again" + e);
			sc.nextLine();
			System.err
					.println("Please enter the above Filling only, Try Again");
		}
		return dosa;
	}// end of method

	// method to accept customer details
	@SuppressWarnings("resource")
	private static Customer acceptCustomerDetails() throws DosaException {
		Scanner sc = new Scanner(System.in);
		Customer customer = null;

		System.out.println("Enter The name of the Customer :");
		String custName = sc.next().toUpperCase();
		while (true) {
			if (dosaOrderService.validateName(custName)) {
				break;
			} else {
				System.err
						.println("Please Customer Name must be characters only, Try Again");
				custName = sc.next();
			}
		}
		System.out.println("Enter customer address :");
		String custAddress = sc.next().toUpperCase();

		System.out
				.println("Enter customer Phone No(only 10 disigit) eg : 9876543212 (must start with 7 or 8 or 9 :");
		long custPhone = 0;
		try {
			custPhone = sc.nextLong();
		} catch (InputMismatchException e) {
			myLogger.error("Please enter a numeric value, Try Again" + e);
			sc.nextLine();
			System.err.println("Please enter a numeric value, Try Again");
		}
		while (true) {
			if (dosaOrderService.validatePhoneNo(custPhone)) {
				break;
			} else {
				System.err
						.println("Please Phone No(only 10 disigit) eg : 9876543212 (must start with 7 or 8 or 9 only, Try Again");
				try {
					custPhone = sc.nextLong();
				} catch (InputMismatchException e) {
					myLogger.error("Please enter a numeric value, Try Again"
							+ e);
					sc.nextLine();
					System.err
							.println("Please enter a numeric value, Try Again");
				}
			}
		}

		// after accepting values now creating Customer object
		customer = new Customer();
		customer.setCustName(custName);
		customer.setCustAddress(custAddress);
		customer.setCustPhone(custPhone);

		return customer;
	}// end of method
}

package com.capgemini.dosaorder.dao;
/**
 * Interface to interact with Database
 */
import com.capgemini.dosaorder.bean.Customer;
import com.capgemini.dosaorder.bean.Dosa;
import com.capgemini.dosaorder.exception.DosaException;

/**
 * @author Smita
 *
 */
public interface IDosaOrderDAO {
	public int placeDosa(Customer customer, Dosa dosa) throws DosaException;//place order
	public Dosa displayOrder(int orderId) throws DosaException;
}
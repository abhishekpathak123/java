package com.capgemini.dosaorder.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.dosaorder.bean.Customer;
import com.capgemini.dosaorder.bean.Dosa;
import com.capgemini.dosaorder.exception.DosaException;
import com.capgemini.dosaorder.util.DBUtil;

/**
 * 
 * @author Smita
 *
 */
public class DosaOrderDAO implements IDosaOrderDAO {
	private static Logger myLogger = null;
	private Connection connection;
	static {
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(DosaOrderDAO.class.getName());
	}

	public DosaOrderDAO() throws DosaException {
		try {
			connection = new DBUtil().obtainConnection();

		} catch (DosaException e) {
			myLogger.error("ERRROR in obtaining Connetion in Dao.. " + e);
			throw new DosaException("ERRROR in obtaining Connetion in Dao.."
					+ e);
		}
	}

	// business methods

	@Override
	public int placeDosa(Customer customer, Dosa dosa) throws DosaException {
		// placing order we need to fire 2 insert statements
		myLogger.info("Placing An Order .... Kindly have patience!!");
		String sql = "insert into dosa_entry values(dosaSeq.NEXTVAL,?,?,?)";
		PreparedStatement pst = null;
		int result = 0;
		int orderId = 0;
		try {// obtain ps
			result = (insertCustomerDetails(customer));
			if (result > 0) {
				pst = connection.prepareStatement(sql);
				// getting the auto_generated id from the getNextCustId()
				int custId = getUniqueCustId();
				customer.setCustId(custId);
				// now inserting into dosa_entry table only if the first
				// insert is successful
				dosa.setCustId(custId);// setting the custId
				// if orderId is generated then only insert will happen
				myLogger.info("Order details getting inserted ....");
				// set the values for place hodlers
				pst.setInt(1, dosa.getCustId());
				pst.setDouble(2, dosa.getTotalPrice());
				// converting localdate to sql date
				java.sql.Date sqlDate=java.sql.Date.valueOf(dosa.getOrderDate());
				pst.setDate(3, sqlDate);
				// execute DML query
				result = pst.executeUpdate();
				if (result > 0) {
					// getting the auto_generated id from the getNextOrderId()
					orderId = getUniqueOrderId();
					myLogger.info("Generating unique orderId ....");
					dosa.setOrderId(orderId);// setting the order id
				}
				myLogger.info("\n==========Your Order Id : " + orderId
						+ "==========\n");
			}// end of if
			else {
				myLogger.error("ERRROR :  " + "Placing Dosa failed ");
				throw new DosaException("Placing Dosa failed ");
			}
			connection.commit();// if both insert successful the commit the
								// transaction
		} catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Placing Dosa failed "
					+ e.getMessage());
			throw new DosaException("ERRROR :  Placing Dosa failed "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Placing Dosa failed "
						+ e.getMessage());
				throw new DosaException("ERRROR : Placing Dosa failed "
						+ e.getMessage());
			}
		}
		return orderId;
	}

	private int insertCustomerDetails(Customer customer) throws SQLException {
		// placing order we need to fire 2 insert statements
		myLogger.info("Inserting Customeer details .... Kindly have patience!!");
		String sql = "insert into customer_details values(customerSeq.NEXTVAL,?,?,?)";
		PreparedStatement pst = null;
		pst = connection.prepareStatement(sql);
		connection.setAutoCommit(false);// transaction starts
		// set the values for place hodlers
		pst.setString(1, customer.getCustName());
		pst.setString(2, customer.getCustAddress());
		pst.setLong(3, customer.getCustPhone());
		myLogger.info("Customer details getting inserted ....");
		int result=pst.executeUpdate();
		return result;
	}

	@Override
	public Dosa displayOrder(int orderId) throws DosaException {
		myLogger.info("displayOrder() invoked!!");
		String sql = "SELECT * FROM dosa_entry WHERE orderId=?";
		Dosa dosa = null;
		PreparedStatement pst = null;
		try {
			// obtaining pst
			pst = connection.prepareStatement(sql);
			pst.setInt(1, orderId);// setting the orderId
			ResultSet rs = pst.executeQuery();// executing the sql
			if (rs.next()) {
				dosa = new Dosa();// creating new dosa object
				// fetching record from database and setting to the dosa object
				dosa.setOrderId(rs.getInt("orderId"));
				dosa.setCustId(rs.getInt("custId"));
				// converting sql date to LocalDate date
				java.sql.Date sqlDate=rs.getDate("orderDate");
				LocalDate orderDate = sqlDate.toLocalDate();
				dosa.setOrderDate(orderDate);
				dosa.setTotalPrice(rs.getDouble("totalPrice"));
				myLogger.info("Dao DisplayOrder dosa :: " + dosa);
				// System.out.println("Dao Display dosa :: " + dosa);
			} else {
				myLogger.error("ERRROR " + "OrderId does Not Exits");
				throw new DosaException("OrderId does Not Exits , ");
			}
		} catch (SQLException e) {
			myLogger.error("ERRROR " + "Displaying Dosa details failed "
					+ e.getMessage());
			throw new DosaException("Displaying Dosa details failed "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ERRROR " + "Displaying Dosa details failed "
						+ e.getMessage());
				throw new DosaException("Displaying Dosa details failed "
						+ e.getMessage());
			}
		}
		return dosa;// returning dosa order
	}

	// method to fetch auto-generated custId by sequence
	public int getUniqueCustId() throws DosaException {
		String sql = "SELECT customerSeq.CURRVAL FROM dual";
		int custId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				custId = rs.getInt(1);
				myLogger.info("auto-generated custId by sequence : " + custId);
			} else {
				myLogger.error("CustId not auto generated , error occured ");
			}
		} catch (SQLException e) {
			myLogger.error("CustId not auto generated , error occured : "
					+ e.getMessage());
			throw new DosaException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("CustId not auto generated , error occured :"
						+ e.getMessage());
				throw new DosaException(e.getMessage());
			}
		}
		return custId;
	}

	// method to fetch auto-generated orderId by sequence
	public int getUniqueOrderId() throws DosaException {
		String sql = "SELECT dosaSeq.CURRVAL FROM dual";
		int orderId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				orderId = rs.getInt(1);
				myLogger.info("auto-generated orderId by sequence : " + orderId);
			} else {
				myLogger.error("OrderId not auto generated , error occured ");
			}
		} catch (SQLException e) {
			myLogger.error("OrderId not auto generated , error occured :"
					+ e.getMessage());
			throw new DosaException(
					"OrderId not auto generated , error occured :"
							+ e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("OrderId not auto generated , error occured : "
						+ e.getMessage());
				throw new DosaException(e.getMessage());
			}
		}
		return orderId;
	}

	// getters and setters
	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}
}

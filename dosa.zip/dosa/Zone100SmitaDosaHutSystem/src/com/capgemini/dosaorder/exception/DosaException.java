package com.capgemini.dosaorder.exception;

public class DosaException extends Exception {

	private static final long serialVersionUID = -8641024466845094458L;

	public DosaException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DosaException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public DosaException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DosaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DosaException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}

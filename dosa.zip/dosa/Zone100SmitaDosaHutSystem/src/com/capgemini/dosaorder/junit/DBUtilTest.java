package com.capgemini.dosaorder.junit;
import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.dosaorder.exception.DosaException;
import com.capgemini.dosaorder.util.DBUtil;

/**
 * @author Smita
 *
 */
public class DBUtilTest {
	 static DBUtil dbUtil ;
	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void testDBUtil() throws DosaException{
		dbUtil= new DBUtil();
		assertNotNull("DBUtil Object Not created..."
				,dbUtil);
	}
	@Test
	public void testConnection() throws DosaException {
		Connection conn = dbUtil.obtainConnection();
		assertNotNull("Connection NOT obtained!",conn);
		if(conn!=null)System.out.println("connection Obtained ...."+conn);
	}

}

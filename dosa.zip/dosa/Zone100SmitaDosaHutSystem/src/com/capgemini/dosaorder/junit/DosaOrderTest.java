/**
 * 
 */
package com.capgemini.dosaorder.junit;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.time.LocalDate;
import java.util.Date;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.dosaorder.bean.Customer;
import com.capgemini.dosaorder.bean.Dosa;
import com.capgemini.dosaorder.dao.DosaOrderDAO;
import com.capgemini.dosaorder.exception.DosaException;
import com.capgemini.dosaorder.service.DosaOrderService;
import com.capgemini.dosaorder.util.DBUtil;

/**
 * @author SMita
 *
 */
public class DosaOrderTest {
	private static DosaOrderDAO dosaOrderDAO;

	// testing dao Object before class
	@BeforeClass
	public static void createDaoObject() throws DosaException {
		dosaOrderDAO = new DosaOrderDAO();
		assertNotNull(dosaOrderDAO);
	}


	// testing displayOrder()method of DAO class
	@Test
	public void testDisplayOrder1() throws DosaException {
		try {// displaying dosa order
			int orderId = 1002;
			Dosa dosa = dosaOrderDAO.displayOrder(orderId);
			assertNotNull(dosa);
			if(dosa!=null)System.out.println("Displaying Placed order : "+dosa);
		} catch (Exception e) {
			throw new DosaException(e.getMessage());
		}
	}
	// testing displayOrder()method of DAO class
		@Test
		public void testDisplayOrder2() throws DosaException {
			try {// displaying dosa order
				int orderId = 1004;
				Dosa dosa = dosaOrderDAO.displayOrder(orderId);
				assertTrue(dosa!=null);
				if(dosa!=null)System.out.println("Displaying Placed order : "+dosa);
			} catch (Exception e) {
				throw new DosaException(e.getMessage());
			}
		}

	// testing placeDosa()method of DAO class
	@Test
	public void testPlaceDosa1() throws DosaException {
		try {
			Customer customer = new Customer(1111, "Smita", "mumbai",
					9876543212L);
			Dosa dosa = new Dosa(1111, 1111, 438, LocalDate.now());
			int orderId = dosaOrderDAO.placeDosa(customer, dosa);
			assertFalse("Order Not Placed", orderId==0);
			if(orderId>0)System.out.println("Order Placed..Order Id is : "+orderId);
		} catch (Exception e) {
			throw new DosaException(e.getMessage());
		}
	}
	// testing placeDosa()method of DAO class
		@Test
		public void testPlaceDosa2() throws DosaException {
			try {// placeDosa order
				Customer customer = new Customer(2222, "Smita", "mumbai",
						9876543212L);
				Dosa dosa = new Dosa(2222, 2222, 438,LocalDate.now());
				int orderId = dosaOrderDAO.placeDosa(customer, dosa);
				assertTrue("Order Not Placed", orderId>0);
				if(orderId>0)System.out.println("Order Placed..Order Id is : "+orderId);
			} catch (Exception e) {
				throw new DosaException(e.getMessage());
			}
		}

	
}

/*CREATE TABLE purchasedetails(
	purchaseid NUMBER, 
	cname vARCHAR2(20), 
	mailid VARCHAR2(30),
	phoneno VARCHAR2(20), 
	purchasedate DATE, 
	mobileid references mobiles(mobileid));
 */
package com.capgemini.mobile.bean;

import java.time.LocalDate;

/**
 * @author shosakop
 *
 */
public class PurchaseDetails {
	private int purchaseId; 
	private String cName; 
	private String mailId;
	private String phoneNo; 
	private LocalDate purchaseDate;
	private int mobileId;
	
	public PurchaseDetails() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param purchaseId
	 * @param cName
	 * @param mailId
	 * @param phoneNo
	 * @param purchaseDate
	 * @param mobileId
	 */
	public PurchaseDetails(int purchaseId, String cName, String mailId,
			String phoneNo, LocalDate purchaseDate, int mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.cName = cName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}

	/**
	 * @return the purchaseId
	 */
	public int getPurchaseId() {
		return purchaseId;
	}

	/**
	 * @param purchaseId the purchaseId to set
	 */
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	/**
	 * @return the cName
	 */
	public String getcName() {
		return cName;
	}

	/**
	 * @param cName the cName to set
	 */
	public void setcName(String cName) {
		this.cName = cName;
	}

	/**
	 * @return the mailId
	 */
	public String getMailId() {
		return mailId;
	}

	/**
	 * @param mailId the mailId to set
	 */
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	/**
	 * @return the phoneNo
	 */
	public String getPhoneNo() {
		return phoneNo;
	}

	/**
	 * @param phoneNo the phoneNo to set
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	/**
	 * @return the purchaseDate
	 */
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}

	/**
	 * @param purchaseDate the purchaseDate to set
	 */
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	/**
	 * @return the mobileId
	 */
	public int getMobileId() {
		return mobileId;
	}

	/**
	 * @param mobileId the mobileId to set
	 */
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId=" + purchaseId + ", cName=" + cName
				+ ", mailId=" + mailId + ", phoneNo=" + phoneNo
				+ ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId
				+ "]";
	}

	public void print() {
		System.out.println(
				  "\n________________________________________________________________________________"
				+ "\n	Mobile Purchase Details					"
				+ "\n________________________________________________________________________________"
				+ "\n	PurchaseDetails Id: " + purchaseId
				+ "\n	Customer Id       : " + cName
				+ "\n	Email             : " + mailId
				+ "\n	Phone No          : " + phoneNo
				+ "\n	PurchaseDate      : " + purchaseDate
				+ "\n	Mobile Id         : " + mobileId
				+ "\n________________________________________________________________________________");
	
	}

}

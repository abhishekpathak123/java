/*
  CREATE TABLE mobiles (
  mobileid NUMBER PRIMARY KEY,
   name VARCHAR2 (20), 
   price NUMBER(10,2),
   quantity VARCHAR2(20));
	

 */
package com.capgemini.mobile.bean;

/**
 * @author Smita
 *
 */
public class Mobile {

	private int mobileId;
	private String name; 
	private double price;
	private int quantity;
	public Mobile() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the mobileId
	 */
	public int getMobileId() {
		return mobileId;
	}
	/**
	 * @param mobileId the mobileId to set
	 */
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	/**
	 * @param mobileId
	 * @param name
	 * @param price
	 * @param quantity
	 */
	public Mobile(int mobileId, String name, double price, int quantity) {
		super();
		this.mobileId = mobileId;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", name=" + name + ", price="
				+ price + ", quantity=" + quantity + "]";
	}

}

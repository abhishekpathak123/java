/**
 * 
 */
package com.capgemini.mobile.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.mobile.bean.Mobile;
import com.capgemini.mobile.bean.PurchaseDetails;
import com.capgemini.mobile.dao.IMobileDao;
import com.capgemini.mobile.dao.MobileDaoImpl;
import com.capgemini.mobile.exception.MobileException;

/**
 * @author Smita
 *
 */
public class MobileServiceImpl implements IMobileService {
	private static IMobileDao mobileDao;
	static {
		//initialize dao object
		mobileDao = new MobileDaoImpl();
	}
	public MobileServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see com.capgemini.mobile.service.IMobileService#insertPurchasedetails(com.capgemini.mobile.bean.PurchaseDetails)
	 */
	@Override
	public int insertPurchaseDetails(PurchaseDetails purchaseDetails)
			throws MobileException {
		// TODO Auto-generated method stub
		return mobileDao.insertPurchasedetails(purchaseDetails);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.mobile.service.IMobileService#listAllMobiles()
	 */
	@Override
	public List<Mobile> listAllMobiles() throws MobileException {
		// TODO Auto-generated method stub
		return mobileDao.listAllMobiles();
	}

	/* (non-Javadoc)
	 * @see com.capgemini.mobile.service.IMobileService#removeMobile(int)
	 */
	@Override
	public int removeMobile(int mobileId) throws MobileException {
		// TODO Auto-generated method stub
		return mobileDao.removeMobile(mobileId);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.mobile.service.IMobileService#searchMobile(double, double)
	 */
	@Override
	public List<Mobile> searchMobile(double minPrice, double maxPrice)
			throws MobileException {
		// TODO Auto-generated method stub
		return mobileDao.searchMobile(minPrice, maxPrice);
	}
	@Override
	public PurchaseDetails searchMobilePurchaseDeatails(int purchaseId)
			throws MobileException {
		// TODO Auto-generated method stub
		return mobileDao.searchMobilePurchaseDeatails(purchaseId);
	}
//validation methods

	// Validation Services Implementations
	// /which validates input and
	// /returns boolean value to the clientCode
	@Override
	public boolean validateId(int id) throws MobileException {
		// converting int to String inorder to perform regex validation
		String input = String.valueOf(id);

		// creating regex pattern String
		String patternStr = "^[0-9]{4}$";// only 4 digits
		// Now create Pattern object.

		Pattern pattern = Pattern.compile(patternStr);
		// Now create matcher object.
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
		//return input.matches(patternStr);
		// or
		//return Pattern.matches(patternStr, input);
	}

	@Override
	public boolean validateName(String input) throws MobileException {
		// creating regex pattern String
		String patternStr = "^[A-Z][a-z]{2,20}$";
		// 3-20 char, first letter must be in caps
		
		// Now create Pattern object.
		Pattern pattern = Pattern.compile(patternStr);
		// Now create matcher object.
		Matcher matcher = pattern.matcher(input);
		//now matcher matches
		return matcher.matches();
	}

	@Override
	public boolean validatePhoneNo(String input) throws MobileException {
		// creating regex pattern String
		String patternStr = "^[789][0-9]{9}$";
		// 10 digits phone number
		// 1st number must start with 7 or 8 or 9
		// followed by 9 digits
		// Now create matcher object.

		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}

	@Override
	public boolean validateEmail(String input) throws MobileException {
		// creating regex pattern String
		String patternStr = 
				"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		// must be in proper email format
		// Now create matcher object.

		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}

	/*
	 * ^ #start of the line [_A-Za-z0-9-\\+]+ # must start with string in the
	 * bracket [ ], must contains one or more (+) ( # start of group #1
	 * \\.[_A-Za-z0-9-]+ # follow by a dot "." and string in the bracket [ ],
	 * must contains one or more (+) )* # end of group #1, this group is
	 * optional (*)
	 * 
	 * @ # must contains a "@" symbol [A-Za-z0-9-]+ # follow by string in the
	 * bracket [ ], must contains one or more (+) ( # start of group #2 - first
	 * level TLD checking \\.[A-Za-z0-9]+ # follow by a dot "." and string in
	 * the bracket [ ], must contains one or more (+) )* # end of group #2, this
	 * group is optional (*) ( # start of group #3 - second level TLD checking
	 * \\.[A-Za-z]{2,} # follow by a dot "." and string in the bracket [ ], with
	 * minimum length of 2 ) # end of group #3 $ #end of the line
	 */

	@Override
	public boolean validatePrice(double minPrice, double maxPrice)
			throws MobileException {
		if(minPrice<maxPrice)
			return true;
		else 
			return false;		
	}

	

}

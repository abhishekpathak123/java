/**
 * 
 */
package com.capgemini.mobile.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.mobile.bean.Mobile;
import com.capgemini.mobile.bean.PurchaseDetails;
import com.capgemini.mobile.dao.IMobileDao;
import com.capgemini.mobile.dao.MobileDaoImpl;
import com.capgemini.mobile.exception.MobileException;

/**
 * @author Smita
 *
 */
public class MobileDaoImplTest {
	private static IMobileDao mobileDao;	
	@BeforeClass
	public static void testEmpDaoImpl(){
		mobileDao= new MobileDaoImpl();
		assertNotNull("MobileDaoImpl List Not Found",
				mobileDao);
		if(mobileDao!=null)System.out.println("mobileDao object created");
	}
	@Test
	public void testInsertPurchasedetails() throws MobileException {
		PurchaseDetails purchaseDetails = 
				new PurchaseDetails(2222,
				"Mona", "mon@cg.com", "8889879991", 
				LocalDate.now(), 1001);
		int purchaseId=mobileDao.insertPurchasedetails(purchaseDetails);
		if(purchaseId>0)System.out.println("Unique Id : "+purchaseId);
		assertNotEquals(0, purchaseId);
		
	}
	
	@Test
	public void testAddPurchaseDeatails2() throws MobileException {
		PurchaseDetails purchaseDetails = new PurchaseDetails(1111,
				"Smita", "smi@cg.com", "9879879990", 
				LocalDate.now(), 1001);
		int purchaseId=mobileDao.insertPurchasedetails(purchaseDetails );
		if(purchaseId>0)System.out.println("Unique Id : "+purchaseId);
		assertTrue(purchaseId>0);		
	}
	@Test
	public void testListMobile1() throws MobileException {
		List<Mobile> mobileList=mobileDao.listAllMobiles();
		assertNotNull("Mobile List Not Found",
				mobileList);
		for(Mobile mobile:mobileList)
			System.out.println(mobile);
		
	}
	@Test
	public void testListMobile2() throws MobileException {
		List<Mobile> mobileList=mobileDao.listAllMobiles();
		assertTrue("Mobile List Not Found",
				mobileList!=null);
		for(Mobile mobile:mobileList)
			System.out.println(mobile);
		
	}
	@Ignore
	@Test
	public void testDeleteMobile1() throws MobileException {
		int result=mobileDao.removeMobile(1111);
		if(result>0)System.out.println("No of Mobile deleted : "+result);
		assertTrue(result>0);		
	}
	@Ignore
	@Test
	public void testDeleteMobile2() throws MobileException {
		int result=mobileDao.removeMobile(2222);
		if(result>0)System.out.println("No of Mobile deleted : "+result);
		assertTrue(result>0);		
	}
	@Test
	public void testUpdateMobileQuantity1() throws MobileException {
		int result=mobileDao.updateMobileQuantity(1001, 10);
		if(result>0)System.out.println(result+"...Mobile Updated : ");
		assertTrue(result>0);		
	}
	@Test
	public void testUpdateMobileQuantity2() throws MobileException {
		int result=mobileDao.updateMobileQuantity(1002,10);
		if(result>0)System.out.println(result+"...Mobile Updated : ");
		assertEquals(1,result);		
	}
	@Test
	public void testSearchMobile1() throws MobileException {
		List<Mobile> mobileList=mobileDao.searchMobile(1001,5000);
		assertNotNull("Mobile  Not Found",
				mobileList);		
		if(mobileList!=null)System.out.println("Mobile Record Found....."+mobileList);		
	}
	@Test
	public void testSearchMobile2() throws MobileException {
		List<Mobile> mobileList=mobileDao.searchMobile(10002,90000);
		assertTrue("Mobile  Not Found",
				mobileList!=null);		
		if(mobileList!=null)System.out.println("Mobile Record Found....."+mobileList);		
	}
	@Test
	public void testsearchMobilePurchaseDeatails1() throws MobileException {
		PurchaseDetails purchaseDetails= mobileDao.searchMobilePurchaseDeatails(2001);
		assertTrue("Mobile PurchaseDetails Not Found",
				purchaseDetails!=null);		
		if(purchaseDetails!=null)System.out.println("Mobile PurchaseDetails Record Found....."+purchaseDetails);		
	}
	@Test
	public void testsearchMobilePurchaseDeatails2() throws MobileException {
		PurchaseDetails purchaseDetails= mobileDao.searchMobilePurchaseDeatails(2001);
		assertNotNull("Mobile PurchaseDetails Not Found",
				purchaseDetails!=null);		
		if(purchaseDetails!=null)System.out.println("Mobile PurchaseDetails Record Found....."+purchaseDetails);		
	}
	
}

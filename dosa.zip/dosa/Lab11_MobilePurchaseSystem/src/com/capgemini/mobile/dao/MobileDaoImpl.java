/**
 * 
 */
package com.capgemini.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.mobile.bean.Mobile;
import com.capgemini.mobile.bean.PurchaseDetails;
import com.capgemini.mobile.exception.MobileException;
import com.capgemini.mobile.util.DBUtil;

/**
 * @author Smita
 *
 */
public class MobileDaoImpl implements IMobileDao {
	// step 1 :declare Connection and Logger variables
	private Connection connection;
	private static Logger myLogger = null;
	// step 2 :static blog for logger code
	static {
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(MobileDaoImpl.class.getName());
	}

	// step 3 : obtain connection in the constructor
	public MobileDaoImpl() {
		try {
			connection = new DBUtil().obtainConnection();
			myLogger.info("Connection Obtained ... at DAO");
		} catch (MobileException e) {
			myLogger.error("ERROR : " + e);
			System.err.println(e.getMessage());
		}
	}

	// step 4 : override methods
	@Override
	public int insertPurchasedetails(PurchaseDetails purchaseDetails)
			throws MobileException {
		MobileDaoImpl daoImpl = new MobileDaoImpl();
		// purchasedetails(purchaseid NUMBER,
		// cname vARCHAR2(20), mailid VARCHAR2(30),
		// phoneno VARCHAR2(20), purchasedate DATE,
		// mobileid references mobiles(mobileid));
		// CREATE SEQUENCE purchase_seq
		String sql = "insert into purchasedetails "
				+ "values(purchase_seq.NEXTVAL,?,?,?,SYSDATE,?)";
		PreparedStatement pst = null;
		int insertRec = 0;
		int purchaseId = 0;
		int mobileId = purchaseDetails.getMobileId();
		int quantity = daoImpl.getMobileQuantity(mobileId);
		try {
			connection.setAutoCommit(false);// tx starts
			if (quantity > 0) {
				pst = connection.prepareStatement(sql);
				// SET THE PLACEHOLDERS VALUES
				pst.setString(1, purchaseDetails.getcName());
				pst.setString(2, purchaseDetails.getMailId());
				pst.setString(3, purchaseDetails.getPhoneNo());
				// convert LocalDate to sql Date
				/*LocalDate date = purchaseDetails.getPurchaseDate();
				java.sql.Date sqlDate = java.sql.Date.valueOf(date);
				pst.setDate(4, sqlDate);*/
				pst.setInt(4, mobileId);
				// executing the query
				insertRec = pst.executeUpdate();
				if (insertRec > 0) {
					// now update the mobile quantity
					int updateRec = daoImpl.updateMobileQuantity(mobileId,
							quantity - 1);
					if (updateRec > 0) {
						// getting unique purchase id
						purchaseId = getUniquePurchaseId();
					} else {
						myLogger.error("Not able to Update"
								+ " Mobile quantity of Mobile id : " + mobileId);
					}
				} else {
					myLogger.error("Not able to insert"
							+ " PurchaseDetails of Mobile id : " + mobileId);
				}
			} else {
				myLogger.error("No Stock for Mobile id : " + mobileId);
			}
			connection.commit();// tx ends
		} catch (SQLException e) {
			myLogger.error("ERRROR :  "
					+ "Inserting Mobile PurchaseDetails failed  "
					+ e.getMessage());
			//e.printStackTrace();
			throw new MobileException(
					"ERRROR :  Inserting Mobile PurchaseDetails failed  "
							+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  "
						+ "Inserting Mobile PurchaseDetails failed "
						+ e.getMessage());
				throw new MobileException(
						"ERRROR : Inserting Mobile PurchaseDetails failed "
								+ e.getMessage());
			}
		}
		return purchaseId;
	}

	@Override
	public List<Mobile> listAllMobiles() throws MobileException {
		ArrayList<Mobile> mobileList = null;
		Statement st = null;
		ResultSet rs = null;
		Mobile mobile = null;
		String sql = "select * from mobiles";
		try {
			// obtain st
			st = connection.createStatement();
			rs = st.executeQuery(sql);
			//initialize the list
			mobileList = new ArrayList<>();
			while (rs.next()) {
				//initialize the domain object
				mobile = new Mobile();
				// fetch the column data
				// and set to the mobile object
				mobile.setMobileId(rs.getInt(1));
				mobile.setName(rs.getString(2));
				mobile.setPrice(rs.getDouble(3));
				mobile.setQuantity(rs.getInt(4));
				// add the mobile object to the list
				mobileList.add(mobile);
			}
		} catch (SQLException e) {
			myLogger.error("MobileList not found , error occured : "
					+ e.getMessage());
			throw new MobileException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("MobileList not found , error occured :"
						+ e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return mobileList;
	}

	@Override
	public List<Mobile> searchMobile(double minPrice, double maxPrice)
			throws MobileException {
		ArrayList<Mobile> mobileList = null;
		myLogger.info("searchMobile() in MobileDaoImpl invoked!!");
		String sql = "SELECT * FROM mobiles WHERE price between ? and ?";
		Mobile mobile = null;
		PreparedStatement pst = null;
		try {
			// obtaining pst
			pst = connection.prepareStatement(sql);
			pst.setDouble(1, minPrice);
			pst.setDouble(2, maxPrice);// setting the mobileId
			ResultSet rs = pst.executeQuery();// executing the sql
			mobileList = new ArrayList<>();
			while (rs.next()) {
				myLogger.info("Mobile record found ");
				// create the object of mobile
				mobile = new Mobile();
				// mapping the value from db to mobile object
				// fetch the column data
				// and set to the mobile object
				mobile.setMobileId(rs.getInt(1));
				mobile.setName(rs.getString(2));
				mobile.setPrice(rs.getDouble(3));
				mobile.setQuantity(rs.getInt(4));
				// add the mobile object to the list
				mobileList.add(mobile);
				mobileList.add(mobile);
			}
		} catch (SQLException e) {
			myLogger.error("ERRROR " + "Searching Mobile details failed "
					+ e.getMessage());
			throw new MobileException("Searching Mobile details failed "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ERRROR " + "Searching Mobile details failed "
						+ e.getMessage());
				throw new MobileException("Searching Mobile details failed "
						+ e.getMessage());
			}
		}
		return mobileList;// returning mobile
	}

	@Override
	public int removeMobile(int mobileId) throws MobileException {
		myLogger.info("------------------Deleting Mobileloyee Records----------------");
		PreparedStatement ps = null;
		String sql = "delete from mobiles where mobileid=?";// '?'
		int noOfRec = 0; // placeholder
		try {
			// start the transaction boundary
			connection.setAutoCommit(false);
			// obatain ps object
			ps = connection.prepareStatement(sql);
			// prepare the pre-compiled statement
			// now we will set the dynamic(runtime) values of ps
			// placeholder-1
			ps.setInt(1, mobileId);
			// execute the insert query(DML)-executeUpdate()
			noOfRec = ps.executeUpdate();
			connection.commit();// transaction ends
		} catch (SQLException e) {
			throw new MobileException("Issue in Deleting mobile : " + e);
		} finally {
			if (ps != null)
				try {
					ps.close();
					connection.rollback();// if something wrong then rollback
				} catch (SQLException e) {
					throw new MobileException(
							"Issue while closing resource, which are null");
				}
		}
		return noOfRec;
	}

	@Override
	public int getUniquePurchaseId() throws MobileException {
		myLogger.info("Generating unique MobilePurchaseId");
		String sql = "SELECT purchase_seq.CURRVAL FROM dual";
		int purchaseId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				purchaseId = rs.getInt(1);
				myLogger.info("auto-generated Mobile purchaseId by sequence : "
						+ purchaseId);
			} else {
				myLogger.error("Mobile purchaseId not auto generated , error occured ");
			}
		} catch (SQLException e) {
			myLogger.error("Mobile purchaseId not auto generated , error occured : "
					+ e.getMessage());
			throw new MobileException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("Mobile purchaseId not auto generated , error occured :"
						+ e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return purchaseId;
	}

	@Override
	public int getMobileQuantity(int mobileId) throws MobileException {
		myLogger.info("------------------Fetching quantity of Mobile----------------");
		PreparedStatement ps = null;
		ResultSet rs=null;
		String sql = "select quantity from mobiles where mobileid=?";// '?'
		int quantity = 0; // placeholder
		try {
			// start the transaction boundary
			connection.setAutoCommit(false);
			// obatain ps object
			ps = connection.prepareStatement(sql);
			// prepare the pre-compiled statement
			// now we will set the dynamic(runtime) values of ps
			// placeholder-1
			ps.setInt(1, mobileId);
			// execute the insert query(DML)-executeUpdate()
			rs = ps.executeQuery();
			if(rs.next())
				quantity=rs.getInt(1);
			connection.commit();// transaction ends
		} catch (SQLException e) {
			throw new MobileException("Issue in fetching quantity of Mobile : " + e);
		} finally {
			if (ps != null)
				try {
					ps.close();
					connection.rollback();// if something wrong then rollback
				} catch (SQLException e) {
					throw new MobileException(
							"Issue while closing resource, which are null");
				}
		}
		return quantity;
	}

	@Override
	public int updateMobileQuantity(int mobileId, int quantity)
			throws MobileException {
		myLogger.info("updateMobile() invoked in MobileDaoImpl!!");

		System.out.println("Updating Mobile record.... Kindly have patience!!");
		String sql = "update mobiles set quantity=? where mobileid=?";
		PreparedStatement pst = null;
		int result = 0;
		try {// obtain ps
			pst = connection.prepareStatement(sql);
			connection.setAutoCommit(false);// transaction starts
			// set the values for place hodlers

			pst.setDouble(1, quantity);
			pst.setInt(2, mobileId);
			myLogger.info("Mobile details getting Updated ....");
			// execute DML query
			result = pst.executeUpdate();
			// now updating into Mobile table only if the first
			// insert is successful
			// getting the auto_generated id from the getNextMobileId()
			myLogger.info("Mobile Id : " + mobileId + " ,Quantity Updated");

			connection.commit();// if insert successful the commit the
								// transaction
		} catch (SQLException e) {
			myLogger.error("ERRROR :  "
					+ "Updating Quantity of Mobile failed  " + e.getMessage());

			throw new MobileException("ERRROR :  Updating Mobile failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  "
						+ "Updating Mobile Quantity failed " + e.getMessage());
				throw new MobileException(
						"ERRROR : Updating Mobile Quantity failed "
								+ e.getMessage());
			}
		}
		return result;
	}

	@Override
	public PurchaseDetails searchMobilePurchaseDeatails(int purchaseId)
			throws MobileException {
		myLogger.info("searchMobilePurchaseDeatails() in MobileDaoImpl invoked!!");
		String sql = "SELECT * FROM purchasedetails WHERE purchaseid=?";
		PurchaseDetails purchaseDetails = null;
		PreparedStatement pst = null;
		try {
			// obtaining pst
			pst = connection.prepareStatement(sql);
			pst.setInt(1, purchaseId);// setting the purchaseId
			ResultSet rs = pst.executeQuery();// executing the sql
			if (rs.next()) {
				myLogger.info("PurchaseDetails record found ");
				// create the object of purchaseDetails
				purchaseDetails = new PurchaseDetails();
				// mapping the value from db to purchaseDetails object
				purchaseDetails.setPurchaseId(rs.getInt(1));
				purchaseDetails.setcName(rs.getString(2));
				purchaseDetails.setMailId(rs.getString(3));
				purchaseDetails.setPhoneNo(rs.getString(4));
				java.sql.Date sqlDate= rs.getDate(5);
				purchaseDetails.setPurchaseDate(sqlDate.toLocalDate());
				purchaseDetails.setMobileId(rs.getInt(6));

			} else {
				myLogger.error("ERRROR " + "purchase Id does Not Exits");
				throw new MobileException("purchase Id does Not Exits , ");
			}
		} catch (SQLException e) {
			myLogger.error("ERRROR " + "Searching Mobile purchaseDetails failed "
					+ e.getMessage());
			throw new MobileException("Searching Mobile purchaseDetails failed "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				myLogger.error("ERRROR " + "Searching Mobile purchaseDetails failed "
						+ e.getMessage());
				throw new MobileException(
						"Searching Mobile purchaseDetails failed " + e.getMessage());
			}
		}
		return purchaseDetails;// returning mobile
	}
}

/**
 * 
 */
package com.capgemini.mobile.dao;

import java.util.List;

import com.capgemini.mobile.bean.Mobile;
import com.capgemini.mobile.bean.PurchaseDetails;
import com.capgemini.mobile.exception.MobileException;

/**
 * @author Smita
 *
 */
public interface IMobileDao {

	//business Methods
	public int insertPurchasedetails(PurchaseDetails 
			purchaseDetails)throws MobileException;
	public List<Mobile> listAllMobiles()throws MobileException;
	public int removeMobile(int mobileId) throws MobileException;// U
	public List<Mobile> searchMobile(double minPrice,
			double maxPrice) throws MobileException;
	public PurchaseDetails searchMobilePurchaseDeatails(int purchaseId) throws MobileException;
		
	//dao	//fetch the generated mobileId from the sequence
	public int getUniquePurchaseId()
				throws MobileException;
	//check the mobile quantity then make purchase
	public int getMobileQuantity(int mobileId)
			throws MobileException;
	//Update the mobile quantity in mobiles table, 
	//once mobile is purchased by a customer.
	public int updateMobileQuantity(int mobileId,
			int quantity)throws MobileException;
	
}

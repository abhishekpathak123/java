package com.capgemini.mobile.client;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.mobile.bean.Mobile;
import com.capgemini.mobile.bean.PurchaseDetails;
import com.capgemini.mobile.exception.MobileException;
import com.capgemini.mobile.service.IMobileService;
import com.capgemini.mobile.service.MobileServiceImpl;
import com.capgemini.mobile.exception.MobileException;

/**
 * @author Smita
 *
 */
public class Client {
	private static IMobileService mobileService;
	private static Scanner sc;
	private static Logger myLogger = null;
	// step 2 :static blog for logger code
	static {
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(Client.class.getName());
		sc = new Scanner(System.in);
		mobileService = new MobileServiceImpl();
	}

	public static void main(String[] args) {

		int option = 0;
		try {
			// crud
			do {
				option = showMenu(option);
				switch (option) {
				case 1:
					acceptDetailsFromUser();
					break;
				case 2:
					listAllRecords();
					break;
				case 3:
					searchRecord();
					break;
				case 4:
					removeRecord();
					break;
				case 5:
					searchPurchaseDetails();
					break;
				case 6:
					exitApp();
					break;
				default:
					System.out.println("Wrong option entered"
							+ "\n kindly enter choice (1-6) only");
					break;
				}
			} while (true);
		} catch (MobileException e) {
			myLogger.error("Something went wrong at client code..."
					+ e.getMessage());
			System.out.println("Something went wrong at client code..."
					+ e.getMessage());
		} catch (InputMismatchException e) {
			myLogger.error("Input should be only Numbers ");
			System.out.println("Input should be only Numbers ");
		}
	}// end of main
		// -showing main menu to opt choice from the user

	private static void searchPurchaseDetails() {
		int purchaseId = 0;
		try {
			// accept mobile id to be Searched
			System.out.println("Enter purchase Id to be Searched");
			purchaseId = sc.nextInt();
			while (true) {
				if (mobileService.validateId(purchaseId)) {
					// mobile.setMobileId(mobileId);
					break;
				} else {
					System.err
							.println("**********Please Enter  Correct Mobile Purchase Id:"
									+ "(Must be 4 digits only)**********");
					purchaseId = sc.nextInt();
				}
			}// end of while
				// search the mobile weather it exists or not
			PurchaseDetails purchaseDetails = mobileService.searchMobilePurchaseDeatails(purchaseId);
			// remove the mobile if it is not null
			if (purchaseDetails != null) {
				purchaseDetails.print();
			} else {
				myLogger.error("Mobile Not Exists!!");
				System.err
				.println("\n=================================================================="
						+ "\n		Sorry !! No Mobile Purchase details Found!!"
						+ "\n==================================================================");
		
			}
		} catch (MobileException e) {
			myLogger.error("Something went wrong..."
					+ "while Searching Record..." + e.getMessage());
			
			
			System.err.println("Something went wrong..."
					+ "while Searching Record..." + e.getMessage());
		}
	}

	private static int showMenu(int option) throws MobileException {
		System.out.println(
				  "\n_________________________________________________________________________________\n"
				+ "\n	   Mobile Application\n"
				+ "\n_________________________________________________________________________________\n"

				+ "\n   Enter your Choice (1-5)\n" 
				+ "\n      1. Add Mobile Purchase Details"
				+ "\n      2. Display All Mobile Details"
				+ "\n      3. Search Mobile Details" 
				+ "\n      4. Remove Mobile Details"
				+ "\n      5. Search Mobile Purchase Details"
				+ "\n      6. Exit"
				+ "\n_________________________________________________________________________________\n");
		option = sc.nextInt();

		return option;
	}

	private static void exitApp() {
		System.out
		.println(
				  "\n=================================================================="
				+ "\n		Thankyou for using Mobile App"
				+ "\n             Do Visit Again!!!"
				+ "\n==================================================================");

		sc.close();
		System.exit(0);
	}

	private static void removeRecord() throws MobileException {
		// accept mobile id to be deleted
		System.out
				.println("Enter Mobile Id to be deleted from the following List Of Mobiles:");
		listAllRecords();
		int mobileId = sc.nextInt();
		// search the mobile weather it exists or not
		int result = mobileService.removeMobile(mobileId);
		// remove the mobile if it is not null
		if (result > 0) {
			System.out
					.println("\n=================================================================="
							+ "\n		Mobile Delete Successfully!!"
							+ "\n==================================================================");
		} else {
			System.err
					.println("\n=================================================================="
							+ "\n		Sorry !! Mobile Does Not exists!!"
							+ "\n==================================================================");
		}
	}

	private static void searchRecord() throws MobileException {
		// accept mobile id to be Searched
		System.out
				.println("Enter Minium price range of the Mobile to be Searched");
		double minPrice = sc.nextDouble();
		System.out
				.println("Enter Maxium price range of the Mobile to be Searched");
		double maxPrice = sc.nextDouble();
		List<Mobile> mobileList = null;
		while (true) {
			if (mobileService.validatePrice(minPrice, maxPrice)) {
				mobileList=mobileService.searchMobile(minPrice, maxPrice);
				break;
			} else {
				System.err
						.println("**********Please Enter Correct Price Range:"
								+ "(Min price Must be less than Max Price Range)**********");
				System.out
				.println("**********Please Enter Correct Min Price Range:");
				
				minPrice = sc.nextDouble();
				System.out
				.println("**********Please Enter Correct Max Price Range:");
				maxPrice = sc.nextDouble();
			}
		}// end of while
		if (mobileList != null) {
			System.out
					.println("\n=================================================================="
							+ "\n		Mobile List between "
							+ minPrice
							+ " and "
							+ maxPrice
							+ "\n==================================================================");

			for (Mobile mobile : mobileList) {
				System.out.println(mobile);
			}
		} else {
			System.err
			.println("\n=================================================================="
					+ "\n		Sorry !! No Mobile Found in the Given Range!!"
					+ "\n==================================================================");
		}
	}

	private static void listAllRecords() throws MobileException {
		List<Mobile> mobileList = mobileService.listAllMobiles();

		if (mobileList != null) {
			System.out
					.println("\n=================================================================="
							+ "\n		Mobile List "
							+ "\n==================================================================");

			for (Mobile mobile : mobileList) {
				System.out.println(mobile);
			}
		} else {
			System.err
			.println("\n=================================================================="
					+ "\n		Sorry !! No Mobiles Record Found!!"
					+ "\n==================================================================");

		}
	}

	private static void acceptDetailsFromUser() throws MobileException {
		PurchaseDetails purchaseDetails= new PurchaseDetails();
		// accept purchaseDetails
		System.out.println("Enter Customer Name FirstName");
		
		String cName=sc.next();
		while (true) {
			if (mobileService.validateName(cName)) {
				purchaseDetails.setcName(cName);
				break;
			} else {
				System.err
						.println("**********Please Enter  Correct Customer Name FirstName:"
								+ "(Must be 3-20 chars only and First letter must be in Capital Letter)**********");
				cName=sc.next();
			}
		}// end of while
		System.out.println("Enter Customer Email");		
		String mailId=sc.next();
		while (true) {
			if (mobileService.validateEmail(mailId)) {
				purchaseDetails.setMailId(mailId);
				break;
			} else {
				System.err
						.println("**********Please Enter  Correct Customer Email Id **********");
				mailId=sc.next();
			}
		}// end of while
		System.out.println("Enter Mobile PhoneNo");		
		String phoneNo=sc.next();
		while (true) {
			if (mobileService.validatePhoneNo(phoneNo)){
				purchaseDetails.setPhoneNo(phoneNo);
				break;
			} else {
				System.err
						.println("**********Please Enter  Correct Phone Number"
								+ " (Must be 10 digit only and start with 7 or 8 or 9 **********");
				phoneNo=sc.next();
			}
		}// end of while
		purchaseDetails.setPurchaseDate(LocalDate.now());
		System.out.println("Enter Mobile Id you want to purchase from the below list of Mobiles:");
		listAllRecords();
		int mobileId=sc.nextInt();
		while (true) {
			if (mobileService.validateId(mobileId)) {
				purchaseDetails.setMobileId(mobileId);
				break;
			} else {
				System.err
						.println("**********Please Enter  Correct Mobile Id:"
								+ "(Must be 4 digits only)**********");
				mobileId = sc.nextInt();
			}
		}// end of while
		int purchaseId=mobileService.insertPurchaseDetails(purchaseDetails);
	
		if (purchaseId > 0) {
			System.out
					.println("\n=================================================================="
							+ "\n		Mobile Purchase Deatailes Added Successfully!!"
							+ "\n 		Unique Purchase Id generated is : "+purchaseId
							+ "\n==================================================================");
		} else {
			System.err
					.println("\n=================================================================="
							+ "\n		Sorry !! Purchase Deatailes Not Added!!"
							+ "\n==================================================================");
		}
		
	}
}

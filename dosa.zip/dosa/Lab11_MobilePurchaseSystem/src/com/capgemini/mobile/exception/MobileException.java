/**
 * 
 */
package com.capgemini.mobile.exception;

/**
 * @author Smita
 *
 */
public class MobileException extends Exception {

	private static final long serialVersionUID = -7944245173912011512L;

	/**
	 * 
	 */
	public MobileException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public MobileException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}

/**
 * 
 */
package com.capgemini.service;

import com.capgemini.DosaException.DosaException;
import com.capgemini.jdbc.bean.CustomerDetails;
import com.capgemini.jdbc.bean.DosaDetails;


/**
 * @author apathak8
 *
 */
public interface IDosaService {
	public int placeOrder(CustomerDetails customerDetails)throws DosaException;
	public int takeOrder(DosaDetails dosaDetails) throws DosaException;
	
	
	//validate method
	public boolean validatePhoneNo(String phone)throws DosaException;

}

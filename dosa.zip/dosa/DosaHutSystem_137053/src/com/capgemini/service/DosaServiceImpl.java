/**
 * 
 */
package com.capgemini.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.DosaException.DosaException;
import com.capgemini.jdbc.bean.CustomerDetails;
import com.capgemini.jdbc.bean.DosaDetails;
import com.capgemini.jdbc.dao.DosaDaoImpl;
import com.capgemini.jdbc.dao.IDosaDao;


/**
 * @author apathak8
 *
 */
public class DosaServiceImpl implements IDosaService {
	private static IDosaDao dosaDao;
	static{
		dosaDao = new DosaDaoImpl();
	}

	@Override
	public int placeOrder(CustomerDetails customerDetails) throws DosaException {
		// TODO Auto-generated method stub
		return dosaDao.placeOrder(customerDetails);
	}

	@Override
	public int takeOrder(DosaDetails dosaDetails) throws DosaException {
		// TODO Auto-generated method stub
		return dosaDao.takeOrder(dosaDetails);
	}



	@Override
	public boolean validatePhoneNo(String phone) throws DosaException {
		String input = String.valueOf(phone);
		// creating regex pattern String
		String patternStr = "^[789][0-9]{9}$";
		// 10 digits phone number
		// 1st number must start with 7 or 8 or 9
		// followed by 9 digits
		// Now create matcher object.

		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	
	}
	

}

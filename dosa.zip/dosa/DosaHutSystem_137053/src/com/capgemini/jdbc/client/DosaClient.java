/**
 * 
 */
package com.capgemini.jdbc.client;

/**
 * @author apathak8
 *
 */
public class DosaClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

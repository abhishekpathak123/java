/**
 * 
 */
package com.capgemini.jdbc.dao;

import java.util.List;

import com.capgemini.DosaException.DosaException;
import com.capgemini.jdbc.bean.CustomerDetails;
import com.capgemini.jdbc.bean.DosaDetails;





/**
 * @author apathak8
 *
 */
public interface IDosaDao {
	public int placeOrder(CustomerDetails customerDetails)throws DosaException;
	public int takeOrder(DosaDetails dosaDetails) throws DosaException;
	//public List<DosaDetails> listDosaDetails()throws DosaException;
	public int getUniqueOrderId()throws DosaException;
	public int getUniqueCustomerId()throws DosaException;

}

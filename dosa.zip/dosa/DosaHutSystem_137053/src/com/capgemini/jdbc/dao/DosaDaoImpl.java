/**
 * 
 */
package com.capgemini.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.DosaException.DosaException;
import com.capgemini.jdbc.bean.CustomerDetails;
import com.capgemini.jdbc.bean.DosaDetails;
import com.capgemini.jdbc.util.DBUtil;




/**
 * @author apathak8
 *
 */
public class DosaDaoImpl implements IDosaDao {
	
	private Connection connection;
	private static Logger myLogger = null;
	
	static {
		PropertyConfigurator.configure("resources/log4j.properties");
		myLogger = Logger.getLogger(DosaDaoImpl.class.getName());
	}

	
	public DosaDaoImpl() {
		try {
			connection = new DBUtil().obtainConnection();
			myLogger.info("Connection Obtained ... at DAO");
		} catch (DosaException e) {
			myLogger.error("ERROR : " + e);
			System.err.println(e.getMessage());
		}
	}
	@Override
	public int placeOrder(CustomerDetails customerDetails) throws DosaException {
		myLogger.info("placeOrder() invoked in DosaDaoImpl!!");
		System.out.println("Taking Dosa Order Details.... Kindly have patience!!");
		String sql = "insert into dosa_entry values(purchase_seq.NEXTVAL,?,?,?,?)";
		PreparedStatement pst = null;
		//int UniqueOrderId = 0;
		int UniqueCustomerId = 0;
		DosaDaoImpl dosaDao = new DosaDaoImpl();//because calling 2 funcs
		int custId = customerDetails.getCustId();
		try{
			connection.setAutoCommit(false);// transaction starts
			
			pst = connection.prepareStatement(sql);
			pst.setString(1, customerDetails.getCustName());
			pst.setString(2, customerDetails.getCustAddress());
			pst.setString(3, customerDetails.getCustPhone());
			pst.setInt(4, customerDetails.getCustId());
			
			
			//UniqueOrderId = getUniqueOrderId();
			custId  = getUniqueCustomerId();
			customerDetails.setCustId(custId);;
			//customerDetails.setCustId(custId);
			
		}catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Inserting Trainee failed  "
					+ e.getMessage());
			throw new DosaException("ERRROR :  Inserting Trainee failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Inserting Trainee failed "
						+ e.getMessage());
				throw new DosaException(
						"ERRROR : Inserting Trainee failed " + e.getMessage());
			}}
		return custId;
	}
	
	public int takeOrder(DosaDetails dosaDetails) throws DosaException {
		myLogger.info("takeOrder() invoked in DosaDaoImpl!!");
		System.out.println("Taking Dosa Order Details.... Kindly have patience!!");
		String sql = "insert into dosa_entry values(purchase_seq.NEXTVAL,?,?,?,?)";
		PreparedStatement pst = null;
		int UniqueOrderId = 0;
		//int UniqueCustomerId = 0;
		DosaDaoImpl dosaDao = new DosaDaoImpl();//because calling 2 funcs
		int custId = dosaDetails.getOrderId();
		try{
			connection.setAutoCommit(false);// transaction starts
			
			pst = connection.prepareStatement(sql);
			pst.setInt(1, dosaDetails.getCustId());
			pst.setDouble(2, dosaDetails.getTotalPrice());
			pst.setDate(3, java.sql.Date.valueOf(dosaDetails.getOrderDate()));
			
			
			UniqueOrderId = getUniqueOrderId();
			//custId  = getUniqueCustomerId();
			//customerDetails.setCustId(custId);;
			dosaDetails.setCustId(custId);
			
		}catch (SQLException e) {
			myLogger.error("ERRROR :  " + "Inserting Trainee failed  "
					+ e.getMessage());
			throw new DosaException("ERRROR :  Inserting Trainee failed  "
					+ e.getMessage());
		} finally {
			try {
				if (pst != null)
					pst.close();
				// if exception then transaction will rollback
				connection.rollback();
			} catch (SQLException e) {
				myLogger.error("ERRROR :  " + "Inserting Trainee failed "
						+ e.getMessage());
				throw new DosaException(
						"ERRROR : Inserting Trainee failed " + e.getMessage());
			}}
		return custId;
	}

		

		

	/*@Override
	public List<DosaDetails> listDosaDetails() throws DosaException {
		ArrayList<DosaDetails> OrderList = null;
		Statement st = null;
		ResultSet rs = null;
		DosaDetails dosaDetails = null;
		String sql = "select * from dosa_entry";
		return null;
	}*/

	@Override
	public int getUniqueOrderId() throws DosaException {
		myLogger.info("Generating unique OrderId");
		String sql = "SELECT dosaSeq.CURRVAL FROM dual";
		int orderId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				orderId = rs.getInt(1);
				myLogger.info("auto-generated purchaseId by sequence : "
						+ orderId);
			} else {
				myLogger.error("purchaseId not auto generated , error occured ");
			}
		} catch (SQLException e) {
			myLogger.error("purchaseId not auto generated , error occured : "
					+ e.getMessage());
			throw new DosaException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("purchaseId not auto generated , error occured :"
						+ e.getMessage());
				throw new DosaException(e.getMessage());
			}
		}
		
		return orderId;
	}
		

	@Override
	public int getUniqueCustomerId() throws DosaException {
		myLogger.info("Generating unique CustomerId");
		String sql = "SELECT customerSeq.CURRVAL FROM dual";
		int custId = 0;
		Statement st = null;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				custId = rs.getInt(1);
				myLogger.info("auto-generated purchaseId by sequence : "
						+ custId);
			} else {
				myLogger.error("purchaseId not auto generated , error occured ");
			}
		} catch (SQLException e) {
			myLogger.error("purchaseId not auto generated , error occured : "
					+ e.getMessage());
			throw new DosaException(e.getMessage());
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				myLogger.error("purchaseId not auto generated , error occured :"
						+ e.getMessage());
				throw new DosaException(e.getMessage());
			}
		}
		
		return custId;
	}
}

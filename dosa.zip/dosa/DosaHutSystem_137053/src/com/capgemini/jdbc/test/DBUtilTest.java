package com.capgemini.jdbc.test;
import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.DosaException.DosaException;
import com.capgemini.jdbc.util.DBUtil;



/**
 * @author apathak8
 *
 */
public class DBUtilTest {
	 static DBUtil dbUtil ;
	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void testDBUtil() throws DosaException{
		dbUtil= new DBUtil();
		assertNotNull("DBUtil Object Not created..."
				,dbUtil);
	}
	@Test
	public void testConnection() throws DosaException {
		Connection conn = dbUtil.obtainConnection();
		assertNotNull("Connection NOT obtained!",conn);
		if(conn!=null)System.out.println("connection Obtained ...."+conn);
	}

}

package com.capgemini.jdbc.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class DosaDaoImplTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}

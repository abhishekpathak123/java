/**
 * 
 */
package com.capgemini.jdbc.bean;

import java.time.LocalDate;

/**
 * @author apathak8
 *
 */
public class DosaDetails {
	private int orderId;
	private double totalPrice;
	private LocalDate orderDate;
	private int custId;
	
	public DosaDetails(){
		
	}

	@Override
	public String toString() {
		return "DosaDetails [orderId=" + orderId + ", totalPrice=" + totalPrice
				+ ", orderDate=" + orderDate + ", custId=" + custId + "]";
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}
	
	public DosaDetails(int orderId, double totalPrice, LocalDate orderDate, int custId) {
		super();
		this.orderId = orderId;
		this.totalPrice = totalPrice;
		this.orderDate = orderDate;
		this.custId = custId;
	}
	
	public void print() {
		System.out.println("\n________________________________________"
				+ "\n	Dosa Details					"
				+ "\n________________________________________"
				+ "\n	Order Id 	    	: " + orderId
				+ "\n	Total price			: " + totalPrice
				+ "\n	Order Date    	 	: " + orderDate
				+ "\n	Customer Id		    : " + custId
				+ "\n________________________________________");
	}

}

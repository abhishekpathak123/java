/**
 * 
 */
package com.capgemini.DosaException;

/**
 * @author apathak8
 *
 */
public class DosaException extends Exception {

	public DosaException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DosaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 3865927095556110733L;

}

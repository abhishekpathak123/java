package com.capgemini.ocs.dao;

import java.util.List;

import com.capgemini.ocs.bean.PlayerBean;
import com.capgemini.ocs.exception.CricketException;

public interface ICricketScoreDao {
	public int addInfo(PlayerBean player) throws CricketException;
	public List<PlayerBean> getInfo() throws CricketException;
	
}

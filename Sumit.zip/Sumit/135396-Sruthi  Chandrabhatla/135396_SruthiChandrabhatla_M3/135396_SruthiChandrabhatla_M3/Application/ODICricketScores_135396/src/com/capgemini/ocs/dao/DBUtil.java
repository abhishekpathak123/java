package com.capgemini.ocs.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.ocs.exception.CricketException;

public class DBUtil {

	private static Connection conn;

	public static Connection getConnection() throws CricketException {

		if (conn == null) {
			/*
			 * InitialContext ic; DataSource ds;
			 */
			try {
				InitialContext ic = new InitialContext();
				DataSource ds = (DataSource) ic.lookup("java:/jdbc/MyDatabase");
				conn = ds.getConnection();
			} catch (NamingException e) {
				throw new CricketException("Problem in obtaining datasource"
						+ e.getMessage());

			} catch (SQLException e) {
				throw new CricketException("Problem in obtaining datasource"
						+ e.getMessage());
			}

		}
		return conn;

	}
}
